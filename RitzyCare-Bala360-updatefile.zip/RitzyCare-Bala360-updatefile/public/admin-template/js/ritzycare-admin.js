$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

/** Zone Status Update */

function blockunblockZone(id, type) {
    $.get('blockunblock-zone/' + id + '/' + type, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Please try later.");
    });
}

/** Delete Zone */

function deleteZone(id) {
    if (id && confirm('Are you sure want to delete?')) {
        $.get('delete-zone/' + id, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Problem Occur.Please try again!.");
        });
    }
    return;
}

/** Area status update */

function blockunblockArea(id, type) {
    $.get('blockunblock-area/' + id + '/' + type, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Please try later.");
    });
}

/** Delete Area */

function deleteArea(id) {
    if (id && confirm('Are you sure want to delete?')) {
        $.get('delete-area/' + id, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Please try later.");
        });
    }
    return;
}

/** Category Status Update */

function blockunblockCategory(id, type, category_type, parent_category) {
    var Path = domainScriptPath + 'admin/blockunblock-category/' + id + '/' + type + '/' + category_type + '/' + parent_category;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Category */

function deleteCategory(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-category/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Banner Status Update */

function blockunblockBanner(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-banner/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Banner */

function deleteBanner(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-banner/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Brand Status Update */

function blockunblockBrand(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-brand/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Banner */

function deleteBrand(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-brand/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Delete faq */

function deleteFaq(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-faq/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Faq Status Update */

function blockunblockFaq(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-faq/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Ads image Status Update */

function blockunblockAdsimage(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-promo-ad/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Ads image */

function deleteAdsimage(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-promo-ad/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Page Status Update */

function blockunblockPage(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-page/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Page */

function deletePage(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-page/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Socialreview Status Update */

function blockunblockSocialreview(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-social-review/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Socialreview */

function deleteSocialreview(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-social-review/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Membership Status Update */

function blockunblockmembershipplan(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-membership/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Referral Status Update */

function blockunblockReferral(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-referral/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Reward Status Update */

function blockunblockReward(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-reward/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Membership image */

function deletemembershipplan(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-membership/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Ads video Status Update */

function blockunblockAdsvideo(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-promo-video/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Ads video */

function deleteAdsvideo(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-promo-video/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Programme Status Update */

function blockunblockProgramme(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-programme/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Programme */

function deleteProgramme(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-programme/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Add Vendor - Fetch Zone Based Area Data */

$('#storeZone').on('change', function () {
    var html = "";
    $.ajax({
        type: "get",
        url: domainScriptPath + 'admin/fetch-area',
        data: { zone: $(this).val() },
        success: function (data) {
            $('#storeArea').html($("<option></option>").attr("value", '').text('--- Select Zone First ---'));
            if ($.trim(data)) {
                $.each(data, function (key, value) {
                    $('#storeArea').empty().append($("<option selected></option>").attr("value", value.id).text(value.area_name.en));
                    $("#storeArea").selectpicker("refresh");
                });
            } else {
                $('#storeArea').html($("<option></option>").attr("value", '').text('--- Select Zone First ---'));
            }
        },
        error: function () {
            console.warn("Problem in fetching information");
        }
    });
});

/** Vendor Status Update */

function blockunblockVendor(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-vendor/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Vendor */

function deleteVendor(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-vendor/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Vendor Store Status Update */

function blockunblockStore(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-vendor-store/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Vendor Store */

function deleteStore(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-vendor-store/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

$(function () {
    $('.editAttrType').on('click', function () {
        var modal = $("#editAttrTypeModal");
        var id = $(this).data('id');
        var name = $(this).data('name');
        var name_ar = $(this).data('name-ar');
        var type = $(this).data('type');
        var typeName = type == 0 ? 'Text' : type == 1 ? 'Color' : 'Image';
        modal.find('.filter-option-inner-inner').text(typeName);
        modal.find('select[name=attribute_category]').val(type);
        modal.selectpicker("refresh");
        modal.find('input[name=attribute_name]').val(name);
        modal.find('input[name=attribute_name_ar]').val(name_ar);
        var form = document.getElementById('edit-attribute');
        form.action = domainScriptPath + 'admin/update-attribute-type/' + id;
        modal.modal('show');
    });
});

$(".numeric-validation").keypress((function (e) { var t = e.charCode ? e.charCode : e.keyCode; if (8 != t && "." != e.key && 45 != t && (t < 2534 || t > 2543) && (t < 48 || t > 57)) return !1 }));

$(".integer-validation").keypress((function (e) { var t = e.charCode ? e.charCode : e.keyCode; if (8 != t && (t < 2534 || t > 2543) && (t < 48 || t > 57)) return !1 }));

/** Fetch Category Based Sub Category */

$('#itemMainCategory').on('change', function () {
    $.ajax({
        type: "get",
        url: domainScriptPath + 'admin/fetch-categories',
        data: { categoryID: $(this).val(), searchType: 2 },
        success: function (data) {
            if (data.length == 0) {
                $('#itemSubCategory').empty().html($("<option selected></option>").attr("value", '').text('No categories found'));
                $("#itemSubCategory").selectpicker("refresh");
            }
            $('#itemSubCategory').empty().html($("<option selected></option>").attr("value", '').text('Choose Sub Category'));
            if ($.trim(data)) {
                $.each(data, function (key, value) {
                    if (formSubCate == value.id) {
                        $('#itemSubCategory').append($("<option selected></option>").attr("value", value.id).text(toUcWords(value.category_name.en)));
                    } else {
                        $('#itemSubCategory').append($("<option></option>").attr("value", value.id).text(toUcWords(value.category_name.en)));
                    }
                });
                $("#itemSubCategory").selectpicker("refresh");
            } else {
                $('#itemSubCategory').html($("<option></option>").attr("value", '').text('Choose Parent Category'));
            }
        },
        error: function () {
            console.warn("Problem in fetching information");
        }
    });
});

/** Fetch Sub Category Based Sec Sub Category */

$('#itemSubCategory').on('change', function () {
    var cateID = ($(this).val() != '') ? $(this).val() : formSubCate;
    $.ajax({
        type: "get",
        url: domainScriptPath + 'admin/fetch-categories',
        data: { categoryID: cateID, searchType: 3 },
        success: function (data) {
            if (data.length == 0) {
                $('#itemThirdCategory').empty().html($("<option selected></option>").attr("value", '').text('No categories found'));
                $("#itemThirdCategory").selectpicker("refresh");
            }
            $('#itemThirdCategory').empty().html($("<option selected></option>").attr("value", '').text('Choose Sub Category'));
            if ($.trim(data)) {
                $.each(data, function (key, value) {
                    if (formSecSubCate == value.id) {
                        $('#itemThirdCategory').append($("<option selected></option>").attr("value", value.id).text(toUcWords(value.category_name.en)));
                    } else {
                        $('#itemThirdCategory').append($("<option></option>").attr("value", value.id).text(toUcWords(value.category_name.en)));
                    }
                });
                $("#itemThirdCategory").selectpicker("refresh");
            } else {
                $('#itemThirdCategory').html($("<option></option>").attr("value", '').text('Choose Parent Category'));
            }
        },
        error: function () {
            console.warn("Problem in fetching information");
        }
    });
});

/** Fetch Sub Category Based Sec Sub Category */

$('#itemThirdCategory').on('change', function () {
    var cateID = ($(this).val() != '') ? $(this).val() : formSecSubCate;
    $.ajax({
        type: "get",
        url: domainScriptPath + 'admin/fetch-categories',
        data: { categoryID: cateID, searchType: 4 },
        success: function (data) {
            if (data.length == 0) {
                $('#itemFourthCategory').empty().html($("<option selected></option>").attr("value", '').text('No categories found'));
                $("#itemFourthCategory").selectpicker("refresh");
            }
            $('#itemFourthCategory').empty().html($("<option selected></option>").attr("value", '').text('Choose Sub Category'));
            if ($.trim(data)) {
                $.each(data, function (key, value) {
                    if (formThirdCate == value.id) {
                        $('#itemFourthCategory').append($("<option selected></option>").attr("value", value.id).text(toUcWords(value.category_name.en)));
                    } else {
                        $('#itemFourthCategory').append($("<option></option>").attr("value", value.id).text(toUcWords(value.category_name.en)));
                    }
                });
                $("#itemFourthCategory").selectpicker("refresh");
            } else {
                $('#itemFourthCategory').empty().html($("<option></option>").attr("value", '').text('No Categories Found'));
            }
        },
        error: function () {
            console.warn("Problem in fetching information");
        }
    });
});

$(function () {
    $('#add-more-image').hide();
    $('#remove-additional-image').hide();
    $('#spec-desc-input').hide();
});

var itemImg = $('.additionalImage').length + 0;

function validateFileExtension(fld) {
    if (!/(\.png|\.jpg|\.jpeg)$/i.test(fld.value)) {
        alert("Invalid image file type.");
        return false;
    }
    if (itemImg == 1) {
        $('#add-more-image').show();
    }
    return true;
}

$('#add-more-image').on("click", function () {
    $('#remove-additional-image').show();
    if (itemImg != 5) {
        itemImgInc = itemImg + 1;
        $('<div class="row clearfix additionalImage"><div class="col-md-4"><label for="additionalImage-1">Additional Images</label><div class="form-group"><input type="file" name="item_sub_image[]" id="additionalImage-' + itemImgInc + '" class="form-control" onchange="return validateFileExtension(this)" accept=".jpeg,.jpg,.png"></div></div></div>').fadeIn("slow").appendTo('.jAdd');
        itemImg++;
        if (itemImg == 5) {
            $('#add-more-image').hide();
        }
    } else {
        $('#add-more-image').hide();
    }
});

$('#remove-additional-image').on("click", function () {
    if (itemImg > 0) {
        $('#add-more-image').show();
        $('.additionalImage:last').remove();
        itemImg--;
        if (itemImg == 1) {
            $('#remove-additional-image').hide();
        }
    } else if (itemImg == 1) {
        alert('No more to remove');
        itemImg = 1;
        return false;
    }
});

var itemSpecID = 0;
$('#add-specification').on("click", function (e) {
    e.preventDefault();
    var itemSpec = $('.itemSpec').length + 0;
    $('#spec-desc').hide();
    $('#spec-desc-input').show();
    itemSpecID = itemSpec + 1;
    $('#spec-desc-input').append('<div class="row clearfix p-2 ml-1 itemSpec itemSpecRow-' + itemSpecID + '"><div class="col-md-1"><label>' + itemSpecID + '</label></div><div class="col-md-5"><input type="text" name="item_spec[]" id="itemSpec-' + itemSpecID + '" class="form-control" placeholder="Item specification name" required="true"></div><div class="col-md-5"><input type="text" name="item_spec_desc[]" id="itemSpecDesc" class="form-control" placeholder="Item specification description" required="true"></div></div><div class="row clearfix p-2 ml-1 itemSpecRow-' + itemSpecID + '"><div class="col-md-1"><label>&nbsp</label></div><div class="col-md-5"><input type="text" name="item_spec_ar[]" id="itemSpec-' + itemSpecID + '" class="form-control" placeholder="Item specification name (Arabic)" required="true"></div><div class="col-md-5"><input type="text" name="item_spec_desc_ar[]" id="itemSpecDesc" class="form-control" placeholder="Item specification description (Arabic)" required="true"></div><div class="col-md-1"><button class="btn btn-danger btn-icon  btn-icon-mini btn-round g-bg-soundcloud" onclick="return removeSpecification(' + itemSpecID + ')"><i class="zmdi zmdi-minus"></i></button></div></div>');
    return true;
});

function removeSpecification(itemSpecID) {
    $('.itemSpecRow-' + itemSpecID).remove();
    if (itemSpecID == 1) {
        $('#spec-desc').show();
    }
    return false;
}

function toUcWords(str) {
    var convertedStr = str.toLowerCase().replace(/\b[a-z]/g, function (letter) {
        return letter.toUpperCase();
    });
    return convertedStr;
}

$('input[type=radio][name=item_group]').on('change', function () {
    if (this.value == 1) {
        $('#dimenDesc').html('Image Dimension: 1200 x 880 px');
    }
    else if (this.value == 2) {
        $('#dimenDesc').html('Image Dimension: 1200 x 944 px');
    }
});

function checkCKeditorContent() {
    $('.itemDescErr').html('');
    $('.itemDescArErr').html('');
    var proDescLength = CKEDITOR.instances['itemDescription'].getData().replace(/<[^>]*>/gi, '').length;
    if (!proDescLength) {
        $("html, body").animate({ scrollTop: 500 }, "slow");
        $('.itemDescErr').html('*Please enter item description');
        return false;
    }
    var proDescArLength = CKEDITOR.instances['itemDescriptionAr'].getData().replace(/<[^>]*>/gi, '').length;
    if (!proDescArLength) {
        $("html, body").animate({ scrollTop: 700 }, "slow");
        $('.itemDescArErr').html('*Please enter item arabic description');
        return false;
    }
    return true;
}

/** Vendor Store Status Update */

function blockunblockItem(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-item/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Item */

function deleteItem(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-item/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

/** Delete Item Image */

$('.remove-img').on("click", function () {
    var imgID = $(this).attr('data-id');
    var imgName = $(this).attr('data-name');
    if (confirm('Are you sure you want to delete this?')) {
        var Path = domainScriptPath + 'admin/delete-item-image';
        $.ajax({
            url: Path,
            type: 'POST',
            data: { 'image_id': imgID, 'image_name': imgName },
            success: function (data) {
                location.reload();
            },
            errors: function () {
                alert("Oops!, Something went wrong. Please try later.");
            }
        });
    }
});

/** Add Variants */

$('#attribute_type').on('change', function () {
    $('#attributeType').html('');
    var itemVariantID = $('.attributeType').length + 0;
    var attrType = $(this).val().split('_')[1];
    if (attrType == 0) {
        $('#attributeType').append('<div class="row clearfix attributeType" id="itemVariantRow-' + itemVariantID + '"><div class="col-md-3"><label for="variantName">Variant Name <span class="col-red">*</span></label><div class="form-group"><input type="text" name="variant_name[]" id="variantName" class="form-control" placeholder="Variant Name" required="true"></div></div><div class="col-md-3"><label for="variantNameAr">Variant Name (Arabic)<span class="col-red">*</span></label><div class="form-group"><input type="text" name="variant_name_ar[]" id="variantNameAr" class="form-control" placeholder="Variant Name (Arabic)" required="true"></div></div><div class="col-md-3"><label for="variantDesc">Variant Value<span class="col-red">*</span></label><div class="form-group"><input type="text" name="variant_desc[]" id="variantDesc" class="form-control" placeholder="Variant Value" required="true"></div></div><div class="col-md-3"><label for="removeVariant">&nbsp;</label><div class="form-group"><button class="btn btn-danger btn-icon  btn-icon-mini btn-round g-bg-soundcloud" onclick="return removeItemVariant(' + itemVariantID + ')"><i class="zmdi zmdi-minus"></i></button></div></div></div><div class="row clearfix" id="add-variant-type"><div class="col-md-2"><div class="form-group float-left"><button class="btn btn-success btn-icon btn-icon-mini btn-round g-bg-cgreen" onclick="return addNewVariant()"><i class="zmdi zmdi-plus"></i></button></div></div><div class="col-md-10">&nbsp;</div></div>');
    } else {
        $('#attributeType').append('<div class="row clearfix attributeType" id="itemVariantRow-' + itemVariantID + '"><div class="col-md-3"><label for="variantName">Variant Name <span class="col-red">*</span></label><div class="form-group"><input type="text" name="variant_name[]" id="variantName" class="form-control" placeholder="Variant Name" required="true"></div></div><div class="col-md-3"><label for="variantNameAr">Variant Name (Arabic)<span class="col-red">*</span></label><div class="form-group"><input type="text" name="variant_name_ar[]" id="variantNameAr" class="form-control" placeholder="Variant Name (Arabic)" required="true"></div></div><div class="col-md-3"><label for="variantColor">Color<span class="col-red">*</span></label><div class="form-group"><div class="radio inlineblock"><input type="color" value="#4CAF50" name="variant_color[]" onchange="variantColor(this.value)" class="with-gap"></div><div class="radio inlineblock"><input type="text" class="form-control with-gap" spellcheck="false" placeholder="Color" id="variantColorText" readonly value="#823fc6"></div></div></div><div class="col-md-3"><label for="removeVariant">&nbsp;</label><div class="form-group"><button class="btn btn-danger btn-icon  btn-icon-mini btn-round g-bg-soundcloud" onclick="return removeItemVariant(' + itemVariantID + ')"><i class="zmdi zmdi-minus"></i></button></div></div></div><div class="row clearfix" id="add-variant-type"><div class="col-md-2"><div class="form-group float-left"><button class="btn btn-success btn-icon btn-icon-mini btn-round g-bg-cgreen" onclick="return addNewVariant()"><i class="zmdi zmdi-plus"></i></button></div></div><div class="col-md-10">&nbsp;</div></div>');
    }
    return true;
});

/** Add Variants Color Picker */

function variantColor(color = "") {
    document.getElementById("variantColorText").value = color;
}

/** Add Variants - Dynamic Property */

function addNewVariant() {
    var itemVariantID = $('.attributeType').length + 0;
    var attrType = $('#attribute_type').val().split('_')[1];
    if (attrType == 0) {
        $('#add-variant-type').before('<div class="row clearfix attributeType" id="itemVariantRow-' + itemVariantID + '"><div class="col-md-3"><label for="variantName">Variant Name <span class="col-red">*</span></label><div class="form-group"><input type="text" name="variant_name[]" id="variantName" class="form-control" placeholder="Variant Name" value="" required="true"></div></div><div class="col-md-3"><label for="variantNameAr">Variant Name (Arabic)<span class="col-red">*</span></label><div class="form-group"><input type="text" name="variant_name_ar[]" id="variantNameAr" class="form-control" placeholder="Variant Name (Arabic)" value="" required="true"></div></div><div class="col-md-3"><label for="variantDesc">Variant Value<span class="col-red">*</span></label><div class="form-group"><input type="text" name="variant_desc[]" id="variantDesc" class="form-control" placeholder="Variant Value" required="true"></div></div><div class="col-md-3"><label for="removeVariant">&nbsp;</label><div class="form-group"><button class="btn btn-danger btn-icon  btn-icon-mini btn-round g-bg-soundcloud" onclick="return removeItemVariant(' + itemVariantID + ')"><i class="zmdi zmdi-minus"></i></button></div></div></div>');
    } else {
        $('#add-variant-type').before('<div class="row clearfix attributeType" id="itemVariantRow-' + itemVariantID + '"><div class="col-md-3"><label for="variantName">Variant Name <span class="col-red">*</span></label><div class="form-group"><input type="text" name="variant_name[]" id="variantName" class="form-control" placeholder="Variant Name" value="" required="true"></div></div><div class="col-md-3"><label for="variantNameAr">Variant Name (Arabic)<span class="col-red">*</span></label><div class="form-group"><input type="text" name="variant_name_ar[]" id="variantNameAr" class="form-control" placeholder="Variant Name (Arabic)" value="" required="true"></div></div><div class="col-md-3"><label for="variantColor">Color<span class="col-red">*</span></label><div class="form-group"><div class="radio inlineblock"><input type="color" value="#4CAF50" name="variant_color[]" onchange="variantColor(this.value)" class="with-gap"></div><div class="radio inlineblock"><input type="text" class="form-control with-gap" spellcheck="false" placeholder="Color" id="variantColorText" readonly value="#823fc6"></div></div></div><div class="col-md-3"><label for="removeVariant">&nbsp;</label><div class="form-group"><button class="btn btn-danger btn-icon  btn-icon-mini btn-round g-bg-soundcloud" onclick="return removeItemVariant(' + itemVariantID + ')"><i class="zmdi zmdi-minus"></i></button></div></div></div>');
    }
    return false;
}

/** Remove Dynamic Variant */

function removeItemVariant(itemVariantID) {
    $('#itemVariantRow-' + itemVariantID).remove();
    return false;
}

/** Update Item Variant Status */

function blockunblockItemVariant(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-item-variant/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete Item Attribute */

function deleteItemVariant(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-item-attribute/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}

$('.editVariant').on('click', function () {
    var modal = $('#editvariantModal');
    var item = $(this).data('item');
    var content = ``;
    if (item.attribute_type == 0) {
        content = `<div class="row clearfix">
                        <div class="col-md-12">
                            <label for="variantName">Variant Name <span class="col-red">*</span></label>
                            <div class="form-group">
                                <input type="text" name="variant_name" id="variantName" class="form-control" placeholder="Variant Name" value="" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-12">
                            <label for="variantNameAr">Variant Name (Arabic)<span class="col-red">*</span></label>
                            <div class="form-group">
                                <input type="text" name="variant_name_ar" id="variantNameAr" class="form-control" placeholder="Variant Name (Arabic)" value="" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-12">
                            <label for="variantDesc">Variant Value<span class="col-red">*</span></label>
                            <div class="form-group">
                                <input type="text" name="variant_desc" id="variantDesc" class="form-control" placeholder="Variant Value" required="true">
                            </div>
                        </div>
                    </div>`;
        modal.find('.modal-body').html(content);
        modal.find('input[name=attr_type]').val(0);
        modal.find('input[name=variant_name]').val(item.variant_name.en);
        modal.find('input[name=variant_name_ar]').val(item.variant_name.ar);
        modal.find('input[name=variant_desc]').val(item.attribute_value);
    } else if (item.attribute_type == 1) {
        content = `<div class="row clearfix">
                        <div class="col-md-12">
                            <label for="variantName">Variant Name <span class="col-red">*</span></label>
                            <div class="form-group">
                                <input type="text" name="variant_name" id="variantName" class="form-control" placeholder="Variant Name" value="" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-12">
                            <label for="variantNameAr">Variant Name (Arabic)<span class="col-red">*</span></label>
                            <div class="form-group">
                                <input type="text" name="variant_name_ar" id="variantNameAr" class="form-control" placeholder="Variant Name (Arabic)" value="" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-12">
                            <label for="variantColor">Color<span class="col-red">*</span></label>
                            <div class="form-group">
                                <div class="radio inlineblock">
                                    <input type="color" value="#4CAF50" name="variant_color" onchange="variantColor(this.value)" class="with-gap">
                                </div>
                                <div class="radio inlineblock">
                                    <input type="text" name="variant_color_txt" class="form-control with-gap" spellcheck="false" placeholder="Color" id="variantColorText" readonly value="#823fc6">
                                </div>
                            </div>
                        </div>
                    </div>`;
        modal.find('.modal-body').html(content);
        modal.find('input[name=attr_type]').val(1);
        modal.find('input[name=variant_name]').val(item.variant_name.en);
        modal.find('input[name=variant_name_ar]').val(item.variant_name.ar);
        modal.find('input[name=variant_color]').val(item.attribute_value);
        modal.find('input[name=variant_color_txt]').val(item.attribute_value);
    } else if (item.attribute_type == 2) {
        content = `<div class="row clearfix">
                        <div class="col-md-12">
                            <label for="variantName">Variant Name <span class="col-red">*</span></label>
                            <div class="form-group">
                                <input type="text" name="variant_name" id="variantName" class="form-control" placeholder="Variant Name" value="" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-12">
                            <label for="variantNameAr">Variant Name (Arabic)<span class="col-red">*</span></label>
                            <div class="form-group">
                                <input type="text" name="variant_name_ar" id="variantNameAr" class="form-control" placeholder="Variant Name (Arabic)" value="" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-12">
                            <label for="variantColor">Color<span class="col-red">*</span></label>
                            <div class="form-group">
                                <div class="radio inlineblock">
                                    <input type="color" value="#4CAF50" name="variant_color" onchange="variantColor(this.value)" class="with-gap">
                                </div>
                                <div class="radio inlineblock">
                                    <input type="text" name="variant_color_txt" class="form-control with-gap" spellcheck="false" placeholder="Color" id="variantColorText" readonly value="#823fc6">
                                </div>
                            </div>
                        </div>
                    </div>`;
        modal.find('.modal-body').html(content);
        modal.find('input[name=attr_type]').val(2);
        modal.find('input[name=variant_name]').val(item.variant_name.en);
        modal.find('input[name=variant_name_ar]').val(item.variant_name.ar);
        modal.find('input[name=variant_color]').val(item.attribute_value);
        modal.find('input[name=variant_color_txt]').val(item.attribute_value);
    } else {
        modal.find('.modal-body').html(content);
    }
    var form = document.getElementById('promotion-form');
    form.action = domainScriptPath + 'admin/update-item-variant/' + item.id + '/' + item.item_rcin;
    modal.modal('show');
});

/** Add Inventory - Fetch Vendor Based Store Data */

$('#item_vendor').on('change', function () {
    var html = "";
    $.ajax({
        type: "get",
        url: domainScriptPath + 'admin/fetch-stores',
        data: { vendorID: $(this).val() },
        success: function (data) {
            $('#item_store').empty().html($("<option selected></option>").attr("value", '').text('Choose Store'));
            if ($.trim(data)) {
                $.each(data, function (key, value) {
                    $('#item_store').append($("<option></option>").attr("value", value.id).text(value.store_name.en));
                });
                $("#item_store").selectpicker("refresh");
            } else {
                $('#item_store').html($("<option></option>").attr("value", '').text('--- Select Vendor First ---'));
            }
        },
        error: function () {
            console.warn("Problem in fetching information");
        }
    });
});

/** Edit Inventory - Fetch Inventory Vendor Based Store Data */

$('#inventory_vendor').on('change', function () {
    var item_ID = $('#itemID').val();
    $.ajax({
        type: "post",
        url: domainScriptPath + 'admin/fetch-inventory-stores',
        data: { vendorID: $(this).val(), itemID: item_ID },
        success: function (data) {
            $('#inventory_store').empty().html($("<option selected></option>").attr("value", '').text('Choose Store'));
            if ($.trim(data)) {
                $.each(data, function (key, value) {
                    var data = JSON.parse(value.store_name);
                    $('#inventory_store').append($("<option></option>").attr("value", value.id).text(data.en));
                });
                $("#inventory_store").selectpicker("refresh");
            } else {
                $('#inventory_store').html($("<option></option>").attr("value", '').text('--- Select Vendor First ---'));
            }
        },
        error: function () {
            console.warn("Problem in fetching information");
        }
    });
});

/** Edit Inventory - Fetch Inventory Attribute Based On Store Data */

$('#inventory_store').on('change', function () {
    var item_ID = $('#itemID').val();
    var is_variant = $('#isVariant').val();
    console.log(is_variant);
    if (is_variant == 1) {
        $.ajax({
            type: "post",
            url: domainScriptPath + 'admin/fetch-inventory-attributes',
            data: { vendorID: $('#inventory_vendor').val(), itemID: item_ID, storeID: $(this).val() },
            success: function (data) {
                $('#inventory_attribute').empty().html($("<option selected></option>").attr("value", '').text('Choose Attribute'));
                if ($.trim(data)) {
                    $.each(data, function (key, value) {
                        var data = JSON.parse(value.variant_name);
                        $('#inventory_attribute').append($("<option></option>").attr("value", value.id).text(data.en));
                    });
                    $("#inventory_attribute").selectpicker("refresh");
                } else {
                    $('#inventory_attribute').html($("<option></option>").attr("value", '').text('--- Select Store First ---'));
                }
            },
            error: function () {
                console.warn("Problem in fetching information");
            }
        });
    } else {
        $.ajax({
            type: "post",
            url: domainScriptPath + 'admin/fetch-inventory-properties',
            data: { vendorID: $('#inventory_vendor').val(), itemID: item_ID, storeID: $('#inventory_store').val(), attrID: 0 },
            success: function (data) {
                $('#inventoryID').val(data[0].id);
                seedInventoryProp(data);
            },
            error: function () {
                console.warn("Problem in fetching information");
            }
        });
    }
});

/** Edit Inventory - Fetch Inventory Attribute Based On Other Property */

$('#inventory_attribute').on('change', function () {
    var item_ID = $('#itemID').val();
    $.ajax({
        type: "post",
        url: domainScriptPath + 'admin/fetch-inventory-properties',
        data: { vendorID: $('#inventory_vendor').val(), itemID: item_ID, storeID: $('#inventory_store').val(), attrID: $(this).val() },
        success: function (data) {
            $('#inventoryID').val(data[0].id);
            seedInventoryProp(data);
        },
        error: function () {
            console.warn("Problem in fetching information");
        }
    });
});

/** To Fill Inventory Property */

function seedInventoryProp(data) {
    $('#base_price').val(data[0].base_price);
    $('#selling_price').val(data[0].selling_price);
    $('#quantity').val(data[0].quantity);
    $('#discount').val(data[0].discount);
    $('#member_discount').val(data[0].member_discount);
    $('#member_selling_price').val(data[0].member_selling_price);
}

/** Update Vendor Inventory Status */

function blockunblockInventory(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-vendor-inventory/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Check Vendor Inventory Status */

$('.addInventory').on('click', function (e) {
    e.preventDefault();
    $('#inventory-error').html('');
    var vendor_ID = $('#item_vendor').val();
    var item_ID = $('#itemID').val();
    var is_variant = $('#isVariant').val();
    var store_ID = $('#item_store').val();
    var attr_ID = (is_variant == 1) ? $('#attribute').val() : 0;
    var base_price = $('#base_price').val();
    var sell_price = $('#selling_price').val();
    var quantity = $('#quantity').val();
    if (vendor_ID === '' || store_ID === '' || base_price === '' || base_price === 0 || sell_price === '' || sell_price === 0 || quantity === '' || quantity === 0) {
        $('#inventory-error').html('Please fill valid information to proceed.');
    } else {
        $.ajax({
            type: "post",
            url: domainScriptPath + 'admin/check-vendor-inventory',
            data: { vendorID: vendor_ID, itemID: item_ID, storeID: store_ID, attrID: attr_ID },
            success: function (data) {
                if (parseInt(data) == 0) {
                    $('form#add-item-inventory').trigger('submit');
                } else {
                    $('#inventory-error').html('Sorry!, The same inventory already available.');
                }
            },
            error: function () {
                console.warn("Problem in fetching information");
            }
        });
    }
});

/** Calculate Price Information Based on Discount - Max-discount = 80% */

$('#base_price').on('keyup', function () {
    calcPrice();
    calcMemberPrice();
});

$('#discount').on('keyup', function () {
    calcPrice();
});

$('#member_discount').on('keyup', function () {
    calcMemberPrice();
});

function calcPrice() {
    $('#inventory-error').html('');
    let attrDiscount = parseInt($('#discount').val());
    let base_price = $('#base_price').val();

    if (attrDiscount > 80) {
        $('#discount').val('');
        $('#selling_price').val('');
        $('#inventory-error').html('Sorry!, Item discount should be less than equal to 80%');
    } else {
        if (attrDiscount !== '' && base_price === '') {
            $('#discount').val('');
            $('#inventory-error').html('Please enter base price.');
        }
        if (attrDiscount !== '' && !isNaN(attrDiscount)) {
            var sellPrice = ((base_price / 100) * attrDiscount);
            sellPrice = (base_price - sellPrice);
            if (Math.round(sellPrice) !== sellPrice) {
                sellPrice = sellPrice.toFixed(2);
            }
            $('#selling_price').val(sellPrice);
        } else {
            $('#selling_price').val('');
        }
    }
}

function calcMemberPrice() {
    $('#inventory-error').html('');
    let attrMemDiscount = parseInt($('#member_discount').val());
    let base_price = $('#base_price').val();
    if (attrMemDiscount > 80) {
        $('#member_discount').val('');
        $('#member_selling_price').val('');
        $('#inventory-error').html('Sorry!, Item member discount should be less than equal to 80%');
    } else {
        if (attrMemDiscount !== '' && base_price === '') {
            $('#member_discount').val('');
            $('#inventory-error').html('Please enter base price.');
        }
        if (attrMemDiscount !== '' && !isNaN(attrMemDiscount)) {
            var sellPrice = ((base_price / 100) * attrMemDiscount);
            sellPrice = (base_price - sellPrice);
            if (Math.round(sellPrice) !== sellPrice) {
                sellPrice = sellPrice.toFixed(2);
            }
            $('#member_selling_price').val(sellPrice);
        } else {
            $('#member_selling_price').val('');
        }
    }
}

/** Social Media Highlights */

$(function () {
    $('.sm-review-highlight').on('change', function () {
        var status = $(this).prop('checked') == true ? 1 : 0;
        var id = $(this).data('id');
        $.ajax({
            type: "post",
            url: domainScriptPath + 'admin/highlight-sm-review',
            data: { 'status': status, 'id': id },
            success: function () {
                location.reload();
            }
        });
    })
})

/** Check Item Promotion Status */

$('.highlightModalSign').on('click', function () {
    var $el = $(this);
    var $item = $el.data('item');
    var $itemPromoRef = $el.data('highlight-ref');
    var $itemPromoRefStat = $el.data('highlight-status');
    $('#highlightItem').val($item);
    $('#highlightItemRef').val($itemPromoRef);
    $('#highlight-error').html('');
    var isExPromo = $el.data('highlight');
    if (isExPromo != 0) {
        $.ajax({
            type: "post",
            url: domainScriptPath + 'admin/check-item-promotions',
            data: { itemPromoRef: $itemPromoRef },
            success: function (data) {
                if (data.length > 0) {
                    $('#promotion-form').trigger("reset");
                    $('.action-hidden').show();
                    if ($itemPromoRefStat == 1) {
                        $('#highlightActionEdit').trigger('click');
                    } else if ($itemPromoRefStat == 0) {
                        $('#highlightActionStop').trigger('click');
                    } else if ($itemPromoRefStat == '') {
                        $('#highlightActionNew').trigger('click');
                    }
                    if ($.trim(data)) {
                        $.each(data, function (key, value) {
                            if (value.promotion_id == 1) {
                                $('#flash-deals').trigger('click');
                                $('#flash-startdate').val(value.start_date);
                                $('#flash-enddate').val(value.end_date);
                            } else if (value.promotion_id == 2) {
                                $('#weekly-deals').trigger('click');
                                $('#weekly-startdate').val(value.start_date);
                                $('#weekly-enddate').val(value.end_date);
                            } else if (value.promotion_id == 3) {
                                $('#monthly-deals').trigger('click');
                                $('#monthly-startdate').val(value.start_date);
                                $('#monthly-enddate').val(value.end_date);
                            } else if (value.promotion_id == 4) {
                                $('#exclusive-deals').trigger('click');
                                $('#exclusive-startdate').val(value.start_date);
                                $('#exclusive-enddate').val(value.end_date);

                            } else if (value.promotion_id == 5) {
                                $('#members-deals').trigger('click');
                                $('#members-startdate').val(value.start_date);
                                $('#members-enddate').val(value.end_date);
                            } else if (value.promotion_id == 6) {
                                $('#best-seller').trigger('click');
                            }
                        });
                    }
                }
                return true;
            },
            error: function () {
                console.warn("Problem in fetching information");
            }
        });
    } else {
        $('#highlightActionNew').trigger('click');
        $('#promotion-form').trigger("reset");
        $('.deals').hide();
        $('.members-deals').hide();
        $('.action-hidden').hide();
        return true;
    }
});

/** Update Promotion Information */

$('.itemHighlightSub').on('click', function (e) {
    e.preventDefault();
    $('#highlight-error').html('');
    var numberDealsChecked = $('input[name="promotion_deals[]"]:checked').length;
    if (numberDealsChecked == 0 && $('.members-deals').is(":not(:checked)")) {
        $('#highlight-error').html('Warning! Please choose anyone of the highlight option.')
    } else {
        $('#promotion-form').trigger('submit');
    }
});

/** Customer Status Update */

function blockunblockCustomer(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-customer/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Customer Status Update */

function affiliateStatUpdate(id, type) {
    var Path = domainScriptPath + 'admin/affiliate-user-status/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Affiliate User List View More */

$('.affUserModalSign').on('click', function () {
    $('.modal-body').html('');
    var $el = $(this);
    var uType = $el.data('user-type');
    var uName = $el.data('user-name');
    var uEmail = $el.data('user-email');
    var uPhone = $el.data('user-phone');
    var uCountry = $el.data('country');
    var uCreate = $el.data('create');
    var uUpdate = $el.data('update');
    var modalBody = "<table class='table table-striped'><tr><td>User Category</td><td>" + uType + "</td></tr><tr><td>User Name</td><td>" + uName + "</td></tr><tr><td>User Email</td><td>" + uEmail + "</td></tr><tr><td>User Phone</td><td>" + uPhone + "</td></tr><tr><td>User Country</td><td>" + uCountry + "</td></tr><tr><td>Register At</td><td>" + uCreate + "</td></tr><tr><td>Modified At</td><td>" + uUpdate + "</td></tr></table>";
    $('.modal-body').html(modalBody);
});

/** Enquiry List View More */

$('.enquirySignModal').on('click', function () {
    $('.modal-body').html('');
    var $el = $(this);
    var uName = $el.data('user-name');
    var uEmail = $el.data('user-email');
    var uPhone = $el.data('user-phone');
    var uComments = $el.data('message');
    var uCreate = $el.data('create');
    var modalBody = "<table class='table table-striped'><tr><td>User Name</td><td>" + uName + "</td></tr><tr><td>User Email</td><td>" + uEmail + "</td></tr><tr><td>User Phone</td><td>" + uPhone + "</td></tr><tr><td>Message</td><td>" + uComments + "</td></tr><tr><td>Register At</td><td>" + uCreate + "</td></tr></table>";
    $('.modal-body').html(modalBody);
});

/** Customer Subscription Status Update */

function updateSubscriptionStat(id, type) {
    var Path = domainScriptPath + 'admin/update-subscription-status/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Roles Check All */

$('#role-all').on('click', function () {
    if ($(this).is(':checked') == true) {        
        $('.permission-list').prop("checked", true);
    } else {        
        $('.permission-list').prop("checked", false);
    }
});

function checkRoleAllBtn() {
    var checked_checkbox = $('input[type=checkbox]:checked').not( "#role-all" ).length;
    var total_checkbox = $('input[type=checkbox]').not( "#role-all" ).length;
    if(checked_checkbox == total_checkbox){
        $('#role-all').prop("checked","checked");
    }else{
        $('#role-all').prop("checked",false);
    }
}

$('input[type=checkbox]').not( "#role-all" ).on('click',function(){
    checkRoleAllBtn();
});

/** User Status Update */

function blockunblockUser(id, type) {
    var Path = domainScriptPath + 'admin/blockunblock-user/' + id + '/' + type;
    $.get(Path, {
    }, function (response) {
        if (response > 0)
            location.reload();
        else
            alert("Oops!, Something went wrong. Please try later.");
    });
}

/** Delete User */

function deleteUser(id) {
    if (id && confirm('Are you sure want to delete?')) {
        var Path = domainScriptPath + 'admin/delete-user/' + id;
        $.get(Path, {
        }, function (response) {
            if (response > 0)
                location.reload();
            else
                alert("Oops!, Something went wrong. Please try later.");
        });
    }
    return;
}