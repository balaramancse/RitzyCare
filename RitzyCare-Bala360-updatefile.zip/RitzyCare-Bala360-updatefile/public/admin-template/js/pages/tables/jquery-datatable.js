$(function () {
    //$('.js-basic-example').DataTable();

    //Exportable table
    $('.js-exportable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        drawCallback: function() {
		  	var hasRows = this.api().rows({ filter: 'applied' }).data().length > 0;
		  	$('.dt-buttons')[0].style.visibility = hasRows ? 'visible' : 'hidden'
		}
    });
});