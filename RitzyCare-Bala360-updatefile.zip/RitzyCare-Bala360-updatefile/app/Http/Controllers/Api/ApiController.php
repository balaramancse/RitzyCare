<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use App\Models\Brand;
use App\Models\Category;
use App\Models\CompetitionOffer;
use App\Models\Faq;
use App\Models\ItemInventory;
use App\Models\ItemPromotions;
use App\Models\Items;
use App\Models\ItemViewHistory;
use App\Models\ModuleSettings;
use App\Models\Nationality;
use App\Models\PromoAds;
use App\Models\PromoVideos;
use App\Models\Rating;
use App\Models\Settings;
use App\Models\SocialMediaReviews;
use App\Models\StaticPages;
use App\Models\User;
use App\Models\UserShippingAddress;
use App\Models\UserWishList;
use App\Models\VideoReview;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Lang;

class ApiController extends Controller
{

    public function __construct(Request $request)
    {
        $this->data = array();
    }

    /**
     * @OA\Get(
     *   path="/checkout-settings",
     *   tags={"Application Settings"},
     *   summary="To get application settings",
     *   operationId="checkout-settings",
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not Request"
     *   ),
     * )
     **/

    /** Get Application Settings */

    public function getCheckOutSettings(Request $request)
    {
        $genSettings = Settings::first();
        $modSettings = ModuleSettings::first();

        $delModes = array('express_delivery' => $genSettings->express_delivery, 'express_delivery_hrs' => $genSettings->express_delivery_hrs, 'express_delivery_fee' => $genSettings->express_delivery, 'standard_delivery' => $genSettings->standard_delivery, 'standard_delivery_hrs' => $genSettings->standard_delivery_hrs, 'standard_delivery_fee' => $genSettings->standard_delivery, 'schedule_delivery' => $genSettings->scheduled_delivery, 'schedule_delivery_fee' => $genSettings->scheduled_delivery);

        $payment = array('is_cod' => $modSettings->cod, 'is_paypal' => $modSettings->paypal, 'is_creditcard' => $modSettings->is_credit_card, 'is_debitcard' => $modSettings->is_debit_card, 'payment_mode' => $genSettings->payment_mode, 'payment_mode_desc' => (($genSettings->payment_mode == 1) ? "Live" : "Sandbox"));

        $this->data['settings'] = array('delivery_modes' => $delModes, 'payment_modes' => $payment);
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     ** path="/banner-list",
     *   tags={"Banner List"},
     *   summary="To get all available banner images",
     *   operationId="banner-list",
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=false,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=false,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 20,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not Request"
     *   ),
     *)
     **/

    /** Get Banner Images */

    public function getPromoBanners(Request $request)
    {
        $bannerCount = Banner::where(['status' => 1, 'app_type' => 0])->count();
        $bannerList = Banner::where(['status' => 1, 'app_type' => 0])->offset($request->offset)->limit($request->limit)->select('id', 'image_name', 'image', 'image_text', 'redirect_url', 'app_type')->get();
        $this->data['total_records'] = $bannerCount;
        $this->data['image_root'] = cdn('uploads/banners');
        $this->data['banners'] = $bannerList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     ** path="/video-list",
     *   tags={"Video List"},
     *   summary="To get all available videos",
     *   operationId="video-list",
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=false,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=false,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 20,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get Promo Videos */

    public function getPromoVideos(Request $request)
    {
        $offset = 0;
        $limit = 20;
        if (isset($request->offset)) {
            $offset = $request->offset;
        }
        if (isset($request->limit)) {
            $limit = $request->limit;
        }
        $videoCount = PromoVideos::where(['status' => 1, 'app_type' => 0])->count();
        $videoList = PromoVideos::where(['status' => 1, 'app_type' => 0])->offset($request->offset)->limit($request->limit)->select('id', 'video_title', 'video_link', 'app_type')->get();
        $this->data['total_records'] = $videoCount;
        $this->data['videos'] = $videoList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
       
    }

 
    public function getmemberDeals(Request $request)
    { 
        $reviews = SocialMediaReviews::where(['status' => 1, 'app_type' => 0])->get();
        $reviewCount = $reviews->count();
        $avg_rating = $reviews->avg('rating');
        $reviewList = SocialMediaReviews::where(['status' => 1, 'app_type' => 0])->offset($request->offset)->limit($request->limit)->orderBy('is_higlight', 'desc')->select('id', 'name', 'image', 'posted_date', 'media_type', 'rating', 'comments', 'is_higlight as is_highlight', 'app_type')->get();
        $this->data['total_records'] = $reviewCount;
        $this->data['average_rating'] = $avg_rating;
        $this->data['social_links'] = config('ritzycare.social_links');
        $this->data['image_root'] = cdn('uploads/sm-reviews');
        $this->data['no_image_root'] = cdn('uploads/no-images');
        $this->data['reviews'] = $reviewList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
   
    }

    
    /**
     * @OA\Get(
     ** path="/fetch-deals-list",
     *   tags={"Fetch Deals"},
     *   summary="To get respective deals listing",
     *   operationId="fetch-deals-list",
     *
     *   @OA\Parameter(
     *      name="list_category",
     *      in="query",
     *      required=true,
     *      description="1 - Flash, 2 - Weekly, 3 - Monthly, 4 - Exclusive, 5 - Members, 6 - Best Sellers",
     *      @OA\Schema(
     *         type = "integer",
     *         enum = {1,2,3,4,5,6},
     *         default = 1
     *      )
     *   ),
     *  
     *   @OA\Parameter(
     *      name="uuid",
     *      in="query",
     *      required=false,
     *      description="User Id",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="sort_by",
     *      in="query",
     *      required=false,
     *      description="0 - Popular Item, 1 - Low to High, 2 - High to Low",
     *      @OA\Schema(
     *         type = "integer",
     *         enum = {0,1,2},
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=false,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=false,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 20,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *
     *)
     **/

    /** Get Promo Deals */
    /** Get Weekly Deals, Flash Deals, Monthly Dels, Exclusive Deals*/

    public function getDealsList(Request $request)
    {
        $sortBy = "item_promotions.id";
        if ($request->sort_by == 0) {
            $sortBy = "item_inventories.selling_price";
        } else if ($request->sort_by == 1) {
            $sortBy = "item_inventories.selling_price ASC";
        } else if ($request->sort_by == 2) {
            $sortBy = "item_inventories.selling_price DESC";
        }

        $itemCount = ItemPromotions::join('items', 'items.id', 'item_promotions.item_id')->where(['items.status' => 1, 'item_promotions.status' => 1, 'items.is_active' => 1, 'is_expired' => 1, 'promotion_id' => $request->list_category])->count();
        $itemList = ItemPromotions::with(['itemInfo' => function ($q) {$q->select('id', 'item_name', 'item_rcin', 'item_summary', 'item_group', 'category_id', 'slug', 'is_inventory_track', 'is_variants', 'app_type', 'status', 'is_active'); $q->where(['status' => 1, 'is_active' => 1]);}, 'ItemParentImage','wishList' => function($q) use ($request) { $q->where('user_id',$request->uuid); }])->leftjoin('item_inventories', 'item_inventories.item_id', 'item_promotions.item_id')->leftjoin('items', 'items.id', 'item_promotions.item_id')->leftjoin('categories', 'categories.id', 'items.category_id')->where(['item_promotions.status' => 1, 'is_expired' => 1, 'promotion_id' => $request->list_category, 'item_inventories.status' => 1])->select('item_promotions.item_id', 'promotion_id', 'start_date', 'end_date', 'is_expired', 'item_inventories.base_price', 'item_inventories.selling_price', 'item_inventories.discount', 'item_inventories.member_discount', 'item_inventories.member_selling_price', 'categories.category_name')->orderByRaw($sortBy)->groupBy('item_promotions.item_id')->limit($request->limit)->offset($request->offset)->get();
        $this->data['total_records'] = $itemCount;
        $this->data['image_root'] = cdn('uploads/items');
        $this->data['no_image_root'] = cdn('uploads/no-images');
        $this->data['currency_code'] = 'QAR';
        $this->data['deals_list'] = $itemList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }



    /**
     * 
     * @OA\Get(
     ** path="/social-media-reviews",
     *   tags={"Customer Reviews"},
     *   summary="Fetch social media customer reviews",
     *   operationId="social-media-reviews",
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=false,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=false,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 4,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not Request"
     *   ),
     *)
     **/

    /** Get Social Media Reviews */

    public function getSocialMediaReviews(Request $request)
    {
        $reviews = SocialMediaReviews::where(['status' => 1, 'app_type' => 0])->get();
        $reviewCount = $reviews->count();
        $avg_rating = $reviews->avg('rating');
        $reviewList = SocialMediaReviews::where(['status' => 1, 'app_type' => 0])->offset($request->offset)->limit($request->limit)->orderBy('is_higlight', 'desc')->select('id', 'name', 'image', 'posted_date', 'media_type', 'rating', 'comments', 'is_higlight as is_highlight', 'app_type')->get();
        $this->data['total_records'] = $reviewCount;
        $this->data['average_rating'] = $avg_rating;
        $this->data['social_links'] = config('ritzycare.social_links');
        $this->data['image_root'] = cdn('uploads/sm-reviews');
        $this->data['no_image_root'] = cdn('uploads/no-images');
        $this->data['reviews'] = $reviewList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     ** path="/video-reviews",
     *   tags={"Customer Reviews"},
     *   summary="Fetch customer video reviews",
     *   operationId="video-reviews",
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=false,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=false,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 4,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not Request"
     *   ),
     *)
     **/

    /** Get Video Reviews */

    public function getVideoReviews(Request $request)
    {

        $offset = 0;
        $limit = 20;
        if (isset($request->offset)) {
            $offset = $request->offset;
        }
        if (isset($request->limit)) {
            $limit = $request->limit;
        }

        $reviewCount = VideoReview::where(['status' => 1, 'app_type' => 0])->count();
        $reviewList = VideoReview::where(['status' => 1, 'app_type' => 0])->offset($request->offset)->limit($request->limit)->orderBy('is_highlight', 'desc')->select('id', 'video_name', 'video_url', 'is_highlight', 'app_type')->get();
        $this->data['total_records'] = $reviewCount;
        $this->data['reviews'] = $reviewList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     ** path="/faq",
     *   tags={"FAQ"},
     *   summary="To get all available FAQ's",
     *   operationId="faq",
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=false,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=false,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 6,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get FAQ List */

    public function getFaqList(Request $request)
    {
        $faqCount = Faq::where(['status' => 1, 'app_type' => 0])->count();
        $faqList = Faq::where(['status' => 1, 'app_type' => 0])->offset($request->offset)->limit($request->limit)->select('id', 'title', 'description')->get();
        $this->data['total_records'] = $faqCount;
        $this->data['faq'] = $faqList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     ** path="/static-pages",
     *   tags={"Static Pages"},
     *   summary="To get all available static pages",
     *   operationId="faq",
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get Static Page List */

    public function getStaticPages()
    {
        $spList = StaticPages::where(['status' => 1, 'app_type' => 0])->select('id', 'page_title', 'page_content', 'slug')->get();
        $this->data['total_records'] = count($spList);
        $this->data['pages'] = $spList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     ** path="/static-page-details",
     *   tags={"Static Page Details"},
     *   summary="To get static page description",
     *   operationId="static-page",
     *
     *   @OA\Parameter(
     *      name="slug",
     *      in="query",
     *      required=true,
     *      description="Page details",
     *      @OA\Schema(
     *         type = "string"
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get Static Page List */

    public function getStaticPageDetails(Request $request)
    {
        $spList = StaticPages::where(['status' => 1, 'app_type' => 0, 'slug' => $request->slug])->select('id', 'page_title', 'page_content', 'slug')->get();
        $this->data['page_info'] = $spList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     ** path="/brand-list",
     *   tags={"Brands"},
     *   summary="To get all available Brands",
     *   operationId="brands",
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=true,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=true,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 20,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get Brand List */

    public function getBrandList(Request $request)
    {
        $brandCount = Brand::where(['status' => 1, 'app_type' => 0])->count();
        $brandList = Brand::where(['status' => 1, 'app_type' => 0])->offset($request->offset)->limit($request->limit)->select('id', 'brand_name', 'image', 'listing_position')->get();
        $this->data['total_records'] = $brandCount;
        $this->data['image_root'] = cdn('uploads/brands');
        $this->data['brands'] = $brandList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     ** path="/category-list",
     *   tags={"Category Listing"},
     *   summary="To get all available Categories",
     *   operationId="category",
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get Category List */

    public function getCategoryList()
    {
        $categotyList = Category::with('subCategories')->where(['status' => 1, 'app_type' => 0, 'main_category_id' => 0])->select('id', 'category_name', 'meta_title', 'meta_keywords', 'meta_description', 'slug')->get();

        $mainCategories = $subCategories = $secSubCategories = $thirdCategories = array();
        if (count($categotyList) > 0) {
            foreach ($categotyList as $cat) {
                if ($cat->subCategories->where('main_category_id', $cat->id)->where('sub_category_id', $cat->id)->count() > 0) {
                    foreach ($cat->subCategories->where('main_category_id', $cat->id)->where('sub_category_id', $cat->id)->where('category_type', 2) as $sub) {
                        foreach ($cat->subCategories->where('main_category_id', $cat->id)->where('sub_category_id', $sub->id)->where('category_type', 3) as $sec) {
                            foreach ($cat->subCategories->where('main_category_id', $cat->id)->where('sub_category_id', $sec->id)->where('category_type', 4) as $third) {
                                $thirdCategories[] = array('id' => $third->id, 'category_name_en' => $third->category_name, 'category_name_ar' => $third->getTranslation('category_name', 'ar'), 'slug' => $third->slug);
                            }
                            $secSubCategories[] = array('id' => $sec->id, 'category_name_en' => $sec->category_name, 'category_name_ar' => $sec->getTranslation('category_name', 'ar'), 'slug' => $sec->slug, 'third_categories' => $thirdCategories);
                            $thirdCategories = array();
                        }
                        $subCategories[] = array('id' => $sub->id, 'category_name_en' => $sub->category_name, 'category_name_ar' => $sub->getTranslation('category_name', 'ar'), 'slug' => $sub->slug, 'sec_sub_categories' => $secSubCategories);
                        $secSubCategories = array();
                    }
                }
                $mainCategories[] = array('id' => $cat->id, 'category_name_en' => $cat->category_name, 'category_name_ar' => $cat->getTranslation('category_name', 'ar'), 'slug' => $cat->slug, 'sub_categories' => $subCategories);
                $subCategories = array();
            }
        }
        $this->data['categories'] = $mainCategories;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     *   path="/promo-ads",
     *   tags={"Promo Ads"},
     *   summary="To get promo Ads",
     *   operationId="category",
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get Promo Ads */

    public function getPromoAds()
    {
        $adsList = PromoAds::where(['status' => 1, 'app_type' => 0])->orderBy('id', 'desc')->limit(2)->select('id', 'ad_title', 'ad_image', 'redirect_type', 'redirect_url', 'start_date', 'end_date', 'slug', 'app_type')->get();
        $this->data['image_root'] = cdn('uploads/ads');
        $this->data['promo_ads'] = $adsList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     ** path="/item-list",
     *   tags={"Products & Service"},
     *   summary="To get product & service list",
     *   operationId="item-list",
     *
     *   @OA\Parameter(
     *      name="search",
     *      in="query",
     *      required=false,
     *      description="Search keywords",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     * 
     *  @OA\Parameter(
     *      name="uuid",
     *      in="query",
     *      required=false,
     *      description="User ID",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="item_type",
     *      in="query",
     *      required=true,
     *      description="0 - Both, 1 - Product, 2 - Service",
     *      @OA\Schema(
     *         type = "integer",
     *         enum = {0,1,2},
     *         default = 1
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="category_type",
     *      in="query",
     *      required=false,
     *      description="1 - Main, 2 - Sub Category, 3 - Sec Sub Category, 4 - Third Category",
     *      @OA\Schema(
     *         type = "integer",
     *         enum = {1,2,3,4},
     *         default = 1
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="category_slug",
     *      in="query",
     *      required=false,
     *      description="Category Slug",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     * 
     *  @OA\Parameter(
     *      name="category_id",
     *      in="query",
     *      required=false,
     *      description="Category Ids - Comma(,) separated",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *    
     *  @OA\Parameter(
     *      name="price_type",
     *      in="query",
     *      required=true,
     *      description="0 - Normal, 1 - Premium",
     *      @OA\Schema(
     *         type = "integer",
     *         enum = {0,1},
     *         default = 0
     *      )
     *   ),
     * 
     *  @OA\Parameter(
     *      name="brand",
     *      in="query",
     *      required=false,
     *      description="Brand Ids - Comma(,) separated",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="min_price",
     *      in="query",
     *      required=false,
     *      description="Price filter min value",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="max_price",
     *      in="query",
     *      required=false,
     *      description="Price filter max value",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="sort_by",
     *      in="query",
     *      required=false,
     *      description="0 - Popular, 1 - Low to High, 2 - High to Low",
     *      @OA\Schema(
     *         type = "integer",
     *         enum = {0,1,2},
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=true,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=true,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 20,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get Item & Service List */

    public function getItemServiceList(Request $request)
    {
        $offset = 0;
        $limit = 20;
        if (isset($request->offset)) {
            $offset = $request->offset;
        }
        if (isset($request->limit)) {
            $limit = $request->limit;
        }

        $item_group = 1;
        if (isset($request->item_type)) {
            if ($request->item_type == 2) {
                $item_group = 2;
            } else if ($request->item_type == 0) {
                $item_group = 0;
            } else if ($request->item_type == 6) { // For Best Seller Listing
                $item_group = '-6';
            }
        }        

        $condition = "items.id > 0";
        if ($request->search != '') {
            $condition .= " AND (items.item_name LIKE '%" . $request->search . "%' OR categories.category_name LIKE '%" . $request->search . "%' OR sub.category_name LIKE '%" . $request->search . "%' OR secsub.category_name LIKE '%" . $request->search . "%' OR third.category_name LIKE '%" . $request->search . "%')";
        }
        if(!$request->list_category){   
            if ($item_group > 0) {
                $condition .= " AND items.item_group='" . $item_group . "' ";
            } else {
                if ($request->category_type != 0) {
                    if ($request->category_type == 1) {
                        $condition .= " AND categories.slug ='" . $request->category_slug . "' ";
                    } else if ($request->category_type == 2) {
                        $condition .= " AND sub.slug ='" . $request->category_slug . "' ";
                    } else if ($request->category_type == 3) {
                        $condition .= " AND secsub.slug ='" . $request->category_slug . "' ";
                    } else if ($request->category_type == 4) {
                        $condition .= " AND third.slug ='" . $request->category_slug . "' ";
                    }
                }
                if($item_group == '-6') {
                    $condition .= " AND item_promotions.promotion_id = '6' ";
                }
            }
        }
        if(isset($request->category_id) && $request->category_id != ''){
            if ($request->category_type == '' || $request->category_type == 4) {
                $condition .= " AND categories.id IN(" .rtrim($request->category_id,',') . ")";
            } else if ($request->category_type == 1) {
                $condition .= " AND sub.id IN(" . rtrim($request->category_id,',') . ")";
            } else if ($request->category_type == 2) {
                $condition .= " AND secsub.id IN(" . rtrim($request->category_id,',') . ")";
            } else if ($request->category_type == 3) {
                $condition .= " AND third.id IN(" . rtrim($request->category_id,',') . ")";
            }
        }
        
        // Deals Js
        if(isset($request->list_category)) {
            $list_category = ['item_promotions.promotion_id' => $request->list_category];
        }
        else {
            $list_category = [];
        }        
        if (isset($request->brand) && $request->brand != '') {
            $condition .= " AND items.brand_id IN(" . rtrim($request->brand, ',') . ")";
        }

        if (isset($request->min_price) || isset($request->max_price)) {
            if($request->price_type == 1) {
                $condition .= " AND item_inventories.member_selling_price BETWEEN '" . $request->min_price . "' AND '" . $request->max_price . "'";
            } else {
                $condition .= " AND item_inventories.selling_price BETWEEN '" . $request->min_price . "' AND '" . $request->max_price . "'";
            }            
        }

        $order_by = "quantity DESC";
        if (isset($request->sort_by)) {
            if ($request->sort_by == 0) {
                $order_by = "quantity DESC";
            } else if ($request->sort_by == 1) {
                $order_by = "selling_price ASC";
            } else if ($request->sort_by == 2) {
                $order_by = "selling_price DESC";
            }
        }
        
        $itemCount = ItemInventory::leftjoin('items', 'items.id', 'item_inventories.item_id')
                        ->join('categories', 'categories.id', 'items.category_id')
                        ->join('categories as sub', 'sub.id', 'items.sub_category_id')
                        ->leftjoin('categories as secsub', 'secsub.id', 'items.sec_subcategory_id')
                        ->leftjoin('categories as third', 'third.id', 'items.third_category_id')
                        ->leftjoin('item_promotions', 'item_promotions.item_id', 'items.id')
                        ->leftjoin('brands', 'brands.id', 'items.brand_id')
                        ->select('items.id', 'brands.id', 'brands.brand_name', 'item_inventories.selling_price', 'item_inventories.member_selling_price')
                        ->where(['items.status' => 1, 'items.is_active' => 1, 'item_promotions.status' => 1, 'item_promotions.is_expired' => 1])
                        ->where($list_category)
                        ->whereRaw($condition)->orderBy('brands.brand_name')->groupBy('item_inventories.item_id')->get();

        $itemList = ItemInventory::with(['ItemParentImage','wishList' => function($q) use ($request) { $q->where('user_id',$request->uuid); }])
                        ->leftjoin('items', 'items.id', 'item_inventories.item_id')
                        ->join('categories', 'categories.id', 'items.category_id')
                        ->join('categories as sub', 'sub.id', 'items.sub_category_id')
                        ->leftjoin('categories as secsub', 'secsub.id', 'items.sec_subcategory_id')
                        ->leftjoin('categories as third', 'third.id', 'items.third_category_id')
                        ->leftjoin('item_promotions', 'item_promotions.item_id', 'items.id')
                        ->leftjoin('brands', 'brands.id', 'items.brand_id')
                        ->select('item_inventories.item_id', 'items.id', 'items.item_name', 'items.item_rcin', 'items.item_summary', 'items.item_group', 'items.category_id','categories.category_name as main_cate_name', 'items.sub_category_id','sub.category_name as sub_cate_name', 'items.sec_subcategory_id','secsub.category_name as secsub_cate_name', 'items.third_category_id', 'third.category_name as third_cate_name', 'items.slug', 'items.is_inventory_track', 'items.is_variants', 'items.app_type', 'item_promotions.start_date', 'item_promotions.end_date', 'item_inventories.base_price', 'item_inventories.selling_price', 'item_inventories.discount', 'item_inventories.member_discount', 'item_inventories.member_selling_price', 'items.brand_id', 'brands.brand_name')
                        ->where(['items.status' => 1, 'items.is_active' => 1, 'item_promotions.status' => 1, 'item_promotions.is_expired' => 1])
                        ->where($list_category)
                        ->whereRaw($condition)->orderByRaw($order_by)->groupBy('item_inventories.item_id')->limit($limit)->offset($offset)->get();

        $brands = array();
        if (count($itemCount) > 0) {
            foreach ($itemCount as $brand) {
                if (!array_key_exists($brand->id, $brands)) {
                    $brands[$brand->id] = array('brand_id' => $brand->id, 'brand_name' => $brand->brand_name);
                }
            }
        }

        $priceType = "selling_price";
        if($request->price_type == 1){
            $priceType = "member_selling_price";
        }
        
        $this->data['total_records'] = count($itemCount);
        $this->data['image_root'] = cdn('uploads/items');
        $this->data['currency_code'] = 'QAR';
        $this->data['brands'] = array_values($brands);
        $this->data['min_price'] = collect($itemCount)->min($priceType);
        $this->data['max_price'] = collect($itemCount)->max($priceType);
        $this->data['deals_list'] = $itemList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     *
     * Item Details
     *
     * @param $item_slug
     *
     */

    /**
     * @OA\Get(
     *   path="/item-details",
     *   tags={"Products & Service"},
     *   summary="To get product & service details",
     *   operationId="item-details",
     *
     *  @OA\Parameter(
     *      name="item_slug",
     *      in="query",
     *      required=true,
     *      description="Item Slug",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     * )
     **/

    public function getItemServiceDetails(Request $request)
    {
        $itemDetails = Items::with(['itemImages', 'getItemSpec', 'itemChildAttributes' => function ($q) {$q->join('attribute_types', 'attribute_types.id', 'item_attributes.attr_type_id'); $q->select('attribute_types.attribute_name', 'item_attributes.*'); $q->where('item_attributes.status', 1);}, 'getTotalInventory' => function ($in) {$in->where('status', 1);}, 'getItemPromotions'])->leftjoin('ratings', 'ratings.rateable_id', 'items.id')->whereSlug($request->item_slug)->where(['items.status' => 1, 'is_active' => 1])->select('items.*')->addSelect(\DB::raw('sum(ratings.rating) as total_ratings,avg(ratings.rating) as avg_ratings'))->get();
        $this->data['total_records'] = count($itemDetails);
        $this->data['image_root'] = cdn('uploads/items');
        $this->data['currency_code'] = 'QAR';
        $this->data['item_details'] = $itemDetails;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     *
     * Recently Viewed Items
     *
     * @param $user_id
     *
     */

    /**
     * @OA\POST(
     *   path="/recently-viewed",
     *   tags={"Products & Service"},
     *   summary="To get recently viewed product & service details",
     *   operationId="recently-viewed",
     *
     *  @OA\Parameter(
     *      name="user_id",
     *      in="query",
     *      required=false,
     *      description="User ID",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="user_ref",
     *      in="query",
     *      required=false,
     *      description="User Reference",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     * 
     *   @OA\Parameter(
     *      name="item_ref",
     *      in="query",
     *      required=false,
     *      description="Item ID (Which excluded from the list)",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=true,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=true,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 20,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=412,
     *      description="Precondition Failed"
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     * )
     **/

    public function getItemRecentlyViewed(Request $request)
    {
        if ($request->user_id == '' && $request->user_ref == '') {
            $this->data = "Either User ID or Reference required";
            return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_PRECONDITION_FAILED);
        }

        $condition = ($request->user_id != '') ? 'item_view_histories.user_id = "' . $request->user_id . '"' : 'item_view_histories.guest_token = "' . $request->user_ref . '"';

        $itemListCnt = ItemViewHistory::leftjoin('item_inventories', 'item_inventories.item_id', 'item_view_histories.item_id')->leftjoin('items', 'items.id', 'item_view_histories.item_id')->leftjoin('categories', 'categories.id', 'items.category_id')->where(['items.status' => 1, 'is_expired' => 1, 'item_inventories.status' => 1])->leftjoin('item_promotions', 'item_promotions.item_id', 'item_view_histories.item_id')->whereRaw($condition)->whereNotIn('item_view_histories.item_id', [$request->item_ref])->select('item_view_histories.item_id')->orderBy('item_view_histories.id', 'desc')->groupBy('item_promotions.item_id')->get();

        $itemList = ItemViewHistory::with(['itemInfo' => function ($q) {$q->select('id', 'item_name', 'item_rcin', 'item_summary', 'item_group', 'category_id', 'slug', 'is_inventory_track', 'is_variants', 'app_type', 'status', 'is_active'); $q->where(['status' => 1, 'is_active' => 1]);}, 'ItemParentImage','wishList'])->leftjoin('item_inventories', 'item_inventories.item_id', 'item_view_histories.item_id')->leftjoin('items', 'items.id', 'item_view_histories.item_id')->leftjoin('categories', 'categories.id', 'items.category_id')->leftjoin('item_promotions', 'item_promotions.item_id', 'item_view_histories.item_id')->where(['items.status' => 1, 'is_expired' => 1, 'item_inventories.status' => 1])->whereRaw($condition)->whereNotIn('item_view_histories.item_id', [$request->item_ref])->select('item_view_histories.item_id', 'promotion_id', 'start_date', 'end_date', 'is_expired', 'item_inventories.base_price', 'item_inventories.selling_price', 'item_inventories.discount', 'item_inventories.member_discount', 'item_inventories.member_selling_price', 'categories.category_name')->orderBy('item_view_histories.updated_at', 'desc')->groupBy('item_promotions.item_id')->limit($request->limit)->offset($request->offset)->get();

        $this->data['total_records'] = count($itemListCnt);
        $this->data['image_root'] = cdn('uploads/items');
        $this->data['currency_code'] = 'QAR';
        $this->data['item_list'] = $itemList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     *
     * POST Item Review & Rating
     *
     * @param $rname, $remail, $rcomment, $rating, $uuid
     *
     * @return $bool
     *
     */

    /**
     * @OA\POST(
     *   path="/item-rating-review",
     *   tags={"Products & Service"},
     *   summary="To add user item rating & review",
     *   operationId="item-rating-review",
     *
     *  @OA\Parameter(
     *      name="item_ref",
     *      in="path",
     *      required=true,
     *      description="Item ID",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="uuid",
     *      in="path",
     *      required=false,
     *      description="User ID",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="user_name",
     *      in="path",
     *      required=true,
     *      description="Review user name",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="user_email",
     *      in="path",
     *      required=true,
     *      description="Review user email",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="comments",
     *      in="path",
     *      required=true,
     *      description="Comments",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="rating",
     *      in="path",
     *      required=true,
     *      description="User Rating",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     * )
     **/

    public function postItemReviewRating(Request $request)
    {
        if ($request->uuid == "" || $request->comments == "" || $request->rating == "" || $request->item_ref == "") {
            $this->data['status'] = false;
            $this->data['message'] = Lang::get('message.something_went_wrong');
            return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
        }
        $checkUsrInfo = User::whereId($request->uuid)->count();
        if ($checkUsrInfo === 0) {
            $this->data['status'] = false;
            $this->data['message'] = Lang::get('message.something_went_wrong');
            return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
        }
        $checkRating = Rating::where(['user_id' => $request->uuid, 'rateable_id' => $request->item_ref])->count();
        if ($checkRating === 0) {
            $items = Items::find($request->item_ref);
            $rating = new \willvincent\Rateable\Rating;
            $rating->rating = $request->rating;
            $rating->rateable_type = 'App\Models\Items';
            $rating->user_id = $request->uuid;
            $rating->reviews = $request->comments;
            $rating->listing_position = 0;
            $rating->status = 0;
            $details = $items->ratings()->save($rating);
        } else {
            Rating::where(['user_id' => $request->uuid, 'rateable_id' => $request->item_ref])->update([
                'rating' => $request->rating,
                'reviews' => $request->comments,
            ]);
        }

        $this->data['status'] = true;
        $this->data['message'] = Lang::get('message.rating_succ');
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     *
     * Fetch item reviews
     *
     * @param $user_id, $item_id
     *
     * @return $review list
     *
     */

    /**
     * @OA\POST(
     *   path="/fetch-item-reviews",
     *   tags={"Products & Service"},
     *   summary="Fetch item reviews",
     *   operationId="fetch-item-reviews",
     *
     *   @OA\Parameter(
     *      name="item_ref",
     *      in="query",
     *      required=true,
     *      description="Item Reference",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=true,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=true,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 20,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     * )
     *
     **/

    public function getItemReviews(Request $request)
    {
        if ($request->item_ref === '') {
            $this->data['status'] = false;
            $this->data['message'] = Lang::get('message.something_went_wrong');
            return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
        }

        $reviewListCnt = Rating::where(['rateable_id' => $request->item_ref, 'status' => 1])->groupBy('user_id')->orderBy('listing_position')->count();

        $itemList = Rating::with(['user' => function ($q) {$q->select('id', 'name');}])->where(['rateable_id' => $request->item_ref, 'status' => 1])->select('id', 'rating', 'reviews', 'rateable_id', 'user_id', 'updated_at')->orderBy('listing_position')->limit($request->limit)->offset($request->offset)->get();

        $this->data['total_records'] = $reviewListCnt;
        $this->data['review_list'] = $itemList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     *   path="/nationalities",
     *   tags={"Nationalities"},
     *   summary="To fetch all nationalities",
     *   operationId="nationalities",
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get Nationalities */

    public function getNationalitiesList()
    {
        $nationalityList = Nationality::orderBy('nationality')->select('id', 'nationality')->get();
        $this->data['nationality_list'] = $nationalityList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     *   path="/competition-offers",
     *   tags={"Competition"},
     *   summary="To fetch all competition offers",
     *   operationId="competition-offers",
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get Competition Offers */

    public function getCompetitionOffers()
    {
        $compOffers = CompetitionOffer::whereStatus(1)->select('id', 'offer_name')->get();
        $this->data['compt_offers'] = $compOffers;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     *   path="/shipping-address",
     *   tags={"Shipping Address"},
     *   summary="To fetch user all shipping information ",
     *   operationId="shipping-address",
     *
     *   @OA\Parameter(
     *      name="user_id",
     *      in="query",
     *      required=true,
     *      description="User Id",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=true,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=true,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 20,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *)
     **/

    /** Get Customer Shipping Address */

    public function getShippingAddress(Request $request)
    {
        $shipAddrCnt = UserShippingAddress::where('user_id', $request->user_id)->count();
        $shipAddrList = UserShippingAddress::where('user_id', $request->user_id)->limit($request->limit)->offset($request->offset)->orderBy('is_default', 'DESC')->get();
        $this->data['total_records'] = $shipAddrCnt;
        $this->data['address_list'] = $shipAddrList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     *
     * POST Add User Shipping Address
     *
     * @param $request
     *
     * @return $bool
     *
     */

    /**
     * @OA\POST(
     *   path="/add-shipping-address",
     *   tags={"Shipping Address"},
     *   summary="Add user new shipping address",
     *   operationId="add-shipping-address",

     *  @OA\Parameter(
     *      name="usr_ref",
     *      in="query",
     *      required=true,
     *      description="User ID",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="ship_fname",
     *      in="query",
     *      required=true,
     *      description="First name",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_lname",
     *      in="query",
     *      required=true,
     *      description="Last name",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="ship_email",
     *      in="query",
     *      required=true,
     *      description="Email",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_phone",
     *      in="query",
     *      required=true,
     *      description="Phone Number",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_building_no",
     *      in="query",
     *      required=true,
     *      description="Building No",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_street_no",
     *      in="query",
     *      required=true,
     *      description="Street No",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_zone_no",
     *      in="query",
     *      required=true,
     *      description="Zone No",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_addr",
     *      in="query",
     *      required=true,
     *      description="Address",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="is_default",
     *      in="query",
     *      required=true,
     *      description="0 - No, 1 -Yes",
     *      @OA\Schema(
     *         type = "integer",
     *         default = "0"
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     * )
     **/

    public function addShippingAddr(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'ship_fname' => 'required|regex:/^[A-Za-z. -]+$/',
            'ship_lname' => 'required|regex:/^[A-Za-z. -]+$/',
            'ship_email' => 'required|email',
            'ship_phone' => 'required|regex:/[0-9]/',
            'ship_addr' => 'required',
            'ship_building_no' => 'required|numeric',
            'ship_street_no' => 'required|numeric',
            'ship_zone_no' => 'required|numeric',
            'is_default' => 'nullable|regex:/[0-9]/',
        ], [
            'ship_fname.*' => Lang::get('message.valid_fname_req'),
            'ship_lname.*' => Lang::get('message.valid_lname_req'),
            'ship_email.*' => Lang::get('message.valid_email_req'),
            'ship_phone.*' => Lang::get('message.valid_phone_req'),
            'ship_addr.*' => Lang::get('message.valid_addr_req'),
            'ship_building_no.*' => Lang::get('message.valid_building_no_req'),
            'ship_street_no.*' => Lang::get('message.valid_street_no_req'),
            'ship_zone_no.*' => Lang::get('message.valid_zone_no_req'),
        ]);

        if ($validator->fails()) {
            $this->data['status'] = false;
            $this->data['message'] = $validator->messages();
            return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
        }

        $userID = $request->usr_ref;
        if ($request->is_default == 1) {
            $checkDef = UserShippingAddress::where(['user_id' => $userID, 'is_default' => 1])->first();
            if ($checkDef) {
                $checkDef->is_default = 0;
                $checkDef->save();
            }
        }

        $ship_addr = new UserShippingAddress;
        $ship_addr->user_id = $userID;
        $ship_addr->first_name = $request->ship_fname;
        $ship_addr->last_name = $request->ship_lname;
        $ship_addr->email = $request->ship_email;
        $ship_addr->dial_code = '974';
        $ship_addr->phone_number = $request->ship_phone;
        $ship_addr->building_no = $request->ship_building_no;
        $ship_addr->street_no = $request->ship_street_no;
        $ship_addr->zone_no = $request->ship_zone_no;
        $ship_addr->address = $request->ship_addr;
        $ship_addr->is_default = $request->is_default;
        $ship_addr->save();

        $this->data['status'] = true;
        $this->data['message'] = Lang::get('home.ship_succ_added');
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     *
     * POST Update Existing Shipping Address
     *
     * @param $request
     *
     * @return $bool
     *
     */

    /**
     * @OA\POST(
     *   path="/update-shipping-address",
     *   tags={"Shipping Address"},
     *   summary="Update users existing shipping address",
     *   operationId="update-shipping-address",
     *
     *  @OA\Parameter(
     *      name="ship_addr_ref",
     *      in="query",
     *      required=true,
     *      description="Shipping address id",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="usr_ref",
     *      in="query",
     *      required=true,
     *      description="User ID",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="ship_fname",
     *      in="query",
     *      required=true,
     *      description="First name",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_lname",
     *      in="query",
     *      required=true,
     *      description="Last name",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="ship_email",
     *      in="query",
     *      required=true,
     *      description="Email",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_phone",
     *      in="query",
     *      required=true,
     *      description="Phone Number",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_building_no",
     *      in="query",
     *      required=true,
     *      description="Building No",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_street_no",
     *      in="query",
     *      required=true,
     *      description="Street No",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_zone_no",
     *      in="query",
     *      required=true,
     *      description="Zone No",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="ship_addr",
     *      in="query",
     *      required=true,
     *      description="Address",
     *      @OA\Schema(
     *         type = "string",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="is_default",
     *      in="query",
     *      required=true,
     *      description="0 - No, 1 -Yes",
     *      @OA\Schema(
     *         type = "integer",
     *         default = "0"
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     * )
     **/

    public function updateShippingAddr(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'ship_fname' => 'required|regex:/^[A-Za-z. -]+$/',
            'ship_lname' => 'required|regex:/^[A-Za-z. -]+$/',
            'ship_email' => 'required|email',
            'ship_phone' => 'required|regex:/[0-9]/',
            'ship_addr' => 'required',
            'ship_building_no' => 'required|numeric',
            'ship_street_no' => 'required|numeric',
            'ship_zone_no' => 'required|numeric',
            'is_default' => 'nullable|regex:/[0-9]/',
        ], [
            'ship_fname.*' => Lang::get('message.valid_fname_req'),
            'ship_lname.*' => Lang::get('message.valid_lname_req'),
            'ship_email.*' => Lang::get('message.valid_email_req'),
            'ship_phone.*' => Lang::get('message.valid_phone_req'),
            'ship_addr.*' => Lang::get('message.valid_addr_req'),
            'ship_building_no.*' => Lang::get('message.valid_building_no_req'),
            'ship_street_no.*' => Lang::get('message.valid_street_no_req'),
            'ship_zone_no.*' => Lang::get('message.valid_zone_no_req'),
        ]);

        if ($validator->fails()) {
            $this->data['status'] = false;
            $this->data['message'] = $validator->messages();
            return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
        }

        $userID = $request->usr_ref;
        if ($request->is_default == 1) {
            $checkDef = UserShippingAddress::where(['user_id' => $userID, 'is_default' => 1])->first();
            if ($checkDef) {
                $checkDef->is_default = 0;
                $checkDef->save();
            }
        }

        $ship_addr = UserShippingAddress::whereId($request->ship_addr_ref)->first();
        $ship_addr->user_id = $userID;
        $ship_addr->first_name = $request->ship_fname;
        $ship_addr->last_name = $request->ship_lname;
        $ship_addr->email = $request->ship_email;
        $ship_addr->dial_code = '974';
        $ship_addr->phone_number = $request->ship_phone;
        $ship_addr->building_no = $request->ship_building_no;
        $ship_addr->street_no = $request->ship_street_no;
        $ship_addr->zone_no = $request->ship_zone_no;
        $ship_addr->address = $request->ship_addr;
        $ship_addr->is_default = $request->is_default;
        $ship_addr->save();

        $this->data['status'] = true;
        $this->data['message'] = Lang::get('home.ship_succ_updated');
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     *
     * POST Delete User Shipping Address
     *
     * @param $request
     *
     * @return $bool
     *
     */

    /**
     * @OA\POST(
     *   path="/delete-shipping-address",
     *   tags={"Shipping Address"},
     *   summary="Delete user new shipping address",
     *   operationId="delete-shipping-address",
     *
     *  @OA\Parameter(
     *      name="ship_addr_ref",
     *      in="query",
     *      required=true,
     *      description="Shipping Address ID",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     * )
     **/

    public function deleteShippingAddr(Request $request)
    {
        $userID = $request->usr_ref;
        $checkDef = UserShippingAddress::whereId($request->ship_addr_ref)->count();
        if ($checkDef > 0) {
            UserShippingAddress::whereId($request->ship_addr_ref)->delete();
            $this->data['status'] = true;
            $this->data['message'] = Lang::get('home.ship_succ_removed');
            return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
        } else {
            $this->data['status'] = false;
            $this->data['message'] = Lang::get('home.no_ship_addr');
            return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
        }
    }

    /**
     *
     * POST User WishList
     *
     * @param $uuid, $item_id
     *
     * @return $bool
     *
     */

    /**
     * @OA\POST(
     *   path="/add-to-wishlist",
     *   tags={"Products & Service"},
     *   summary="To add item into user wishlist",
     *   operationId="add-to-wishlist",
     *
     *  @OA\Parameter(
     *      name="item_ref",
     *      in="query",
     *      required=true,
     *      description="Item ID",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *  @OA\Parameter(
     *      name="uuid",
     *      in="query",
     *      required=true,
     *      description="User ID",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     * 
     *  @OA\Parameter(
     *      name="is_wish",
     *      in="query",
     *      required=true,
     *      description="Is item in wishlist or not",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     * )
     **/

    public function postUserWishList(Request $request)
    {
        if ($request->uuid == "" || $request->item_ref == "" || $request->is_wish == "") {
            $this->data['status'] = false;
            $this->data['message'] = Lang::get('message.pls_login_cont');
            return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
        }
        
        if ($request->is_wish == 0) {
            $wish_list = new UserWishList;
            $wish_list->user_id = $request->uuid;
            $wish_list->item_id = $request->item_ref;
            $wish_list->save();
            $statMsg = Lang::get('message.wish_add_succ');
            $isWish = 1;
        } else {
            UserWishList::where(['user_id' => $request->uuid, 'item_id' => $request->item_ref])->delete();
            $statMsg = Lang::get('message.wish_del_succ');
            $isWish = 0;
        }

        $this->data['status'] = true;
        $this->data['is_wish'] = $isWish;
        $this->data['message'] = $statMsg;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * @OA\Get(
     ** path="/user-wishlist",
     *   tags={"User Information"},
     *   summary="To get user wishlist items",
     *   operationId="user-wishlist",     
     *  
     *   @OA\Parameter(
     *      name="uuid",
     *      in="query",
     *      required=false,
     *      description="User Id",
     *      @OA\Schema(
     *         type = "integer",
     *         default = ""
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="offset",
     *      in="query",
     *      required=false,
     *      description="The number of items to skip before starting to collect the result set",
     *      @OA\Schema(
     *         type = "integer",
     *         minimum = 0,
     *         default = 0
     *      )
     *   ),
     *
     *   @OA\Parameter(
     *      name="limit",
     *      in="query",
     *      required=false,
     *      description="The numbers of items to return",
     *      @OA\Schema(
     *        type = "integer",
     *        minimum = 1,
     *        maximum = 100,
     *        default = 20,
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=200,
     *      description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *
     *   @OA\Response(
     *      response=404,
     *      description="Not found"
     *   )
     *
     *)
     **/

    /** Get Promo Deals */

    public function getUserWishList(Request $request)
    {
        $offset = 0;
        $limit = 20;
        if (isset($request->offset)) {
            $offset = $request->offset;
        }
        if (isset($request->limit)) {
            $limit = $request->limit;
        }     
         $itemCount = UserWishList::leftjoin('item_inventories','item_inventories.item_id','user_wish_lists.item_id')->leftjoin('items', 'items.id', 'item_inventories.item_id')->where(['items.status' => 1, 'items.is_active' => 1,'user_wish_lists.user_id' => $request->uuid])->groupBy('item_inventories.item_id')->count();        
        $itemList = ItemInventory::with('ItemParentImage')->leftjoin('items', 'items.id', 'item_inventories.item_id')->leftjoin('item_promotions', 'item_promotions.item_id', 'items.id')->leftjoin('user_wish_lists', 'user_wish_lists.item_id', 'items.id')->select('item_inventories.item_id', 'items.id', 'items.item_name', 'items.item_rcin', 'items.item_summary', 'items.item_group', 'items.category_id', 'items.slug', 'items.is_inventory_track', 'items.is_variants', 'items.app_type', 'item_promotions.start_date', 'item_promotions.end_date', 'item_inventories.base_price', 'item_inventories.selling_price', 'item_inventories.discount', 'item_inventories.member_discount', 'item_inventories.member_selling_price', 'items.brand_id')->where(['items.status' => 1, 'items.is_active' => 1,'user_wish_lists.user_id' => $request->uuid])->groupBy('item_inventories.item_id')->limit($limit)->offset($offset)->get();
        $this->data['total_records'] = $itemCount;
        $this->data['image_root'] = cdn('uploads/items');
        $this->data['currency_code'] = 'QAR';
        $this->data['deals_list'] = $itemList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

}
