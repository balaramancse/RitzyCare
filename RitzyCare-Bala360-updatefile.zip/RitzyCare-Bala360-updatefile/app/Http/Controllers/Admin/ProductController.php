<?php

namespace App\Http\Controllers\Admin;

use AppHelpers;
use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\AttributeTypes;
use App\Models\Brand;
use App\Models\Category;
use App\Models\ItemAttributes;
use App\Models\ItemImages;
use App\Models\ItemInventory;
use App\Models\ItemInventoryHistory;
use App\Models\ItemPromotionHistory;
use App\Models\ItemPromotions;
use App\Models\Items;
use App\Models\ItemSpecifications;
use File;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Image;
use Session;
use Validator;

class ProductController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    /** Add Product & Service */

    public function getAddProductService()
    {
        $brands = Brand::whereStatus(1)->orderBy('brand_name')->get();
        $categories = Category::whereCategoryType(1)->whereStatus(1)->orderBy('category_name')->get();
        return view('admin.products-services.add-product-service', compact('brands', 'categories'));
    }

    /** Post Product & Sevice */

    public function postAddProductService(Request $request)
    {
        Validator::make($request->all(), [
            'item_name' => 'required|unique:items',
            'item_name_ar' => 'required',
            'item_brand' => 'required',
            'item_main_category' => 'required',
            'item_sub_category' => 'required',
            'item_third_category' => 'nullable',
            'item_fourth_category' => 'nullable',
            'item_group' => 'required',
            'item_description' => 'required',
            'item_summary' => 'required',
            'item_spec' => 'nullable',
            'track_inventory' => 'required',
            'has_variants' => 'required',
            'item_sku' => 'required',
            'meta_title' => 'nullable',
            'meta_description' => 'nullable',
            'meta_keywords' => 'nullable',
            'item_image' => 'required|image|max:1024',
            'item_sub_image' => 'nullable|array',
            'item_sub_image.*' => 'image|mimes:jpeg,png|max:1024',
        ])->validate();

        $itemSlug = Str::of($request->item_name)->slug('-');
        $itemRcin = 'RC-' . AppHelpers::generateAlphaNumericCode(8);

        $item = new Items;
        $item->setTranslation('item_name', 'en', $request->item_name)->setTranslation('item_name', 'ar', $request->item_name_ar)->save();
        $item->category_id = $request->item_main_category;
        $item->sub_category_id = $request->item_sub_category;
        $item->sec_subcategory_id = $request->item_third_category;
        $item->third_category_id = $request->item_fourth_category;
        $item->brand_id = $request->item_brand;
        $item->setTranslation('item_description', 'en', $request->item_description)->setTranslation('item_description', 'ar', $request->item_description_ar)->save();
        $item->setTranslation('item_summary', 'en', $request->item_summary)->setTranslation('item_summary', 'ar', $request->item_summary_ar)->save();
        $item->item_group = $request->item_group;
        $item->item_sku = $request->item_sku;
        $item->item_rcin = $itemRcin;
        $item->meta_title = $request->meta_title;
        $item->meta_description = $request->meta_description;
        $item->meta_keywords = $request->meta_keywords;
        $item->slug = $itemSlug;
        $item->is_inventory_track = $request->track_inventory;
        $item->is_variants = $request->has_variants;
        $item->is_active = 1;
        $item->status = 1;
        $item->modified_by = auth()->user()->id;
        $item->app_type = $request->appType;
        $item->save();

        $itemID = $item->id;

        $itemAttr = new ItemAttributes;
        $itemAttr->item_id = $itemID;
        $itemAttr->item_rcin = $itemRcin;
        $itemAttr->setTranslation('variant_name', 'en', $request->item_name)->setTranslation('variant_name', 'ar', $request->item_name_ar)->save();
        $itemAttr->variant_type = 0;
        $itemAttr->variant_rcin = $itemRcin . '-' . AppHelpers::generateAlphaNumericCode(8);
        $itemAttr->modified_by = auth()->user()->id;
        $itemAttr->save();

        $itemAttrID = $itemAttr->id;

        if ($request->has('item_spec')) {
            for ($spec = 0; $spec < count($request->item_spec); $spec++) {
                $itemSpec = new ItemSpecifications;
                $itemSpec->item_id = $itemID;
                $itemSpec->setTranslation('specification_name', 'en', $request->item_spec[$spec])->setTranslation('specification_name', 'ar', $request->item_spec_ar[$spec])->save();
                $itemSpec->setTranslation('specification_description', 'en', $request->item_spec_desc[$spec])->setTranslation('specification_description', 'ar', $request->item_spec_desc_ar[$spec])->save();
                $itemSpec->status = 1;
                $itemSpec->modified_by = auth()->user()->id;
                $itemSpec->save();
            }
        }

        if ($request->hasFile('item_image')) {
            $file = $request->file('item_image');

            $image = Image::make($file->getRealPath());
            $extension = $file->getClientOriginalExtension();
            $filename = $itemRcin . '-0.' . $extension;

            /*$image->fit(50, 50)->save(public_path(ItemImages::SMALL_IMAGE.'s-'.$filename));
            $image->fit(370, 370)->save(public_path(ItemImages::MEDIUM_IMAGE.'m-'.$filename));
            $image->fit(1000, 1000)->save(public_path(ItemImages::LARGE_IMAGE.'l-'.$filename));*/

            $picture = str_replace(' ', '', $filename);
            $destinationPath = public_path(ItemImages::DEFAULT_IMAGE);
            $file->move($destinationPath, $picture);

            $itemImg = new ItemImages;
            $itemImg->item_id = $itemID;
            $itemImg->item_attribute_id = $itemAttrID;
            $itemImg->image_name = $filename;
            $itemImg->image_type = 0;
            $itemImg->modified_by = auth()->user()->id;
            $itemImg->save();

            if ($request->hasFile('item_sub_image')) {
                $files = $request->file('item_sub_image');
                $i = 0;
                $j = 0;
                foreach ($files as $key => $file) {
                    $i++;
                    $image = Image::make($file->getRealPath());
                    $extension = $file->getClientOriginalExtension();
                    $filename = $itemRcin . '-' . ($key + 1) . '.' . $extension;

                    $picture = str_replace(' ', '', $filename);
                    $destinationPath = public_path(ItemImages::DEFAULT_IMAGE);
                    $file->move($destinationPath, $picture);

                    $itemImg = new ItemImages;
                    $itemImg->item_id = $itemID;
                    $itemImg->item_attribute_id = $itemAttrID;
                    $itemImg->image_name = $filename;
                    $itemImg->image_type = 1;
                    $itemImg->modified_by = auth()->user()->id;
                    $itemImg->save();
                }
            }
        }

        Session::flash('success', 'Item has been successfully created.');
        return redirect('admin/manage-products-services');
    }

    /** Manage Products & Services */

    public function manageProductsServices()
    {
        $items = Items::with(['getItemParentData', 'getItemParentImage', 'getItemPromotions'])->get();
        return view('admin.products-services.manage-products-services', compact('items'));
    }

    /** Edit Product & Service */

    public function getEditProductService($itemID = "")
    {
        $brands = Brand::whereStatus(1)->orderBy('brand_name')->get();
        $categories = Category::whereCategoryType(1)->whereStatus(1)->orderBy('category_name')->get();
        $item = Items::with(['getItemParentData', 'getItemParentImage', 'getItemChildImages', 'getItemSpec'])->where('id', $itemID)->first();
        return view('admin.products-services.edit-product-service', compact('brands', 'categories', 'item'));
    }

    /** Post Update Product & Sevice */

    public function updateProductService(Request $request, $itemID = "")
    {
        Validator::make($request->all(), [
            'item_name' => 'required|unique:items,item_name,' . $request->id,
            'item_name_ar' => 'required',
            'item_brand' => 'required',
            'item_main_category' => 'required',
            'item_sub_category' => 'required',
            'item_third_category' => 'nullable',
            'item_fourth_category' => 'nullable',
            'item_group' => 'required',
            'item_description' => 'required',
            'item_summary' => 'required',
            'item_spec' => 'nullable',
            'track_inventory' => 'required',
            'has_variants' => 'required',
            'item_sku' => 'required',
            'meta_title' => 'nullable',
            'meta_description' => 'nullable',
            'meta_keywords' => 'nullable',
            'item_image' => 'nullable|image|max:1024',
            'item_sub_image' => 'nullable|array',
            'item_sub_image.*' => 'image|mimes:jpeg,png|max:1024',
        ])->validate();

        $itemSlug = Str::of($request->item_name)->slug('-');

        $item = Items::findOrFail($itemID);
        $item->setTranslation('item_name', 'en', $request->item_name)->setTranslation('item_name', 'ar', $request->item_name_ar)->save();
        $item->category_id = $request->item_main_category;
        $item->sub_category_id = $request->item_sub_category;
        $item->sec_subcategory_id = $request->item_third_category;
        $item->third_category_id = $request->item_fourth_category;
        $item->brand_id = $request->item_brand;
        $item->setTranslation('item_description', 'en', $request->item_description)->setTranslation('item_description', 'ar', $request->item_description_ar)->save();
        $item->setTranslation('item_summary', 'en', $request->item_summary)->setTranslation('item_summary', 'ar', $request->item_summary_ar)->save();
        $item->item_group = $request->item_group;
        $item->meta_title = $request->meta_title;
        $item->meta_description = $request->meta_description;
        $item->meta_keywords = $request->meta_keywords;
        $item->slug = $itemSlug;
        $item->is_inventory_track = $request->track_inventory;
        $item->is_variants = $request->has_variants;
        $item->is_active = 1;
        $item->status = 1;
        $item->modified_by = auth()->user()->id;
        $item->app_type = $request->appType;
        $item->save();

        $itemAttr = ItemAttributes::whereItemId($itemID)->whereVariantType(0)->first();
        $itemAttr->item_id = $itemID;
        $itemAttr->setTranslation('variant_name', 'en', $request->item_name)->setTranslation('variant_name', 'ar', $request->item_name_ar)->save();
        $itemAttr->variant_type = 0;
        $itemAttr->modified_by = auth()->user()->id;
        $itemAttr->save();

        $itemAttrID = $itemAttr->id;
        $itemRCIN = $itemAttr->item_rcin;

        if ($request->has('item_spec')) {

            ItemSpecifications::whereItemId($itemID)->forceDelete();

            for ($spec = 0; $spec < count($request->item_spec); $spec++) {
                $itemSpec = new ItemSpecifications;
                $itemSpec->item_id = $itemID;
                $itemSpec->setTranslation('specification_name', 'en', $request->item_spec[$spec])->setTranslation('specification_name', 'ar', $request->item_spec_ar[$spec])->save();
                $itemSpec->setTranslation('specification_description', 'en', $request->item_spec_desc[$spec])->setTranslation('specification_description', 'ar', $request->item_spec_desc_ar[$spec])->save();
                $itemSpec->status = 1;
                $itemSpec->modified_by = auth()->user()->id;
                $itemSpec->save();
            }
        }

        if ($request->hasFile('item_image')) {

            $file = $request->file('item_image');

            ItemImages::whereItemId($itemID)->where('item_attribute_id', $itemAttrID)->where('image_type', 0)->delete();

            $image = Image::make($file->getRealPath());
            $extension = $file->getClientOriginalExtension();
            $filename = $itemRCIN . '-0.' . $extension;
            $picture = str_replace(' ', '', $filename);
            $destinationPath = public_path(ItemImages::DEFAULT_IMAGE);
            $file->move($destinationPath, $picture);

            $itemImg = new ItemImages;
            $itemImg->item_id = $itemID;
            $itemImg->item_attribute_id = $itemAttrID;
            $itemImg->image_name = $filename;
            $itemImg->image_type = 0;
            $itemImg->modified_by = auth()->user()->id;
            $itemImg->save();
        }

        if ($request->hasFile('item_sub_image')) {
            $files = $request->file('item_sub_image');
            foreach ($files as $key => $file) {
                $image = Image::make($file->getRealPath());
                $extension = $file->getClientOriginalExtension();
                $filename = $itemRCIN . '-' . ($key + 1) . '.' . $extension;

                $picture = str_replace(' ', '', $filename);
                $destinationPath = public_path(ItemImages::DEFAULT_IMAGE);
                $file->move($destinationPath, $picture);

                $itemImg = new ItemImages;
                $itemImg->item_id = $itemID;
                $itemImg->item_attribute_id = $itemAttrID;
                $itemImg->image_name = $filename;
                $itemImg->image_type = 1;
                $itemImg->modified_by = auth()->user()->id;
                $itemImg->save();
            }
        }

        Session::flash('success', 'Item has been successfully updated.');
        return redirect('admin/manage-products-services');
    }

    /** Update Item Status */

    public function updateItemStatus($id, $type)
    {
        $user = auth()->user();
        $item = Items::findOrFail($id);
        if ($item) {
            $itemStat = ($type == 'block') ? 0 : 1;
            $item->is_active = $itemStat;
            $item->status = $itemStat;
            $item->modified_by = $user->id;
            $item->save();
            Session::flash('success', "Item status has been updated.");
            return 1;
        }
    }

    /** Delete Item */

    public function deleteItem($id)
    {
        Items::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        Items::findOrFail($id)->delete();
        ItemAttributes::whereItemId($id)->update(['status' => 0, 'modified_by' => auth()->user()->id]);
        ItemImages::whereItemId($id)->update(['status' => 0, 'modified_by' => auth()->user()->id]);
        ItemSpecifications::whereItemId($id)->update(['status' => 0, 'modified_by' => auth()->user()->id]);
        Session::flash('success', "Item has been deleted successfully.");
        return 1;
    }

    /** Delete Item Image */

    public function deleteItemImage(Request $request)
    {
        ItemImages::findOrFail($request->image_id)->delete();
        if (File::exists(public_path() . '/uploads/items/' . $request->image_name)) {
            unlink(public_path() . '/uploads/items/' . $request->image_name);
        }
        return 1;
    }

    /** Item Promotions */

    public function updateItemPromotions(Request $request)
    {

        if ($request->highlight_action == 1) {
            $rcPromoRef = 'RCPR-' . AppHelpers::generateAlphaNumericCode(8);
            for ($promo = 0; $promo < count($request->promotion_deals); $promo++) {
                $itemPromo = new ItemPromotions;
                $itemPromo->item_id = $request->highlight_item;
                $itemPromo->promotion_id = $request->promotion_deals[$promo];
                $itemPromo->promotion_ref = $rcPromoRef;
                if ($request->promotion_deals[$promo] != 6) {
                    $itemPromo->start_date = $request->pd_startdate[$request->promotion_deals[$promo]][0];
                    $itemPromo->end_date = $request->pd_enddate[$request->promotion_deals[$promo]][0];
                }
                $itemPromo->is_expired = 1;
                $itemPromo->status = 1;
                $itemPromo->modified_by = auth()->user()->id;
                $itemPromo->save();

                $itemPromoHis = new ItemPromotionHistory;
                $itemPromoHis->item_id = $request->highlight_item;
                $itemPromoHis->promotion_id = $request->promotion_deals[$promo];
                $itemPromoHis->promotion_ref = $rcPromoRef;
                if ($request->promotion_deals[$promo] != 6) {
                    $itemPromoHis->start_date = $request->pd_startdate[$request->promotion_deals[$promo]][0];
                    $itemPromoHis->end_date = $request->pd_enddate[$request->promotion_deals[$promo]][0];
                }
                $itemPromoHis->action_type = 1;
                $itemPromoHis->action_description = config('ritzycare.history_action_type')[1];
                $itemPromoHis->modified_by = auth()->user()->id;
                $itemPromoHis->save();
            }
            Session::flash('success', 'Item promotion details has been added.');
            return back();
        } else if ($request->highlight_action == 2) {
            for ($promo = 0; $promo < count($request->promotion_deals); $promo++) {
                $checkExPromo = ItemPromotions::where(['item_id' => $request->highlight_item, 'promotion_id' => $request->promotion_deals[$promo]])->count();
                if ($checkExPromo > 0) {
                    $itemPromo = ItemPromotions::where(['item_id' => $request->highlight_item, 'promotion_id' => $request->promotion_deals[$promo]])->update(['start_date' => $request->pd_startdate[$request->promotion_deals[$promo]][0], 'end_date' => $request->pd_enddate[$request->promotion_deals[$promo]][0], 'modified_by' => auth()->user()->id]);
                } else {
                    $itemPromo = new ItemPromotions;
                    $itemPromo->item_id = $request->highlight_item;
                    $itemPromo->promotion_id = $request->promotion_deals[$promo];
                    $itemPromo->promotion_ref = $request->highlight_item_ref;
                    if ($request->promotion_deals[$promo] != 6) {
                        $itemPromo->start_date = $request->pd_startdate[$request->promotion_deals[$promo]][0];
                        $itemPromo->end_date = $request->pd_enddate[$request->promotion_deals[$promo]][0];
                    }
                    $itemPromo->is_expired = 1;
                    $itemPromo->status = 1;
                    $itemPromo->modified_by = auth()->user()->id;
                    $itemPromo->save();
                }
                $itemPromoHis = new ItemPromotionHistory;
                $itemPromoHis->item_id = $request->highlight_item;
                $itemPromoHis->promotion_id = $request->promotion_deals[$promo];
                $itemPromoHis->promotion_ref = $request->highlight_item_ref;
                if ($request->promotion_deals[$promo] != 6) {
                    $itemPromoHis->start_date = $request->pd_startdate[$request->promotion_deals[$promo]][0];
                    $itemPromoHis->end_date = $request->pd_enddate[$request->promotion_deals[$promo]][0];
                }
                $itemPromoHis->action_type = 2;
                $itemPromoHis->action_description = config('ritzycare.history_action_type')[2];
                $itemPromoHis->modified_by = auth()->user()->id;
                $itemPromoHis->save();
            }
            Session::flash('success', 'Item promotion details has been updated.');
            return back();
        } else if ($request->highlight_action == 0) {
            ItemPromotions::where('promotion_ref', $request->highlight_item_ref)->update(['status' => 0, 'modified_by' => auth()->user()->id]);
            for ($promo = 0; $promo < count($request->promotion_deals); $promo++) {
                $itemPromoHis = new ItemPromotionHistory;
                $itemPromoHis->item_id = $request->highlight_item;
                $itemPromoHis->promotion_id = $request->promotion_deals[$promo];
                $itemPromoHis->promotion_ref = $request->highlight_item_ref;
                if ($request->promotion_deals[$promo] != 6) {
                    $itemPromoHis->start_date = $request->pd_startdate[$request->promotion_deals[$promo]][0];
                    $itemPromoHis->end_date = $request->pd_enddate[$request->promotion_deals[$promo]][0];
                }
                $itemPromoHis->action_type = 3;
                $itemPromoHis->action_description = config('ritzycare.history_action_type')[3];
                $itemPromoHis->modified_by = auth()->user()->id;
                $itemPromoHis->save();
            }
            Session::flash('success', 'Item promotion details has been stopped.');
            return back();
        }
    }

    /** Check Item Promotions */

    public function checkItemPromotions(Request $request)
    {
        return ItemPromotions::where('promotion_ref', $request->itemPromoRef)->get();
    }

    /** Add Item Variants */

    public function getAddItemVariants($itemID = "")
    {
        $itemInfo = Items::with('getItemAttribute')->whereId($itemID)->first();
        $attrTypes = AttributeTypes::whereStatus(1)->orderBy('attribute_name')->get();
        return view('admin.products-services.add-item-variants', compact('itemInfo', 'attrTypes'));
    }

    /** Post Item Variants */

    public function postItemVariants(Request $request, $itemID = "", $itemRCIN = "")
    {
        Validator::make($request->all(), [
            'attribute_type' => 'required',
            'variant_name.*' => 'required',
            'variant_name_ar.*' => 'required',
            'variant_desc.*' => 'nullable',
            'variant_color.*' => 'nullable',
        ])->validate();

        if ($request->has('variant_name')) {
            $attrDet = explode('_', $request->attribute_type);
            $attributeType = $attrDet[1];
            $attributeTypeID = $attrDet[0];
            for ($variants = 0; $variants < count($request->variant_name); $variants++) {
                if ($attributeType == 0) {
                    $attributeVal = $request->variant_desc[$variants];
                } else {
                    $attributeVal = $request->variant_color[$variants];
                }
                $itemAttr = new ItemAttributes;
                $itemAttr->item_id = $itemID;
                $itemAttr->item_rcin = $itemRCIN;
                $itemAttr->variant_rcin = $itemRCIN . '-' . AppHelpers::generateAlphaNumericCode(8);
                $itemAttr->setTranslation('variant_name', 'en', $request->variant_name[$variants])->setTranslation('variant_name', 'ar', $request->variant_name_ar[$variants])->save();
                $itemAttr->variant_type = 1;
                $itemAttr->attr_type_id = $attributeTypeID;
                $itemAttr->attribute_type = $attributeType;
                $itemAttr->attribute_value = $attributeVal;
                $itemAttr->status = 1;
                $itemAttr->modified_by = auth()->user()->id;
                $itemAttr->save();
            }
        }

        Session::flash('success', 'Item variants has been successfully added.');
        return redirect('admin/manage-products-services');
    }

    /** Update Item Attribute Status */

    public function updateItemAttributeStatus($id, $type)
    {
        $user = auth()->user();
        $itemAttr = ItemAttributes::findOrFail($id);
        if ($itemAttr) {
            $itemStat = ($type == 'block') ? 0 : 1;
            $itemAttr->status = $itemStat;
            $itemAttr->modified_by = $user->id;
            $itemAttr->save();
            Session::flash('success', "Attribute status has been updated.");
            return 1;
        }
    }

    /** Delete Item Attribute */

    public function deleteItemAttributes($id)
    {
        ItemAttributes::where('id', $id)->update(['status' => 0, 'modified_by' => auth()->user()->id]);
        ItemAttributes::findOrFail($id)->delete();
        Session::flash('success', "Attribute has been successfully deleted.");
        return 1;
    }

    /** Update Item Variant Information */

    public function updateItemVariant(Request $request, $variantID = "", $itemRCIN = "")
    {
        Validator::make($request->all(), [
            'variant_name.*' => 'required',
            'variant_name_ar.*' => 'required',
            'variant_desc.*' => 'nullable',
            'variant_color.*' => 'nullable',
        ])->validate();

        if ($request->attr_type == 0) {
            $attributeVal = $request->variant_desc;
        } else {
            $attributeVal = $request->variant_color;
        }
        $itemAttr = ItemAttributes::findOrFail($variantID);
        $itemAttr->setTranslation('variant_name', 'en', $request->variant_name)->setTranslation('variant_name', 'ar', $request->variant_name_ar)->save();
        $itemAttr->attribute_value = $attributeVal;
        $itemAttr->modified_by = auth()->user()->id;
        $itemAttr->save();
        Session::flash('success', 'Variant has been successfully updated.');
        return redirect('admin/add-item-variants/' . $itemAttr->item_id . '/' . $itemRCIN);
    }

    /** Get Variant Images */

    public function getVariantImages($variantID = "", $itemID = "", $itemRCIN = "")
    {
        $itemInfo = Items::with('getItemParentImage')->whereId($itemID)->first();
        $attrInfo = ItemAttributes::with(['getVariantChildImages', 'getVariantParentImage'])->where('id', $variantID)->first();
        return view('admin.products-services.variant-images', compact('itemInfo', 'attrInfo', 'itemID', 'itemRCIN'));
    }

    /** Post Variant Images */

    public function postVariantImages(Request $request, $variantID = "", $itemID = "", $itemRCIN = "")
    {
        $attrInfo = ItemAttributes::with('getVariantParentImage')->where('id', $variantID)->first();
        $variantRCIN = $attrInfo->variant_rcin;
        if ($request->hasFile('item_image')) {

            $file = $request->file('item_image');

            ItemImages::whereItemId($itemID)->where('item_attribute_id', $variantID)->where('image_type', 0)->delete();

            $image = Image::make($file->getRealPath());
            $extension = $file->getClientOriginalExtension();
            $filename = $variantRCIN . '-0.' . $extension;
            $picture = str_replace(' ', '', $filename);
            $destinationPath = public_path(ItemImages::DEFAULT_IMAGE);
            $file->move($destinationPath, $picture);

            $itemImg = new ItemImages;
            $itemImg->item_id = $itemID;
            $itemImg->item_attribute_id = $variantID;
            $itemImg->image_name = $filename;
            $itemImg->image_type = 0;
            $itemImg->modified_by = auth()->user()->id;
            $itemImg->save();
        }

        if ($request->hasFile('item_sub_image')) {
            $files = $request->file('item_sub_image');
            foreach ($files as $key => $file) {
                $image = Image::make($file->getRealPath());
                $extension = $file->getClientOriginalExtension();
                $filename = $variantRCIN . '-' . ($key + 1) . '.' . $extension;

                $picture = str_replace(' ', '', $filename);
                $destinationPath = public_path(ItemImages::DEFAULT_IMAGE);
                $file->move($destinationPath, $picture);

                $itemImg = new ItemImages;
                $itemImg->item_id = $itemID;
                $itemImg->item_attribute_id = $variantID;
                $itemImg->image_name = $filename;
                $itemImg->image_type = 1;
                $itemImg->modified_by = auth()->user()->id;
                $itemImg->save();
            }
        }

        Session::flash('success', 'Variant images has been successfully modified.');
        return redirect('admin/add-item-variants/' . $itemID . '/' . $itemRCIN);
    }

    /** Manage Item Inventories */

    public function manageItemInventories()
    {
        $items = Items::with(['getItemParentData', 'getTotalInventory'])->get();
        return view('admin.products-services.manage-item-inventories', compact('items'));
    }

    /** Add Item Inventory */

    public function getItemInventory($itemID = "", $itemRCIN = "")
    {
        $item = Items::with(['getItemAttribute' => function ($q) {$q->orderBy('variant_name');}])->findOrFail($itemID);
        $vendors = Admin::where(['status' => 1, 'user_type' => 1])->orderBy('name')->get();
        return view('admin.products-services.add-item-inventory', compact('vendors', 'item'));
    }

    /** Check Vendor Inventory Details */

    public function checkVendorInventory(Request $request)
    {
        if ($request->attrID != 0) {
            return ItemInventory::where(['item_id' => $request->itemID, 'vendor_id' => $request->vendorID, 'store_id' => $request->storeID, 'attribute_id' => $request->attrID])->count();
        } else {
            return ItemInventory::where(['item_id' => $request->itemID, 'vendor_id' => $request->vendorID, 'store_id' => $request->storeID])->count();
        }
    }

    /** Post Item Inventory */

    public function postItemInventory(Request $request, $itemID = "", $itemRCIN = "")
    {
        Validator::make($request->all(), [
            'item_vendor' => 'required',
            'item_store' => 'required',
            'attribute' => 'nullable',
            'base_price' => 'required',
            'discount' => 'required|numeric',
            'member_discount' => 'required|numeric',
            'selling_price' => 'required|lte:' . $request->base_price,
            'member_selling_price' => 'required|lte:' . $request->base_price,
            'quantity' => 'required',
        ])->validate();

        $itemInven = new ItemInventory;
        $itemInven->item_id = $itemID;
        $itemInven->attribute_id = ($request->attribute) ?: $itemID;
        $itemInven->vendor_id = $request->item_vendor;
        $itemInven->store_id = $request->item_store;
        $itemInven->base_price = $request->base_price;
        $itemInven->discount = $request->discount;
        $itemInven->selling_price = $request->selling_price;
        $itemInven->member_discount = $request->member_discount;
        $itemInven->member_selling_price = $request->member_selling_price;
        $itemInven->quantity = $request->quantity;
        $itemInven->status = 1;
        $itemInven->modified_by = auth()->user()->id;
        $itemInven->save();

        $itemInvenHis = new ItemInventoryHistory;
        $itemInvenHis->item_id = $itemID;
        $itemInvenHis->attribute_id = ($request->attribute) ?: $itemID;
        $itemInvenHis->vendor_id = $request->item_vendor;
        $itemInvenHis->store_id = $request->item_store;
        $itemInvenHis->base_price = $request->base_price;
        $itemInvenHis->discount = $request->discount;
        $itemInvenHis->selling_price = $request->selling_price;
        $itemInvenHis->member_discount = $request->member_discount;
        $itemInvenHis->member_selling_price = $request->member_selling_price;
        $itemInvenHis->quantity = $request->quantity;
        $itemInvenHis->modified_by = auth()->user()->id;
        $itemInvenHis->save();

        Session::flash('success', 'Item inventory has been successfully added.');
        return redirect('admin/manage-item-inventories');
    }

    /** Edit Item Inventory */

    public function getEditItemInventory($itemID = "", $itemRCIN = "")
    {
        $item = Items::findOrFail($itemID);
        $inventoryVendors = ItemInventory::join('admins', 'admins.id', 'item_inventories.vendor_id')->where('item_id', $itemID)->groupBy('item_inventories.vendor_id')->select('admins.name', 'admins.id')->orderBy('admins.name')->get();
        return view('admin.products-services.edit-item-inventory', compact('inventoryVendors', 'item'));
    }

    /** Get Inventory Based Stores */

    public function getInventoryStoresList(Request $request)
    {
        return ItemInventory::join('stores', 'stores.id', 'item_inventories.store_id')->where(['item_inventories.item_id' => $request->itemID, 'item_inventories.vendor_id' => $request->vendorID])->groupBy('item_inventories.store_id')->select('stores.store_name', 'stores.id')->orderBy('stores.store_name')->get();
    }

    /** Get Inventory Based Attributes */

    public function getInventoryAttributes(Request $request)
    {
        return ItemInventory::join('item_attributes', 'item_attributes.id', 'item_inventories.attribute_id')->where(['item_inventories.item_id' => $request->itemID, 'item_inventories.vendor_id' => $request->vendorID, 'item_inventories.store_id' => $request->storeID])->groupBy('item_inventories.attribute_id')->select('item_attributes.variant_name', 'item_attributes.id')->orderBy('item_attributes.variant_name')->get();
    }

    /** Get Inventory Based Properties */

    public function getInventoryProperties(Request $request)
    {
        if ($request->attrID != 0) {
            return ItemInventory::where(['item_inventories.item_id' => $request->itemID, 'item_inventories.vendor_id' => $request->vendorID, 'item_inventories.store_id' => $request->storeID, 'item_inventories.attribute_id' => $request->attrID])->groupBy('item_inventories.attribute_id')->get();
        } else {
            return ItemInventory::where(['item_inventories.item_id' => $request->itemID, 'item_inventories.vendor_id' => $request->vendorID, 'item_inventories.store_id' => $request->storeID])->get();
        }
    }

    /** Post Update Item Inventory */

    public function postUpdateItemInventory(Request $request, $itemID = "", $itemRCIN = "")
    {
        Validator::make($request->all(), [
            'inventory_vendor' => 'required',
            'inventory_store' => 'required',
            'attribute' => 'nullable',
            'base_price' => 'required',
            'selling_price' => 'required|lte:' . $request->base_price,
            'quantity' => 'required',
        ])->validate();

        $itemInven = ItemInventory::findOrFail($request->inventory_id);
        $itemInven->base_price = $request->base_price;
        $itemInven->discount = $request->discount;
        $itemInven->selling_price = $request->selling_price;
        $itemInven->member_discount = $request->member_discount;
        $itemInven->member_selling_price = $request->member_selling_price;
        $itemInven->quantity = $request->quantity;        
        $itemInven->modified_by = auth()->user()->id;
        $itemInven->save();

        $itemInvenHis = new ItemInventoryHistory;
        $itemInvenHis->item_id = $itemID;
        $itemInvenHis->attribute_id = ($request->attribute) ?: $itemID;
        $itemInvenHis->vendor_id = $request->inventory_vendor;
        $itemInvenHis->store_id = $request->inventory_store;
        $itemInvenHis->base_price = $request->base_price;
        $itemInvenHis->discount = $request->discount;
        $itemInvenHis->selling_price = $request->selling_price;
        $itemInvenHis->member_discount = $request->member_discount;
        $itemInvenHis->member_selling_price = $request->member_selling_price;
        $itemInvenHis->quantity = $request->quantity;
        $itemInvenHis->modified_by = auth()->user()->id;
        $itemInvenHis->save();

        Session::flash('success', 'Item inventory has been successfully updated.');
        return redirect('admin/manage-item-inventories');
    }

    /** Manage Item Variants Inventory */

    public function manageVariantsInventory($itemID = "")
    {
        $variants = ItemAttributes::with(['inventoryAttributes', 'inventoryItem'])->where(['item_id' => $itemID, 'variant_type' => 1])->get();
        return view('admin.products-services.manage-variants-inventory', compact('variants', 'itemID'));
    }

    /** Manage Vendor Inventory */

    public function manageVendorInventory($itemID = "")
    {
        $vendors = ItemInventory::with(['inventoryVendors', 'inventoryAttributes', 'inventoryItem'])->where('item_id', $itemID)->get();
        return view('admin.products-services.manage-vendors-inventory', compact('vendors', 'itemID'));
    }

    /** Update Vendor Inventory Status */

    public function updateVendorInventoryStatus($id, $type)
    {
        $user = auth()->user();
        $itemInventory = ItemInventory::findOrFail($id);
        if ($itemInventory) {
            $itemStat = ($type == 'block') ? 0 : 1;
            $itemInventory->status = $itemStat;
            $itemInventory->modified_by = $user->id;
            $itemInventory->save();
            Session::flash('success', "Inventory status has been updated.");
            return 1;
        }
    }

}
