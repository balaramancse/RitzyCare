<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AffiliateUsers;
use App\Models\ContactMessage;
use App\Models\EmailSubscription;
use App\Models\User;
use Session;

class CustomerController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    /** Manage Customers */

    public function manageCustomers()
    {
        $customers = User::orderby("users.id", "DESC")->get();
        return view('admin.customers.manage-customers', compact('customers'));
    }

    /** Update Customer Status */

    public function updateCustomerStatus($id, $type)
    {
        $customer = User::findOrFail($id);
        if ($customer) {
            $customerStat = ($type == 'block') ? 0 : 1;
            $customer->is_active = $customerStat;
            $customer->save();
            Session::flash('success', "Customer status has been updated.");
            return 1;
        }
    }

    /** Manage Premium Customers */

    public function managePremiumCustomers()
    {
        $customers = User::where('is_subscribed', 1)->orderby("users.id", "DESC")->get();
        return view('admin.customers.premium-customers', compact('customers'));
    }

    /** Manage Affiliate Users */

    public function manageAffiliateUsers()
    {
        $affusers = AffiliateUsers::orderby("affiliate_users.id", "DESC")->get();
        return view('admin.customers.affiliate-users', compact('affusers'));
    }

    /** Update Customer Status */

    public function updateAffiliateUserStatus($id, $type)
    {
        $affUser = AffiliateUsers::findOrFail($id);
        if ($affUser) {
            $affUserStat = ($type == 'block') ? 0 : 1;
            $affUser->status = $affUserStat;
            $affUser->save();
            Session::flash('success', "Affiliate user status has been updated.");
            return 1;
        }
    }

    /** Manage Customer Enquiries */

    public function manageCustomerEnquiries()
    {
        $enquiries = ContactMessage::orderby("id", "DESC")->get();
        return view('admin.customers.manage-enquiry', compact('enquiries'));
    }

    /** Manage Customer Enquiries */

    public function manageSubscribers()
    {
        $subscribers = EmailSubscription::orderby("id", "DESC")->get();
        return view('admin.customers.manage-subscribers', compact('subscribers'));
    }

    /** Update User Subscription Status */

    public function updateUserSubscriptionStatus($id, $type)
    {
        $subscription = EmailSubscription::findOrFail($id);
        if ($subscription) {
            $subsStat = ($type == 'block') ? 0 : 1;
            $subscription->status = $subsStat;
            $subscription->save();
            Session::flash('success', "User subscription status has been updated.");
            return 1;
        }
    }
}
