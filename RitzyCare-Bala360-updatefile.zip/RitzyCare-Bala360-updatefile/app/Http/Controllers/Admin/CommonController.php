<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Area;
use App\Models\Category;
use App\Models\Zones;
use Illuminate\Http\Request;

class CommonController extends Controller
{
    /** Fetch Zone Information */

    public function getZoneInformation()
    {
        $zones = Zones::where('status', 1)->orderBy('zone_name')->get();
        return $zones;
    }

    /** Fetch Area Information */

    public function getAreaInformation(Request $request)
    {
        $area = Area::select('id', 'area_name')->where('zone_id', $request->zone)->where('status', 1)->get();
        return $area;
    }

    /** Fetch Category Information */

    public function getSubCategories(Request $request)
    {
        if ($request->searchType == 2) {
            $categories = Category::select('id', 'category_name')->where(['main_category_id' => $request->categoryID, 'status' => 1, 'category_type' => 2])->get();
        } else if($request->searchType == 3) {
            $categories = Category::select('id', 'category_name')->where(['sub_category_id' => $request->categoryID, 'status' => 1, 'category_type' => 3])->get();
        } else if($request->searchType == 4) {
            $categories = Category::select('id', 'category_name')->where(['sub_category_id' => $request->categoryID, 'status' => 1, 'category_type' => 4])->get();
        }
        return $categories;
    }
}
