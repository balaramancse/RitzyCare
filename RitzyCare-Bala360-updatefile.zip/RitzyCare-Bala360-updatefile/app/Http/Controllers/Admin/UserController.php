<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Str;
use Auth;
use Validator;
use Session;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    /** Add Vendor Information */

    public function getAddUser()
    {
        $roles = Role::orderBy('name')->get();
        return view('admin.users.add-user', compact('roles'));
    }

    /** Post User Information */

    public function postUserInformation(Request $request)
    {
        Validator::make($request->all(), [
            'first_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'last_name' => 'nullable', 'regex:/^[A-Za-z _-]+$/',
            'user_email' => 'required|email|unique:admins,email',
            'user_contact' => 'required | numeric',
            'user_role' => 'required',
        ])->validate();

        $password = Str::random(8);
        $storeSlug = Str::of($request->store_name)->slug('-');

        $user = new Admin;
        $user->name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->user_email;
        $user->password = bcrypt($password);
        $user->contact_number = $request->user_contact;
        $user->status = 1;
        $user->modified_by = auth()->user()->id;
        $user->user_type = 0;
        $user->assignRole($request->user_role);
        $user->save();

        Session::flash('success', 'User account has been created successfully.');
        return redirect('admin/manage-users');
    }

    /** Manage User Information */

    public function manageUserInformation()
    {
        $users = Admin::orderby("admins.id", "DESC")->get();
        return view('admin.users.manage-users', compact('users'));
    }

    /** Edit User Information */

    public function getUserDetails($id = "")
    {
        $roles = Role::orderBy('name')->get();
        $user = Admin::findOrFail($id);
        return view('admin.users.edit-user', compact('user','roles'));
    }

    /** Post User Update Information */

    public function updateUserDetails(Request $request, $id = "")
    {
        Validator::make($request->all(), [
            'first_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'last_name' => 'nullable', 'regex:/^[A-Za-z _-]+$/',
            'user_email' => 'required | email | unique:admins,email,' . $id,
            'user_contact' => 'required | numeric',
            'user_role' => 'required',
        ])->validate();

        $user = Admin::findOrFail($id);
        $user->name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->user_email;        
        $user->contact_number = $request->user_contact;
        $user->modified_by = auth()->user()->id;
        $user->roles()->detach();
        $user->assignRole($request->user_role);
        $user->save();

        Session::flash('success', 'User details has been updated successfully.');
        return redirect('admin/manage-users');
    }

    /** Update User Status */

    public function updateUserStatus($id, $type)
    {
        $user = auth()->user();
        $user = Admin::findOrFail($id);
        if ($user) {
            $usrStat = ($type == 'block') ? 0 : 1;
            $user->status = $usrStat;
            $user->modified_by = $user->id;
            $user->save();
            Session::flash('success', "User status has been updated.");
            return 1;
        }
    }

    /** Delete User */

    public function deleteUser($id)
    {
        Admin::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        Admin::findOrFail($id)->delete();       
        Session::flash('success', "User has been removed.");
        return 1;
    }
}
