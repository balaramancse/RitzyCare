<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\AppProgramme;
use App\Models\Area;
use App\Models\AttributeTypes;
use App\Models\Banner;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Faq;
use App\Models\ModuleSettings;
use App\Models\PromoAds;
use App\Models\PromoVideos;
use App\Models\Settings;
use App\Models\SocialMediaReviews;
use App\Models\SocialMediaSettings;
use App\Models\StaticPages;
use App\Models\Zones;
use File;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Redirect;
use Session;

class SettingsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('admin.dashboard.main-dashboard');
    }

    /** Profile information */

    public function profileSettings()
    {
        $isSuccess = (session()->has('success')) ? session()->get('success') : "";
        return view('admin.settings.profile-settings')->with('isSuccess', $isSuccess);
    }

    /** Edit profile information */

    public function getEditProfile()
    {
        return view('admin.settings.edit-profile-settings');
    }

    /** Update profile information */

    public function updateProfile(Request $request)
    {
        $this->validate($request, [
            'userName' => 'required', ' regex:/^[A-Za-z. -]+$/',
            'userEmail' => 'required | email',
        ]);

        $admin = auth()->user();
        $admin->name = ($request->get('userName')) ? $request->get('userName') : '';
        $admin->email = ($request->get('userEmail')) ? $request->get('userEmail') : '';
        $admin->save();
        return redirect('admin/profile-settings')->with('success', 'Your profile has been saved successfully');
    }

    /** Change Password */

    public function getChangePassword()
    {
        return view('admin.settings.change-password');
    }

    /** Update Password information */

    public function updatePassword(Request $request)
    {
        $this->validate($request, [
            'currentPassword' => 'required',
            'newPassword' => 'required|different:currentPassword|min:5|max:16',
            'confirmPassword' => 'required|same:newPassword',
        ]);
        $request_data = $request->All();
        $current_password = auth()->user()->password;
        if (\Hash::check($request_data['currentPassword'], $current_password)) {
            $user_id = auth()->user()->id;
            $obj_user = Admin::find($user_id);
            $obj_user->password = bcrypt($request_data['newPassword']);
            $obj_user->save();
            return redirect('admin/profile-settings')->with('success', 'Your password has been updated successfully');
        } else {
            return redirect()->back()->with('error', 'Incorrect current password');
        }
    }

    /** Get General Settings */

    public function getGeneralSettings()
    {
        $isSuccess = (session()->has('success')) ? session()->get('success') : "";
        $setting = Settings::findOrFail(1);
        return view('admin.settings.general-settings', compact('setting', 'isSuccess'));
    }

    /** Update General Settings */

    public function updateGeneralSettings(Request $request)
    {
        $this->validate($request, [
            'siteName' => 'required ',
            'metaTitle' => 'required ',
            'metaKeywords' => 'required ',
            'metaDescription' => 'required ',
            'siteMode' => 'required ',
        ]);

        $settings = Settings::findOrFail(1);
        $settings->setTranslation('site_name', 'en', $request->siteName)->setTranslation('site_name', 'ar', $request->siteName)->save();
        $settings->setTranslation('about_site', 'en', 'Founded with the purpose of spreading beauty, care and wellness to everyone everywhere, through our carefully curated collection of services and products.')->setTranslation('about_site', 'ar', 'تأسست بهدف نشر الجمال والعناية والعافية للجميع في كل مكان ، من خلال مجموعتنا المنسقة بعناية من الخدمات والمنتجات.')->save();
        $settings->customercare_email = 'info@ritzy.care';
        $settings->customercare_number = '1234 5678 9101';
        $settings->meta_title = $request->metaTitle;
        $settings->meta_keywords = $request->metaKeywords;
        $settings->meta_description = $request->metaDescription;
        $settings->site_mode = ($request->siteMode == 1) ? 1 : 0;
        $settings->save();

        return redirect('admin/general-settings')->with('success', 'General settings has been updated');
    }

    /** Add Zone Information */

    public function addZoneDetails()
    {
        return view('admin.settings.add-zone');
    }

    /** Post Zone Information */

    public function postZoneDetails(Request $request)
    {
        $this->validate($request, [
            'zoneName' => 'required|unique:zones,zone_name', ' regex:/^[A-Za-z _-]+$/',
        ]);
        $zone = new Zones;
        $zone->setTranslation('zone_name', 'en', $request->zoneName)->setTranslation('zone_name', 'ar', $request->zoneNameAr)->save();
        $zone->slug = Str::of($request->zoneName)->slug('-');
        $zone->save();
        Session::flash('success', "New zone has been added.");
        return redirect('admin/zone-listing');
    }

    /** Zone Listing */

    public function getZoneListing()
    {
        $zones = Zones::get();
        return view('admin.settings.zone-listing', compact('zones'));
    }

    /** Edit zone information */

    public function getZoneDetails($id = "")
    {
        $zone = Zones::findOrFail($id);
        return view('admin.settings.edit-zone', compact('zone'));
    }

    /** Update zone information */

    public function updateZoneDetails($id, Request $request)
    {
        $this->validate($request, [
            'zoneName' => 'required|unique:zones,zone_name,' . $id, ' regex:/^[A-Za-z _-]+$/',
        ]);
        $zone = Zones::findOrFail($id);
        $zone->setTranslation('zone_name', 'en', $request->zoneName)->setTranslation('zone_name', 'ar', $request->zoneNameAr)->save();
        $zone->status = 1;
        $zone->slug = Str::of($request->zoneName)->slug('-');
        $zone->save();
        Session::flash('success', "Zone details has been updated.");
        return redirect('admin/zone-listing');
    }

    /** Update zone status */

    public function updateZoneStatus($id, $type)
    {
        $zone = Zones::findOrFail($id);
        if ($zone) {
            $zone->status = ($type == 'block') ? 0 : 1;
            $zone->save();
            Session::flash('success', "Zone details has been updated.");
            return 1;
        }
    }

    /** Delete zone */

    public function deleteZone($id)
    {
        $this->updateZoneStatus($id, 'block');
        Zones::findOrFail($id)->delete();
        Session::flash('success', "Zone has been removed.");
        return 1;
    }

    /** Add Area Information */

    public function addAreaDetails()
    {
        $zones = Zones::whereStatus(1)->orderBy('zone_name')->get();
        return view('admin.settings.add-area', compact('zones'));
    }

    /** Post Area Information */

    public function postAreaDetails(Request $request)
    {
        $this->validate($request, [
            'area_name' => 'required', ' regex:/^[A-Za-z _-]+$/',
            'zone_name' => 'required ',
        ]);

        $result = Area::where('zone_id', $request->zone_name)->where('area_name', $request->area_name)->count();
        if ($result > 0) {
            Session::flash('error', 'Area name already exists.');
            return back()->withInput(\Input::all());
        }

        $area = new Area;
        $area->zone_id = $request->zone_name;
        $area->setTranslation('area_name', 'en', $request->area_name)->setTranslation('area_name', 'ar', $request->area_name_ar)->save();
        $area->slug = Str::of($request->area_name)->slug('-');
        $area->status = 1;
        $area->save();

        Session::flash('success', "Area information has been added.");
        return redirect('admin/area-listing');
    }

    /** Area Listing */

    public function getAreaListing()
    {
        $areas = Area::with('Zone')->get();
        return view('admin.settings.manage-areas', compact('areas'));
    }

    /** Edit area information */

    public function getAreaDetails($id = "")
    {
        $zones = Zones::whereStatus(1)->orderBy('zone_name')->get();
        $area = Area::findOrFail($id);
        return view('admin.settings.edit-area', compact('zones', 'area'));
    }

    /** Update area information */

    public function updateAreaDetails($id, Request $request)
    {
        $this->validate($request, [
            'area_name' => 'required', ' regex:/^[A-Za-z _-]+$/',
            'zone_name' => 'required ',
        ]);

        $result = Area::where('zone_id', $request->zone_name)->where('area_name', $request->area_name)->where('id', '<>', $id)->count();
        if ($result > 0) {
            Session::flash('danger', 'Oops!, Area name already exists.');
            return back()->withInput(\Input::all());
        }

        $area = Area::findOrFail($id);
        $area->zone_id = $request->zone_name;
        $area->area_name = $request->area_name;
        $area->slug = Str::of($request->area_name)->slug('-');
        $area->status = 1;
        $area->save();

        Session::flash('success', "Area details has been updated.");
        return redirect('admin/area-listing');
    }

    /** Update zone status */

    public function updateAreaStatus($id, $type)
    {
        $area = Area::findOrFail($id);
        if ($area) {
            $area->status = ($type == 'block') ? 0 : 1;
            $area->save();
            Session::flash('success', "Area details has been updated.");
            return 1;
        }
    }

    /** Delete zone */

    public function deleteArea($id)
    {
        $this->updateZoneStatus($id, 'block');
        Area::findOrFail($id)->delete();
        Session::flash('success', "Area has been removed.");
        return 1;
    }

    /** Add Category */

    public function addCategoryDetails()
    {
        return view('admin.settings.add-category');
    }

    /** Post Category Information */

    public function postCategoryDetails(Request $request)
    {
        $this->validate($request, [
            'category_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
        ]);

        $cateSlug = Str::of($request->category_name)->slug('-');
        $result = Category::where('slug', $cateSlug)->count();
        if ($result > 0) {
            Session::flash('error', 'Oops!, Category already exists.');
            return back()->withInput(\Input::all());
        }

        $category = new Category;
        $category->setTranslation('category_name', 'en', $request->category_name)->setTranslation('category_name', 'ar', $request->category_name_ar)->save();
        $category->meta_title = $request->meta_title;
        $category->meta_keywords = $request->meta_keywords;
        $category->meta_description = $request->meta_description;
        $category->slug = $cateSlug;
        $category->category_type = 1;
        $category->modified_by = auth()->user()->id;
        $category->app_type = $request->appType;
        $category->save();

        Session::flash('success', "New category has been added.");
        return redirect('admin/manage-categories');
    }

    /** Manage Categories */

    public function getCategoryListing()
    {
        $categories = Category::where('main_category_id', 0)->orderBy('category_name')->get();
        return view('admin.settings.manage-categories', compact('categories'));
    }

    /** Edit Category Details */

    public function getCategoryDetails($id = "", $cateSlug = "")
    {
        $category = Category::where('id', $id)->where('slug', $cateSlug)->first();
        return view('admin.settings.edit-category', compact('category'));
    }

    /** Update Category Details */

    public function updateCategoryDetails(Request $request, $id = "", $cateSlug = "")
    {
        $this->validate($request, [
            'category_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
        ]);

        $cateSlug = Str::of($request->category_name)->slug('-');
        $result = Category::where('slug', $cateSlug)->where('main_category_id', 0)->where('id', '<>', $id)->count();
        if ($result > 0) {
            Session::flash('error', 'Oops!, Category already exists.');
            return back()->withInput(\Input::all());
        }

        $category = Category::findOrfail($id);
        $category->setTranslation('category_name', 'en', $request->category_name)->setTranslation('category_name', 'ar', $request->category_name_ar)->save();
        $category->meta_title = $request->meta_title;
        $category->meta_keywords = $request->meta_keywords;
        $category->meta_description = $request->meta_description;
        $category->slug = $cateSlug;
        $category->modified_by = auth()->user()->id;
        $category->app_type = $request->appType;
        $category->save();

        Session::flash('success', "Category information has been updated.");
        return redirect('admin/manage-categories');
    }

    /** Update Category Status */

    public function updateCategoryStatus($id = "", $type = "", $catType = "", $mainCatID = "")
    {
        $user = auth()->user();
        $status = ($type == 'block') ? 0 : 1;
        if ($catType == 1) {
            $cat = Category::findOrFail($id);
            if ($cat) {
                $cat->status = $status;
                $cat->save();
                $subCate = Category::where('main_category_id', $id)->update(['status' => $status, "modified_by" => $user->id]);
                echo 1;exit;
            } else {
                echo "";exit;
            }
        } else if ($catType == 2) {
            $main_cat = Category::where(['id' => $mainCatID, "main_category_id" => 0, "status" => 1])->first();
            if ($main_cat) {
                $subCate = Category::where('id', $id)->update(['status' => $status, "modified_by" => $user->id]);
                $secsubCate = Category::where('sub_category_id', $id)->update(['status' => $status, "modified_by" => $user->id]);
                echo 1;exit;
            } else {
                echo "";exit;
            }
        } else if ($catType == 3) {
            $main_cat = Category::where(['id' => $mainCatID, "status" => 1])->whereRaw("main_category_id != 0")->first();
            if (count($main_cat) > 0) {
                $subCate = Category::where('id', $id)->update(['status' => $status, "modified_by" => $user->id]);
                $subCate = Category::where('sub_category_id', $id)->update(['status' => $status, "modified_by" => $user->id]);
                echo 1;exit;
            } else {
                echo "";exit;
            }
        } else if ($catType == 4) {
            $main_cat = Category::where(['id' => $mainCatID, "status" => 1])->whereRaw("main_category_id != 0")->first();
            if (count($main_cat) > 0) {
                $subCate = Category::where('id', $id)->update(['status' => $status, "modified_by" => $user->id]);
                echo 1;exit;
            } else {
                echo "";exit;
            }
        }
    }

    /** Delete Category */

    public function deleteCategory($id)
    {
        Category::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        Category::findOrFail($id)->delete();
        return 1;
    }

    /** Add Sub Category */

    public function addSubCategoryDetails($id, $catSlug)
    {
        $main_cat = Category::findOrFail($id);
        if ($main_cat) {
            return view('admin.settings.add-sub-category', compact('main_cat'));
        }
        Session::flash('error', 'Oops!, Something went wrong.');
        return back();
    }

    /** Post Category Information */

    public function postSubCategoryDetails(Request $request, $parentCatID)
    {
        $this->validate($request, [
            'category_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
        ]);

        $cateSlug = Str::of($request->category_name)->slug('-');
        if ($request->category_type == 2) {
            $result = Category::where('slug', $cateSlug)->where('main_category_id', $parentCatID)->count();
        } else {
            $result = Category::where('slug', $cateSlug)->where('sub_category_id', $parentCatID)->count();
        }
        if ($result > 0) {
            Session::flash('error', 'Oops!, Same category already exists under this category.');
            return back()->withInput(\Input::all());
        }
        $category = new Category;
        $category->setTranslation('category_name', 'en', $request->category_name)->setTranslation('category_name', 'ar', $request->category_name_ar)->save();
        $category->main_category_id = $request->main_category_id;
        $category->sub_category_id = $parentCatID;
        $category->meta_title = $request->meta_title;
        $category->meta_keywords = $request->meta_keywords;
        $category->meta_description = $request->meta_description;
        $category->slug = $cateSlug;
        $category->category_type = $request->category_type;
        $category->modified_by = auth()->user()->id;
        $category->save();

        Session::flash('success', "New category has been added.");
        return back();
    }

    /** Manage Sub Categories */

    public function getSubCategoryListing($id = "")
    {
        $categories = Category::where(['main_category_id' => $id, 'category_type' => 2])->orderBy('category_name')->get();
        return view('admin.settings.manage-sub-categories', compact('categories'));
    }

    /** Edit Sub Category Details */

    public function getSubCategoryDetails($parentCateID = "", $cateSlug = "")
    {
        $category = Category::with('parentCategory')->where('id', $parentCateID)->first();
        $pageTitle = "Sub Category";
        $cateType = 2;
        return view('admin.settings.edit-sub-category', compact('category', 'pageTitle', 'cateType'));
    }

    /** Update Sub Category Details */

    public function updateSubCategoryDetails(Request $request, $id = "", $cateSlug = "")
    {
        $this->validate($request, [
            'category_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
        ]);

        $cateSlug = Str::of($request->category_name)->slug('-');
        $result = Category::where('slug', $cateSlug)->where('main_category_id', $request->parent_cate_id)->where('id', '<>', $id)->count();
        if ($result > 0) {
            Session::flash('error', 'Oops!, Category already exists.');
            return back()->withInput(\Input::all());
        }

        $category = Category::findOrfail($id);
        $category->setTranslation('category_name', 'en', $request->category_name)->setTranslation('category_name', 'ar', $request->category_name_ar)->save();
        $category->meta_title = $request->meta_title;
        $category->meta_keywords = $request->meta_keywords;
        $category->meta_description = $request->meta_description;
        $category->slug = $cateSlug;
        $category->modified_by = auth()->user()->id;
        $category->save();

        Session::flash('success', "Category information has been updated.");
        return back();
    }

    /** Add Third Category */

    public function addThirdCategoryDetails($id, $catSlug)
    {
        $main_cat = Category::findOrFail($id);
        if ($main_cat) {
            return view('admin.settings.add-third-category', compact('main_cat'));
        }
        Session::flash('error', 'Oops!, Something went wrong.');
        return back();
    }

    /** Manage Third Categories */

    public function getThirdCategoryListing($id = "")
    {
        $categories = Category::where(['sub_category_id' => $id, 'category_type' => 3])->orderBy('category_name')->get();
        return view('admin.settings.manage-third-categories', compact('categories'));
    }

    /** Add Fourth Level Category */

    public function addFourthCategoryDetails($id, $catSlug)
    {
        $main_cat = Category::findOrFail($id);
        if ($main_cat) {
            return view('admin.settings.add-fourth-category', compact('main_cat'));
        }
        Session::flash('error', 'Oops!, Something went wrong.');
        return back();
    }

    /** Manage Fourth Level Categories */

    public function getFourthCategoryListing($id = "")
    {
        $categories = Category::where(['sub_category_id' => $id, 'category_type' => 4])->orderBy('category_name')->get();
        return view('admin.settings.manage-fourth-categories', compact('categories'));
    }

    /** Add Banner Image */

    public function addBannerImage()
    {
        return view('admin.settings.add-banner-image');
    }

    /** Post Banner Image */

    public function postBannerImage(Request $request)
    {
        $this->validate($request, [
            'banner_image_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'banner_image_name_ar' => 'required',
            'banner_image_redirect' => 'nullable', 'regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'banner_image' => 'required|max:2048',
            'image_text' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'image_text_ar' => 'required',
        ]);
        $banner = new Banner;
        $banner->setTranslation('image_name', 'en', $request->banner_image_name)->setTranslation('image_name', 'ar', $request->banner_image_name_ar)->save();
        $banner->setTranslation('image_text', 'en', $request->image_text)->setTranslation('image_text', 'ar', $request->image_text_ar)->save();
        $banner->redirect_url = $request->banner_image_redirect;
        $banner->status = $request->status;
        $banner->modified_by = auth()->user()->id;
        $banner->app_type = $request->appType;

        if (isset($request->banner_image)) {
            $imageName = time() . '.' . $request->banner_image->getClientOriginalExtension();
            $request->banner_image->move(public_path('uploads/banners'), $imageName);
            $banner->image = $imageName;
        }
        $banner->status = 1;
        $banner->save();
        return redirect('admin/manage-banner-images');
    }

    /** Manage Banner Images */

    public function manageBannerImages()
    {
        $banners = Banner::get();
        return view('admin.settings.manage-banners', compact('banners'));
    }

    /** Edit banner information */

    public function getBannerDetails($id = "")
    {
        $banner = Banner::findOrFail($id);
        return view('admin.settings.edit-banner-image', compact('banner'));
    }

    /** Update banner information */

    public function updateBannerDetails($id, Request $request)
    {
        $this->validate($request, [
            'banner_image_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'banner_image_name_ar' => 'required',
            'banner_image_redirect' => 'nullable', 'regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'banner_image' => 'nullable|max:2048',
            'image_text' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'image_text_ar' => 'required',
        ]);
        $banner = Banner::findOrFail($id);
        $banner->setTranslation('image_name', 'en', $request->banner_image_name)->setTranslation('image_name', 'ar', $request->banner_image_name_ar)->save();
        $banner->setTranslation('image_text', 'en', $request->image_text)->setTranslation('image_text', 'ar', $request->image_text_ar)->save();
        $banner->redirect_url = $request->banner_image_redirect;
        $banner->status = $request->status;
        $banner->modified_by = auth()->user()->id;
        $banner->app_type = $request->appType;

        if (isset($request->banner_image)) {
            if (File::exists(public_path() . '/uploads/banners/' . $banner->image)) {
                unlink(public_path() . '/uploads/banners/' . $banner->image);
            }
            $imageName = time() . '.' . $request->banner_image->getClientOriginalExtension();
            $request->banner_image->move(public_path('uploads/banners'), $imageName);
            $banner->image = $imageName;
        }
        $banner->status = 1;
        $banner->save();
        Session::flash('success', "Banner information has been successfully updated.");
        return redirect('admin/manage-banner-images');
    }

    /** Update Banner Status */

    public function updateBannerStatus($id, $type)
    {
        $banner = Banner::findOrFail($id);
        if ($banner) {
            $banner->status = ($type == 'block') ? 0 : 1;
            $banner->save();
            Session::flash('success', "Banner status has been updated.");
            return 1;
        }
    }

    /** Delete Banner */

    public function deleteBanner($id)
    {
        Banner::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        Banner::findOrFail($id)->delete();
        return 1;
    }

    /** Add Brand */

    public function addBrandInformation()
    {
        return view('admin.settings.add-brand');
    }

    /** Post Banner Image */

    public function postBrandInformation(Request $request)
    {
        $this->validate($request, [
            'brand_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'brand_name_ar' => 'required',
            'brand_image' => 'required|image|max:2048',
        ]);
        $brand = new Brand;
        $brand->setTranslation('brand_name', 'en', $request->brand_name)->setTranslation('brand_name', 'ar', $request->brand_name_ar)->save();
        $brand->modified_by = auth()->user()->id;
        $brand->app_type = $request->appType;

        if (isset($request->brand_image)) {
            $imageName = time() . '.' . $request->brand_image->getClientOriginalExtension();
            $request->brand_image->move(public_path('uploads/brands'), $imageName);
            $brand->image = $imageName;
        }
        $brand->status = 1;
        $brand->save();
        Session::flash('success', "Brand information has been successfully added.");
        return redirect('admin/manage-brands');
    }

    /** Manage Banner Images */

    public function manageBrandInformation()
    {
        $brands = Brand::get();
        return view('admin.settings.manage-brands', compact('brands'));
    }

    /** Edit banner information */

    public function getBrandDetails($id = "")
    {
        $brand = Brand::findOrFail($id);
        return view('admin.settings.edit-brand', compact('brand'));
    }

    /** Update brand information */

    public function updateBrandDetails($id, Request $request)
    {
        $this->validate($request, [
            'brand_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'brand_name_ar' => 'required',
            'brand_image' => 'nullable|image|max:2048',
        ]);
        $brand = Brand::findOrFail($id);
        $brand->setTranslation('brand_name', 'en', $request->brand_name)->setTranslation('brand_name', 'ar', $request->brand_name_ar)->save();
        $brand->modified_by = auth()->user()->id;
        $brand->app_type = $request->appType;

        if (isset($request->brand_image)) {
            if (File::exists(public_path() . '/uploads/brands/' . $brand->image)) {
                unlink(public_path() . '/uploads/brands/' . $brand->image);
            }
            $imageName = time() . '.' . $request->brand_image->getClientOriginalExtension();
            $request->brand_image->move(public_path('uploads/brands'), $imageName);
            $brand->image = $imageName;
        }
        $brand->status = 1;
        $brand->save();
        Session::flash('success', "Brand information has been successfully added.");
        return redirect('admin/manage-brands');
    }

    /** Update Banner Status */

    public function updateBrandStatus($id, $type)
    {
        $brand = Brand::findOrFail($id);
        if ($brand) {
            $brand->status = ($type == 'block') ? 0 : 1;
            $brand->save();
            Session::flash('success', "Brand status has been updated.");
            return 1;
        }
    }

    /** Delete Banner */

    public function deleteBrand($id)
    {
        Brand::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        Brand::findOrFail($id)->delete();
        return 1;
    }

    /** Manage Attribute Types */

    public function manageAttributeTypes()
    {
        $attributes = AttributeTypes::get();
        return view('admin.settings.manage-attribute-types', compact('attributes'));
    }

    /** Post Attribute Type Data */

    public function postAttributeType(Request $request)
    {
        $this->validate($request, [
            'attribute_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'attribute_name_ar' => 'required',
            'attribute_category' => 'required',
        ]);
        $attrType = new AttributeTypes;
        $attrType->setTranslation('attribute_name', 'en', $request->attribute_name)->setTranslation('attribute_name', 'ar', $request->attribute_name_ar)->save();
        $attrType->attribute_type = $request->attribute_category;
        $attrType->modified_by = auth()->user()->id;
        $attrType->status = 1;
        $attrType->save();
        Session::flash('success', "Attribute information has been successfully added.");
        return redirect('admin/manage-attribute-types');
    }

    /** Post Update Attribute Type Data */

    public function updateAttributeType(Request $request, $attrID = "")
    {
        $this->validate($request, [
            'attribute_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'attribute_name_ar' => 'required',
            'attribute_category' => 'required',
        ]);
        $attrType = AttributeTypes::findOrFail($attrID);
        $attrType->setTranslation('attribute_name', 'en', $request->attribute_name)->setTranslation('attribute_name', 'ar', $request->attribute_name_ar)->save();
        $attrType->attribute_type = $request->attribute_category;
        $attrType->modified_by = auth()->user()->id;
        $attrType->status = 1;
        $attrType->save();
        Session::flash('success', "Attribute information has been successfully updated.");
        return redirect('admin/manage-attribute-types');
    }

    /** Add Faq */

    public function addFaqInformation()
    {
        return view('admin.settings.add-faq');
    }

    /** Post Faq */

    public function postFaqInformation(Request $request)
    {
        $this->validate($request, [
            'title' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'title_ar' => 'required',
        ]);

        $faq = new Faq;
        $faq->setTranslation('title', 'en', $request->title)->setTranslation('title', 'ar', $request->title_ar)->save();
        $faq->setTranslation('description', 'en', $request->description)->setTranslation('description', 'ar', $request->description_ar)->save();
        $faq->modified_by = auth()->user()->id;
        $faq->app_type = $request->appType;
        $faq->status = 1;
        $faq->save();

        Session::flash('success', "Faq information has been successfully added.");
        return redirect('admin/manage-faq');
    }

    /** Manage Faq */

    public function manageFaqInformation()
    {
        $faqs = Faq::get();
        return view('admin.settings.manage-faq', compact('faqs'));
    }

    /** Edit Faq */

    public function getFaqDetails($id = "")
    {
        $faq = Faq::findOrFail($id);
        return view('admin.settings.edit-faq', compact('faq'));
    }

    /** Update faq information */

    public function updateFaqDetails($id, Request $request)
    {
        $this->validate($request, [
            'title' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'title_ar' => 'required',
        ]);

        $faq = Faq::findOrFail($id);
        $faq->setTranslation('title', 'en', $request->title)->setTranslation('title', 'ar', $request->title_ar)->save();
        $faq->setTranslation('description', 'en', $request->description)->setTranslation('description', 'ar', $request->description_ar)->save();
        $faq->modified_by = auth()->user()->id;
        $faq->app_type = $request->appType;
        $faq->status = 1;
        $faq->save();

        Session::flash('success', "Faq information has been successfully added.");
        return redirect('admin/manage-faq');
    }

    /** Delete Faq */

    public function deleteFaq($id)
    {
        Faq::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        Faq::findOrFail($id)->delete();
        return 1;
    }

    /** Update Faq Status */

    public function updateFaqStatus($id, $type)
    {
        $faq = Faq::findOrFail($id);
        if ($faq) {
            $faq->status = ($type == 'block') ? 0 : 1;
            $faq->save();
            Session::flash('success', "Faq status has been updated.");
            return 1;
        }
    }

    /** Add Promo Ad */

    public function addAdsimageInformation()
    {
        return view('admin.settings.add-promo-ad');
    }

    /** Post Promo Ad Image */

    public function postAdsimageInformation(Request $request)
    {
        $this->validate($request, [
            'ad_title' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'ad_title_ar' => 'required',
            'ad_image' => 'required|image',
            'redirect_url' => ['required', 'regex:/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i'],
        ]);

        $result = PromoAds::where('status', '=', '1')->count();
        if ($result == 2) {
            Session::flash('success', "Sorry!, You have reached maximum ad limit. Please deactivate and continue.");
            return redirect('admin/manage-promo-ad');
        } else {
            $promoad = new PromoAds;
            $promoad->setTranslation('ad_title', 'en', $request->ad_title)->setTranslation('ad_title', 'ar', $request->ad_title_ar)->save();
            $promoad->modified_by = auth()->user()->id;
            $promoad->app_type = $request->appType;
            $promoad->page_display = $request->page_display;
            $promoad->start_date = $request->start_date;
            $promoad->end_date = $request->end_date;
            $promoad->redirect_url = $request->redirect_url;
            $promoad->redirect_type = $request->redirect_type;
            $promoad->status = 1;
            if (isset($request->ad_image)) {
                $imageName = time() . '.' . $request->ad_image->getClientOriginalExtension();
                $request->ad_image->move(public_path('uploads/ads'), $imageName);
                $promoad->ad_image = $imageName;
            }
            $promoad->save();

            Session::flash('success', "Promo ads has been successfully added.");
            return redirect('admin/manage-promo-ad');
        }
    }

    /** Manage Promo Ad Image */

    public function manageAdsimageInformation()
    {
        $adsimages = PromoAds::get();
        return view('admin.settings.manage-promo-ad', compact('adsimages'));
    }

    /** Edit Promo Ad Image */

    public function getAdsimageDetails($id = "")
    {
        $adsimage = PromoAds::findOrFail($id);
        return view('admin.settings.edit-promo-ad', compact('adsimage'));
    }

    /** Update Promo Ad Image */

    public function updateAdsimageDetails($id, Request $request)
    {
        $this->validate($request, [
            'ad_title' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'ad_title_ar' => 'required',
            'redirect_url' => ['required', 'regex:/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i'],
        ]);

        $promoad = PromoAds::findOrFail($id);
        $promoad->setTranslation('ad_title', 'en', $request->ad_title)->setTranslation('ad_title', 'ar', $request->ad_title_ar)->save();
        $promoad->modified_by = auth()->user()->id;
        $promoad->app_type = $request->appType;
        $promoad->page_display = $request->page_display;
        $promoad->start_date = $request->start_date;
        $promoad->end_date = $request->end_date;
        $promoad->redirect_url = $request->redirect_url;
        $promoad->redirect_type = $request->redirect_type;
        $promoad->status = 1;
        if (isset($request->ad_image)) {
            $imageName = time() . '.' . $request->ad_image->getClientOriginalExtension();
            $request->ad_image->move(public_path('uploads/ads'), $imageName);
            $promoad->ad_image = $imageName;
        }
        $promoad->save();

        Session::flash('success', "Promo ad has been successfully updated.");
        return redirect('admin/manage-promo-ad');
    }

    /** Delete Promo Ad Image */

    public function deleteAdsimage($id)
    {
        PromoAds::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        PromoAds::findOrFail($id)->delete();
        return 1;
    }

    /** Update Promo Ad Image Status */

    public function updateAdsimageStatus($id, $type)
    {
        $brand = PromoAds::findOrFail($id);
        if ($brand) {
            $brand->status = ($type == 'block') ? 0 : 1;
            $brand->save();
            Session::flash('success', "Promo ad status has been updated.");
            return 1;
        }
    }

    /** Add Promo Video */

    public function addAdsvideoInformation()
    {
        return view('admin.settings.add-promo-video');
    }

    /** Post Promo Video */

    public function postAdsvideoInformation(Request $request)
    {
        $this->validate($request, [
            'video_title' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'video_title_ar' => 'required',
        ]);

        $adsvideo = new PromoVideos;
        $adsvideo->setTranslation('video_title', 'en', $request->video_title)->setTranslation('video_title', 'ar', $request->video_title_ar)->save();
        $adsvideo->modified_by = auth()->user()->id;
        $adsvideo->app_type = $request->appType;
        $adsvideo->video_link = $request->video_link;
        $adsvideo->status = 1;
        $adsvideo->save();

        Session::flash('success', "Promo video  has been successfully added.");
        return redirect('admin/manage-promo-video');
    }

    /** Manage Promo Video */

    public function manageAdsvideoInformation()
    {
        $adsvideos = PromoVideos::get();
        return view('admin.settings.manage-promo-video', compact('adsvideos'));
    }

    /** Edit Promo Video */

    public function getAdsvideoDetails($id = "")
    {
        $adsvideo = PromoVideos::findOrFail($id);
        return view('admin.settings.edit-promo-video', compact('adsvideo'));
    }

    /** Update Promo Video */

    public function updateAdsvideoDetails($id, Request $request)
    {
        $this->validate($request, [
            'video_title' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'video_title_ar' => 'required',
        ]);

        $promovideo = PromoVideos::findOrFail($id);
        $promovideo->setTranslation('video_title', 'en', $request->video_title)->setTranslation('video_title', 'ar', $request->video_title_ar)->save();
        $promovideo->modified_by = auth()->user()->id;
        $promovideo->app_type = $request->appType;
        $promovideo->video_link = $request->video_link;
        $promovideo->status = 1;
        $promovideo->save();

        Session::flash('success', "Promo video has been successfully updated.");
        return redirect('admin/manage-promo-video');
    }

    /** Delete Promo Video */

    public function deleteAdsvideo($id)
    {
        PromoVideos::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        PromoVideos::findOrFail($id)->delete();
        return 1;
    }

    /** Update Promo Video Status */

    public function updateAdsvideoStatus($id, $type)
    {
        $promovideo = PromoVideos::findOrFail($id);
        if ($promovideo) {
            $promovideo->status = ($type == 'block') ? 0 : 1;
            $promovideo->save();
            Session::flash('success', "Adsimage status has been updated.");
            return 1;
        }
    }

    /** Add Programme */

    public function addProgrammeInformation()
    {
        return view('admin.settings.add-programme');
    }

    /** Post Programme */

    public function postProgrammeInformation(Request $request)
    {
        $this->validate($request, [
            'video_title' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'video_title_ar' => 'required',
        ]);

        $appprogramme = new AppProgramme;
        $appprogramme->setTranslation('video_title', 'en', $request->video_title)->setTranslation('video_title', 'ar', $request->video_title_ar)->save();
        $appprogramme->modified_by = auth()->user()->id;
        $appprogramme->app_type = $request->appType;
        $appprogramme->video_link = $request->video_link;
        $appprogramme->status = 1;
        $appprogramme->save();

        Session::flash('success', "Programme information has been successfully added.");
        return redirect('admin/manage-promo-video');
    }

    /** Manage Programme */

    public function manageMembershipInformation()
    {
        $memberships = AppProgramme::where('programme_type', 0)->get();
        return view('admin.settings.manage-programme', compact('memberships'));
    }

    /** Edit Membership Plan */

    public function getmeMbershipDetails($id = "")
    {
        $appprogramme = AppProgramme::findOrFail($id);
        return view('admin.settings.edit-membership', compact('appprogramme'));
    }

    /** Update Membership Plan information */

    public function updateMbershipDetails($id, Request $request)
    {
        $this->validate($request, [
            'title' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'price' => 'required|numeric|not_in:0',
            'duration' => 'required|numeric',
        ]);

        $mbership = AppProgramme::findOrFail($id);
        $mbership->setTranslation('title', 'en', $request->title)->setTranslation('title', 'ar', $request->title_ar)->save();
        $mbership->setTranslation('description', 'en', $request->description)->setTranslation('description', 'ar', $request->description_ar)->save();
        $mbership->modified_by = auth()->user()->id;
        $mbership->app_type = $request->appType;
        $mbership->price = $request->price;
        $mbership->points = $request->points;
        $mbership->duration = $request->duration;
        $mbership->programme_type = 0;
        $mbership->status = 1;
        $mbership->save();

        Session::flash('success', "Membership plan has been successfully updated.");
        return redirect('admin/manage-membership');
    }

    /** Update Mbership Plan Status */

    public function updateMbershipStatus($id, $type)
    {
        $mbership = AppProgramme::findOrFail($id);
        if ($mbership) {
            $mbership->status = ($type == 'block') ? 0 : 1;
            $mbership->save();
            Session::flash('success', "Mbership plan status has been updated.");
            return 1;
        }
    }

    /** Manage Referral */

    public function manageReferralInformation()
    {
        $memberships = AppProgramme::where('programme_type', 1)->get();
        return view('admin.settings.manage-referral', compact('memberships'));
    }

    /** Edit Referral Plan */

    public function getReferralDetails($id = "")
    {
        $appprogramme = AppProgramme::findOrFail($id);
        return view('admin.settings.edit-referral', compact('appprogramme'));
    }

    /** Update Referral Programme Status */

    public function updateReferralStatus($id, $type)
    {
        $referral = AppProgramme::findOrFail($id);
        if ($referral) {
            $referral->status = ($type == 'block') ? 0 : 1;
            $referral->save();
            Session::flash('success', "Referral programme status has been updated.");
            return 1;
        }
    }

    /** Update Referral Plan information */

    public function updateReferralDetails($id, Request $request)
    {
        $this->validate($request, [
            'title' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'price' => 'required|numeric|not_in:0',
            'points' => 'required|numeric',
        ]);

        $appprogramme = AppProgramme::findOrFail($id);
        $appprogramme->setTranslation('title', 'en', $request->title)->setTranslation('title', 'ar', $request->title_ar)->save();
        $appprogramme->setTranslation('description', 'en', $request->description)->setTranslation('description', 'ar', $request->description_ar)->save();
        $appprogramme->modified_by = auth()->user()->id;
        $appprogramme->app_type = $request->appType;
        $appprogramme->price = $request->price;
        $appprogramme->points = $request->points;
        $appprogramme->programme_type = 1;
        $appprogramme->status = 1;
        $appprogramme->save();

        Session::flash('success', "Reward programme has been successfully updated.");
        return redirect('admin/manage-referral');
    }

    /** Manage Reward */

    public function manageRewardInformation()
    {
        $memberships = AppProgramme::where('programme_type', 2)->get();
        return view('admin.settings.manage-reward', compact('memberships'));
    }

    /** Edit Reward */

    public function getRewardDetails($id = "")
    {
        $appprogramme = AppProgramme::findOrFail($id);
        return view('admin.settings.edit-reward', compact('appprogramme'));
    }

    /** Update Reward information */

    public function updateRewardDetails($id, Request $request)
    {
        $this->validate($request, [
            'title' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'price' => 'nullable|numeric|not_in:0',
            'points' => 'required|numeric',
        ]);

        $reward = AppProgramme::findOrFail($id);
        $reward->setTranslation('title', 'en', $request->title)->setTranslation('title', 'ar', $request->title_ar)->save();
        $reward->setTranslation('description', 'en', $request->description)->setTranslation('description', 'ar', $request->description_ar)->save();
        $reward->modified_by = auth()->user()->id;
        $reward->app_type = $request->appType;
        $reward->price = $request->price;
        $reward->points = $request->points;
        $reward->programme_type = 2;
        $reward->status = 1;
        $reward->save();

        Session::flash('success', "Referral program information has been successfully updated.");
        return redirect('admin/manage-reward');
    }

    /** Update Reward Status */

    public function updateRewardStatus($id, $type)
    {
        $appprogramme = AppProgramme::findOrFail($id);
        if ($appprogramme) {
            $appprogramme->status = ($type == 'block') ? 0 : 1;
            $appprogramme->save();
            Session::flash('success', "Reward programme status has been updated.");
            return 1;
        }
    }

    /** Delete Programme */

    public function deleteProgramme($id)
    {
        AppProgramme::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        AppProgramme::findOrFail($id)->delete();
        return 1;
    }

    /** Update Programme Status */

    public function updateProgrammeStatus($id, $type)
    {
        $appprogramme = AppProgramme::findOrFail($id);
        if ($appprogramme) {
            $appprogramme->status = ($type == 'block') ? 0 : 1;
            $appprogramme->save();
            Session::flash('success', "Programme status has been updated.");
            return 1;
        }
    }

    /** Get Payment Settings */

    public function getPaymentSettings()
    {
        $isSuccess = (session()->has('success')) ? session()->get('success') : "";
        $setting = Settings::findOrFail(1);
        return view('admin.settings.payment-settings', compact('setting', 'isSuccess'));
    }

    /** Update Payment Settings */

    public function updatePaymentSettings(Request $request)
    {
        $settings = Settings::findOrFail(1);
        $settings->express_delivery_hrs = $request->express_delivery_hrs;
        $settings->standard_delivery_hrs = $request->standard_delivery_hrs;
        $settings->schedule_delivery_hrs = $request->schedule_delivery_hrs;
        $settings->express_delivery = $request->express_delivery;
        $settings->standard_delivery = $request->standard_delivery;
        $settings->scheduled_delivery = $request->scheduled_delivery;
        $settings->currency_code = $request->currency_code;
        $settings->country_code = $request->country_code;
        $settings->paypal_account = $request->paypal_account;
        $settings->paypal_api = $request->paypal_api;
        $settings->paypal_signature = $request->paypal_signature;
        $settings->migs_merchant_id = $request->migs_merchant_id;
        $settings->migs_access_code = $request->migs_access_code;
        $settings->migs_secret_key = $request->migs_secret_key;
        $settings->naps_merchant_id = $request->naps_merchant_id;
        $settings->naps_bank_id = $request->naps_bank_id;
        $settings->naps_secret_key = $request->naps_secret_key;
        $settings->payment_mode = ($request->payment_mode == 1) ? 1 : 0;
        $settings->save();

        Session::flash('success', "Payment settings has been updated.");
        return redirect('admin/payment-settings');
    }

    /** Add Page */

    public function addPageInformation()
    {
        return view('admin.settings.add-page');
    }

    /** Post Page */

    public function postPageInformation(Request $request)
    {
        $this->validate($request, [
            'page_title' => 'required', 'regex:/^[A-Za-z _-]+$/',
        ]);

        $page = new StaticPages;
        $page->setTranslation('page_title', 'en', $request->page_title)->setTranslation('page_title', 'ar', $request->page_title_ar)->save();
        $page->setTranslation('page_content', 'en', $request->page_content)->setTranslation('page_content', 'ar', $request->page_content_ar)->save();
        $page->modified_by = auth()->user()->id;
        $page->slug = Str::of($request->page_title)->slug('-');
        $page->app_type = $request->appType;
        $page->status = 1;
        $page->save();

        Session::flash('success', "$request->page_title has been successfully added.");
        return redirect('admin/manage-page');
    }

    /** Manage Page */

    public function managePageInformation()
    {
        $adsimages = StaticPages::get();
        return view('admin.settings.manage-page', compact('adsimages'));
    }

    /** Edit Page */

    public function getPageDetails($id = "")
    {
        $page = StaticPages::findOrFail($id);
        return view('admin.settings.edit-page', compact('page'));
    }

    /** Update Page */

    public function updatePageDetails($id, Request $request)
    {
        $this->validate($request, [
            'page_title' => 'required', 'regex:/^[A-Za-z _-]+$/',
        ]);

        $page = StaticPages::findOrFail($id);
        $page->setTranslation('page_title', 'en', $request->page_title)->setTranslation('page_title', 'ar', $request->page_title_ar)->save();
        $page->setTranslation('page_content', 'en', $request->page_content)->setTranslation('page_content', 'ar', $request->page_content_ar)->save();
        $page->modified_by = auth()->user()->id;
        $page->app_type = $request->appType;
        $page->slug = Str::of($request->page_title)->slug('-');
        $page->status = 1;
        $page->save();

        Session::flash('success', "$request->page_title has been successfully updated.");
        return redirect('admin/manage-page');
    }

    /** Delete Page */

    public function deletePage($id)
    {
        StaticPages::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        StaticPages::findOrFail($id)->delete();
        return 1;
    }

    /** Update Page Status */

    public function updatePageStatus($id, $type)
    {
        $page = StaticPages::findOrFail($id);
        if ($page) {
            $page->status = ($type == 'block') ? 0 : 1;
            $page->save();
            Session::flash('success', "Page status has been updated.");
            return 1;
        }
    }

    /** Add Social Review */

    public function addSocialReview()
    {
        return view('admin.settings.add-social-review');
    }

    /** Post Social Review */

    public function postSocialReview(Request $request)
    {
        $this->validate($request, [
            'name' => 'required', 'regex:/^[A-Za-z _-]+$/|max:50',
            'posted_date' => 'required',
            'comments' => 'required',
        ]);

        $socialmediareview = new SocialMediaReviews;
        $socialmediareview->name = $request->name;
        $socialmediareview->comments = $request->comments;
        $socialmediareview->modified_by = auth()->user()->id;
        $socialmediareview->app_type = $request->appType;
        $socialmediareview->media_type = $request->media_type;
        $socialmediareview->rating = $request->rating;
        $socialmediareview->posted_date = date('Y-m-d', strtotime($request->posted_date));
        $socialmediareview->status = 1;

        if (isset($request->image)) {
            $imageName = time() . '.' . $request->image->getClientOriginalExtension();
            $request->image->move(public_path('uploads/sm-reviews'), $imageName);
            $socialmediareview->image = $imageName;
        }
        $socialmediareview->save();
        Session::flash('success', "Social review has been successfully added.");
        return redirect('admin/manage-social-review');

    }

    /** Manage Social Review */

    public function manageSocialReview()
    {
        $adsimages = SocialMediaReviews::get();
        return view('admin.settings.manage-social-review', compact('adsimages'));
    }

    /** Edit Social Review */

    public function getSocialReviewDetails($id = "")
    {
        $socialmediareview = SocialMediaReviews::findOrFail($id);
        return view('admin.settings.edit-social-review', compact('socialmediareview'));
    }

    /** Update Social Review */

    public function updateSocialReview($id, Request $request)
    {
        $this->validate($request, [
            'name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'posted_date' => 'required',
            'comments' => 'required',
        ]);

        $socialmediareview = SocialMediaReviews::findOrFail($id);
        $socialmediareview->name = $request->name;
        $socialmediareview->comments = $request->comments;
        $socialmediareview->modified_by = auth()->user()->id;
        $socialmediareview->app_type = $request->appType;
        $socialmediareview->media_type = $request->media_type;
        $socialmediareview->rating = $request->rating;
        $socialmediareview->posted_date = date('Y-m-d', strtotime($request->posted_date));
        $socialmediareview->status = 1;
        if (isset($request->image)) {
            $imageName = time() . '.' . $request->image->getClientOriginalExtension();
            $request->image->move(public_path('uploads/sm-reviews'), $imageName);
            $socialmediareview->image = $imageName;
        }
        $socialmediareview->save();
        Session::flash('success', "Social review has been successfully added.");
        return redirect('admin/manage-social-review');
    }

    /** Update Social Review */

    public function updateSocialReviewStatus($id, $type)
    {
        $page = SocialMediaReviews::findOrFail($id);
        if ($page) {
            $page->status = ($type == 'block') ? 0 : 1;
            $page->save();
            Session::flash('success', "Social media review status has been updated.");
            return 1;
        }
    }

    /** Update Social Settings Highlight */

    public function highlightSMReview(Request $request)
    {
        if($request->status == 1) {
            $result = SocialMediaReviews::where('is_higlight', '=', '1')->count();
            if ($result == 4) {
                Session::flash('error', "Sorry!, You're already reached maximum limit four. Please deactivate anyone to proceed further.");
                return 0;
            }
        }
        $user = SocialMediaReviews::find($request->id);
        $user->is_higlight = $request->status;
        $user->save();
        ($request->status == 1)?Session::flash('success', "Review successfully highlighted."):Session::flash('success', "Review successfully moved to normal listing.");
        return 1;
    }

    /** Delete Social Review */

    public function deleteSocialReview($id)
    {
        SocialMediaReviews::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        SocialMediaReviews::findOrFail($id)->delete();
        return 1;
    }

    /** Get Social Settings */

    public function getSocialSettings()
    {
        $setting = SocialMediaSettings::findOrFail(1);
        return view('admin.settings.social-settings', compact('setting'));
    }

    /** Update Social Settings */

    public function updateSocialSettings(Request $request)
    {
        $settings = SocialMediaSettings::findOrFail(1);
        $settings->facebook = $request->facebook;
        $settings->twiter = $request->twiter;
        $settings->linkedin = $request->linkedin;
        $settings->youtube = $request->youtube;
        $settings->snapchat = $request->snapchat;
        $settings->instagram = $request->instagram;
        $settings->android_app = $request->android_app;
        $settings->ios_app = $request->ios_app;
        $settings->google_analytics = $request->google_analytics;
        $settings->google_tag = $request->google_tag;
        $settings->facebook_sdk = $request->facebook_sdk;
        $settings->app_type = 1;
        $settings->save();

        Session::flash('success', "Social settings has been updated.");
        return redirect('admin/social-settings');
    }  

    /** Get Module Settings */

    public function getModuleSettings()
    {
        $setting = ModuleSettings::findOrFail(1);
        return view('admin.settings.module-settings', compact('setting'));
    }

    /** Update Module Settings */

    public function updateModuleSettings(Request $request)
    {
        $settings = ModuleSettings::findOrFail(1);
        $settings->is_credit_card = $request->is_credit_card;
        $settings->is_debit_card = $request->is_debit_card;
        $settings->paypal = $request->paypal;
        $settings->cod = $request->cod;
        $settings->app_type = $request->appType;
        $settings->save();

        Session::flash('success', "Module settings has been updated.");
        return redirect('admin/module-settings');
    }

    /** Get Logo favicon */

    public function getLogofaviconSettings()
    {
        $setting = Settings::findOrFail(1);
        return view('admin.settings.logo-favicon-settings', compact('setting'));
    }

    /** Update Logo favicon Settings */

    public function updateLogofaviconSettings(Request $request)
    {
        $this->validate($request, [
            'logo' => 'image|mimes:jpeg,png,jpg,gif,svg',
            'favicon' => 'image|mimes:jpeg,png,jpg,gif,svg',
            'logo_ar' => 'image|mimes:jpeg,png,jpg,gif,svg',
            'favicon_ar' => 'image|mimes:jpeg,png,jpg,gif,svg',
        ]);

        $settings = Settings::findOrFail(1);
        if (isset($request->logo)) {
            $imageName = time() . '.' . $request->logo->getClientOriginalExtension();
            $request->logo->move(public_path('uploads/image'), $imageName);
            $settings->logo = $imageName;
        }

        if (isset($request->favicon)) {
            $imageName = time() . '.' . $request->favicon->getClientOriginalExtension();
            $request->favicon->move(public_path('uploads/image'), $imageName);
            $settings->favicon = $imageName;
        }

        if (isset($request->logo_ar)) {
            $imageName = time() . '.' . $request->logo_ar->getClientOriginalExtension();
            $request->logo_ar->move(public_path('uploads/image'), $imageName);
            $settings->logo_ar = $imageName;
        }

        if (isset($request->favicon_ar)) {
            $imageName = time() . '.' . $request->favicon_ar->getClientOriginalExtension();
            $request->favicon_ar->move(public_path('uploads/image'), $imageName);
            $settings->favicon_ar = $imageName;
        }
        $settings->save();

        Session::flash('success', "Logo & Favicon settings has been updated.");
        return redirect('admin/logo-favicon-settings');
    }
}
