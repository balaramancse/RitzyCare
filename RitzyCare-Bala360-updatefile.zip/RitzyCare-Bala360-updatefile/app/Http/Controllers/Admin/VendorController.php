<?php

namespace App\Http\Controllers\Admin;

use AppHelpers;
use App\Http\Controllers\Controller;
use App\Mail\VendorRegistrations;
use App\Models\Admin;
use App\Models\Area;
use App\Models\Stores;
use App\Models\VendorMarginDetails;
use App\Models\VendorPayouts;
use App\Models\Zones;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Mail;
use Session;
use Validator;

class VendorController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    /** Add Vendor Information */

    public function getAddVendor()
    {
        $zones = Zones::where('status', 1)->orderBy('zone_name')->get();
        $areas = Area::where('status', 1)->orderBy('area_name')->get();
        return view('admin.vendors.add-vendor', compact('zones', 'areas'));
    }

    /** Post Vendor Information */

    public function postVendorInformation(Request $request)
    {
        Validator::make($request->all(), [
            'first_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'last_name' => 'nullable', 'regex:/^[A-Za-z _-]+$/',
            'vendor_email' => 'required | email | unique:admins,email',
            'vendor_contact' => 'required | numeric',
            'vendor_margin' => 'required | numeric',
            'vendor_payout' => 'required',
            'finance_manager_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'finance_manager_email' => 'required | email',
            'finance_manager_contact' => 'required | numeric',
            'store_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'store_name_ar' => 'required',
            'store_contact' => 'required | numeric',
            'store_building' => 'required | numeric',
            'store_street_no' => 'nullable | numeric',
            'store_zone_no' => 'nullable | numeric',
            'store_landmark' => 'required',
            'store_manager_name' => 'required',
            'store_manager_email' => 'required',
            'store_manager_contact' => 'required',
            'store_zone' => 'required',
            'store_area' => 'required',
            'store_pobox' => 'required',
        ])->validate();

        $password = Str::random(8);
        $storeSlug = Str::of($request->store_name)->slug('-');

        $seller = new Admin;
        $seller->name = $request->first_name;
        $seller->last_name = $request->last_name;
        $seller->vendor_RCID = 'RC' . date('yhis');
        $seller->email = $request->vendor_email;
        $seller->password = bcrypt($password);
        $seller->contact_number = $request->vendor_contact;
        $seller->vendor_margin = $request->vendor_margin;
        $seller->vendor_payout = $request->vendor_payout;
        $seller->status = 1;
        $seller->modified_by = auth()->user()->id;
        $seller->app_type = $request->appType;
        $seller->user_type = 1;
        $seller->save();
        
        $seller->assignRole('Vendor');
        
        $sellerID = $seller->id;

        VendorMarginDetails::create([
            'margin_percentage' => $request->vendor_margin,
            'vendor_id' => $sellerID,
        ]);

        $store = new Stores;
        $store->setTranslation('store_name', 'en', $request->store_name)->setTranslation('store_name', 'ar', $request->store_name_ar)->save();
        $store->contact_number = $request->store_contact;
        $store->building_no = $request->store_building;
        $store->street_no = $request->store_street_no;
        $store->zone_no = $request->store_zone_no;
        $store->landmark = $request->store_landmark;
        $store->po_box = $request->store_pobox;
        $store->sm_name = $request->store_manager_name;
        $store->sm_email = $request->store_manager_email;
        $store->sm_contact_number = $request->store_manager_contact;
        $store->fm_name = $request->finance_manager_name;
        $store->fm_email = $request->finance_manager_email;
        $store->fm_contact_number = $request->finance_manager_contact;
        $store->zone_id = $request->store_zone;
        $store->area_id = $request->store_area;
        $store->slug = $storeSlug;
        $store->vendor_id = $sellerID;
        $store->status = 1;
        $store->modified_by = auth()->user()->id;
        $store->app_type = $request->appType;
        $store->save();

        $payCycle = AppHelpers::getPayCycleDetails($request->pay_cycle);
        $updateTrack = VendorPayouts::create([
            'vendor_id' => $sellerID,
            'paycycle_start' => $payCycle['startDate'],
            'paycycle_end' => $payCycle['endDate'],
        ]);

        $request['name'] = $request->first_name . ' ' . $request->last_name;
        $request['password'] = $password;
        $request['store_name'] = $request->store_name;

        Mail::to($request->vendor_email)->send(new VendorRegistrations($request));

        Session::flash('success', 'Vendor account has been created successfully.');
        return redirect('admin/manage-vendors');
    }

    /** Manage vendor information */

    public function manageVendorInformation()
    {
        $vendors = Admin::with('stores')->whereUserType(1)->orderby("admins.id", "DESC")->get();
        return view('admin.vendors.manage-vendors', compact('vendors'));
    }

    /** Edit vendor information */

    public function getVendorDetails($id = "")
    {
        $vendor = Admin::findOrFail($id);
        return view('admin.vendors.edit-vendor', compact('vendor'));
    }

    /** Post Vendor Update Information */

    public function updateVendorDetails(Request $request, $id = "")
    {
        Validator::make($request->all(), [
            'first_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'last_name' => 'nullable', 'regex:/^[A-Za-z _-]+$/',
            'vendor_email' => 'required | email | unique:admins,email,' . $id,
            'vendor_contact' => 'required | numeric',
            'vendor_margin' => 'required | numeric',
            'vendor_payout' => 'required',
        ])->validate();

        $seller = Admin::findOrFail($id);
        $seller->name = $request->first_name;
        $seller->last_name = $request->last_name;
        $seller->email = $request->vendor_email;
        $seller->contact_number = $request->vendor_contact;
        $seller->vendor_margin = $request->vendor_margin;
        $seller->vendor_payout = $request->vendor_payout;
        $seller->status = 1;
        $seller->modified_by = auth()->user()->id;
        $seller->app_type = $request->appType;
        $seller->user_type = 1;
        $seller->save();

        $sellerID = $seller->id;

        $removeEx = VendorMarginDetails::where('vendor_id', $sellerID)->forceDelete();
        VendorMarginDetails::create([
            'margin_percentage' => $request->vendor_margin,
            'vendor_id' => $sellerID,
        ]);

        $payCycle = AppHelpers::getPayCycleDetails($request->pay_cycle);
        $exDet = VendorPayouts::where(['vendor_id' => $sellerID, 'is_active' => 1, 'status' => 1])->first();
        if (isset($exDet) && ($request->old_payout != $request->vendor_payout)) {
            $updateTrack = VendorPayouts::where('id', $exDet->id)->update([
                'vendor_id' => $sellerID,
                'paycycle_start' => $payCycle['startDate'],
                'paycycle_end' => $payCycle['endDate'],
            ]);
        } else {
            $updateTrack = VendorPayouts::create([
                'vendor_id' => $sellerID,
                'paycycle_start' => $payCycle['startDate'],
                'paycycle_end' => $payCycle['endDate'],
            ]);
        }
        Session::flash('success', 'Vendor account has been updated successfully.');
        return redirect('admin/manage-vendors');
    }

    /** Update vendor status */

    public function updateVendorStatus($id, $type)
    {
        $user = auth()->user();
        $vendor = Admin::findOrFail($id);
        if ($vendor) {
            $vendorStat = ($type == 'block') ? 0 : 1;
            $vendor->status = $vendorStat;
            $vendor->modified_by = $user->id;
            $vendor->save();
            Stores::whereVendorId($id)->update(['is_active' => $vendorStat, 'modified_by' => $user->id]);
            Session::flash('success', "Vendor status has been updated.");
            return 1;
        }
    }

    /** Delete Vendor */

    public function deleteVendor($id)
    {
        Admin::where('id', $id)->update(['status' => 0, "modified_by" => auth()->user()->id]);
        Admin::findOrFail($id)->delete();
        Stores::whereVendorId($id)->update(['is_active' => 0, 'modified_by' => auth()->user()->id]);
        echo 1;exit;
    }

    /** Add Vendor Store Information */

    public function getAddStore($vendorID = "")
    {
        $zones = Zones::where('status', 1)->orderBy('zone_name')->get();
        $areas = Area::where('status', 1)->orderBy('area_name')->get();
        return view('admin.vendors.add-vendor-store', compact('zones', 'areas', 'vendorID'));
    }

    /** Post Vendor Store Information */

    public function postVendorStoreInformation(Request $request, $sellerID = "")
    {
        Validator::make($request->all(), [
            'finance_manager_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'finance_manager_email' => 'required | email',
            'finance_manager_contact' => 'required | numeric',
            'store_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'store_name_ar' => 'required',
            'store_contact' => 'required | numeric',
            'store_building' => 'required | numeric',
            'store_street_no' => 'nullable | numeric',
            'store_zone_no' => 'nullable | numeric',
            'store_landmark' => 'required',
            'store_manager_name' => 'required',
            'store_manager_email' => 'required',
            'store_manager_contact' => 'required',
            'store_zone' => 'required',
            'store_area' => 'required',
            'store_pobox' => 'required',
        ])->validate();

        $storeSlug = Str::of($request->store_name)->slug('-');

        $store = new Stores;
        $store->setTranslation('store_name', 'en', $request->store_name)->setTranslation('store_name', 'ar', $request->store_name_ar)->save();
        $store->contact_number = $request->store_contact;
        $store->building_no = $request->store_building;
        $store->street_no = $request->store_street_no;
        $store->zone_no = $request->store_zone_no;
        $store->landmark = $request->store_landmark;
        $store->po_box = $request->store_pobox;
        $store->sm_name = $request->store_manager_name;
        $store->sm_email = $request->store_manager_email;
        $store->sm_contact_number = $request->store_manager_contact;
        $store->fm_name = $request->finance_manager_name;
        $store->fm_email = $request->finance_manager_email;
        $store->fm_contact_number = $request->finance_manager_contact;
        $store->zone_id = $request->store_zone;
        $store->area_id = $request->store_area;
        $store->slug = $storeSlug;
        $store->vendor_id = $sellerID;
        $store->status = 1;
        $store->modified_by = auth()->user()->id;
        $store->app_type = $request->appType;
        $store->save();

        Session::flash('success', 'Vendor store has been created successfully.');
        return redirect('admin/manage-vendors');
    }

    /** Manage Vendor Stores */

    public function manageVendorStores(Request $request, $sellerID = "")
    {
        $stores = Stores::with(['zone', 'area'])->where('vendor_id', $sellerID)->get();
        return view('admin.vendors.manage-vendor-stores', compact('stores'));
    }

    /** Edit Vendor Store Information */

    public function getVendorStoreDetails($id = "")
    {
        $zones = Zones::where('status', 1)->orderBy('zone_name')->get();
        $areas = Area::where('status', 1)->orderBy('area_name')->get();
        $store = Stores::findOrFail($id);
        return view('admin.vendors.edit-vendor-store', compact('store', 'areas', 'zones'));
    }

    /** Edit Vendor Store Information */

    public function updateVendorStoreDetails(Request $request, $id = "")
    {
        Validator::make($request->all(), [
            'finance_manager_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'finance_manager_email' => 'required | email',
            'finance_manager_contact' => 'required | numeric',
            'store_name' => 'required', 'regex:/^[A-Za-z _-]+$/',
            'store_name_ar' => 'required',
            'store_contact' => 'required | numeric',
            'store_building' => 'required | numeric',
            'store_street_no' => 'nullable | numeric',
            'store_zone_no' => 'nullable | numeric',
            'store_landmark' => 'required',
            'store_manager_name' => 'required',
            'store_manager_email' => 'required',
            'store_manager_contact' => 'required',
            'store_zone' => 'required',
            'store_area' => 'required',
            'store_pobox' => 'required',
        ])->validate();

        $storeSlug = Str::of($request->store_name)->slug('-');

        $store = Stores::findOrFail($id);
        $store->setTranslation('store_name', 'en', $request->store_name)->setTranslation('store_name', 'ar', $request->store_name_ar)->save();
        $store->contact_number = $request->store_contact;
        $store->building_no = $request->store_building;
        $store->street_no = $request->store_street_no;
        $store->zone_no = $request->store_zone_no;
        $store->landmark = $request->store_landmark;
        $store->po_box = $request->store_pobox;
        $store->sm_name = $request->store_manager_name;
        $store->sm_email = $request->store_manager_email;
        $store->sm_contact_number = $request->store_manager_contact;
        $store->fm_name = $request->finance_manager_name;
        $store->fm_email = $request->finance_manager_email;
        $store->fm_contact_number = $request->finance_manager_contact;
        $store->zone_id = $request->store_zone;
        $store->area_id = $request->store_area;
        $store->slug = $storeSlug;        
        $store->status = 1;
        $store->modified_by = auth()->user()->id;
        $store->app_type = $request->appType;
        $store->save();

        Session::flash('success', 'Vendor store information has been updated successfully.');
        return redirect('admin/manage-vendor-stores/'.$store->vendor_id);
    }

    /** Update vendor status */

    public function updateVendorStoreStatus($id, $type)
    {
        $user = auth()->user();
        $store = Stores::findOrFail($id);
        if ($store) {
            $storeStat = ($type == 'block') ? 0 : 1;
            $store->status = $storeStat;
            $store->modified_by = $user->id;
            $store->save();
            Session::flash('success', "Store status has been updated.");
            return 1;
        }
    }

    /** Delete Vendor */

    public function deleteVendorStore($id)
    {
        Stores::where('id', $id)->update(['status' => 0, 'is_active' => 0, "modified_by" => auth()->user()->id]);
        Stores::findOrFail($id)->delete();
        echo 1;exit;
    }
    
    /** Fetch Stores Information */

    public function getStoresList(Request $request)
    {
        return Stores::where(['vendor_id' => $request->vendorID,'is_active' => 1])->get();
    }
}
