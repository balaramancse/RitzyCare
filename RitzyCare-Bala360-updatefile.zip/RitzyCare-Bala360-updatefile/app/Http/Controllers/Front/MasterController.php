<?php

namespace App\Http\Controllers\Front;

use AppHelpers;
use App\Http\Controllers\Controller;
use App\Mail\CompetitionRegisterMail;
use App\Mail\ContactMail;
use App\Mail\ResetPasswordMail;
use App\Mail\UserActivationMail;
use App\Mail\VendorRegistrationMail;
use App\Models\AffiliateUsers;
use App\Models\AppProgramme;
use App\Models\Competition;
use App\Models\ContactMessage;
use App\Models\ForgotPassword;
use App\Models\Settings;
use App\Models\StaticPages;
use App\Models\User;
use App\Models\VendorRegistration;
use App\Models\EmailSubscription;
use App\Models\ShoppingCart;
use App\Models\PromoVideos;
use App\Models\VideoReview;


use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Str;
use Lang;
use Mail;
use Redirect;
use Session;
use Cart;

class MasterController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('front.home');
    }

    /**
     * Language set
     *
     * @param $locale
     *
     * @return $locale
     *
     */

    public function setAppLanguage($locale = "")
    {
        if (!in_array($locale, ['en', 'ar'])) {
            abort(400);
        }
        Session::put('locale', $locale);
        return $locale;
    }

    /**
     * Brand List
     *
     * @param $request
     *
     * @return $brands view
     */

    public function getBrandList()
    {
        return view('front.brand-list');
    }

    /**
     *
     * Static Page Details
     *
     * @param $slug
     *
     * @return $pageview
     */

    public function getStaticPageContent($slug = "")
    {
        $page_title = Str::title(str_replace('-', ' ', $slug));
        $page_info = StaticPages::whereStatus(1)->where('slug', $slug)->first();
        if ($page_info === null) {
            Session::flash('error', Lang::get('message.no_data_found'));
            return redirect('/');
        }
        return view('front.static-page', compact('page_title', 'page_info'));
    }

    /**
     * Contact Us Page
     *
     *  @return $contact us view
     */

    public function getContactUs($slug = "")
    {
        $contactInfo = Settings::orderBy('id', 'desc')->select('customercare_email', 'customercare_number')->first();
        return view('front.contact-us', compact('contactInfo'));
    }

    /**
     * Contact Us Page Refresh Captcha
     *
     *  @return $captcha image
     */

    public function refreshCaptcha(Request $request)
    {
        return response()->json(['captcha' => captcha_img($request->level)]);
    }

    /**
     * Contact us data store into DB
     *
     * @param $request
     *
     * @return back()
     *
     */

    public function postContactUs(Request $request)
    {
        $this->validate($request,
            [
                'cs_name' => 'required|regex:/^[A-Za-z. -]+$/',
                'cs_email' => 'required|email',
                'cs_phone' => 'required|regex:/[0-9]/',
                'captcha' => 'required|captcha',
                'cs_message' => 'required',
                'dial_code' => 'required',
            ], [
                'cs_name.required' => Lang::get('message.valid_name_req'),
                'cs_email.required' => Lang::get('message.valid_email_req'),
                'cs_phone.required' => Lang::get('message.valid_phone_req'),
                'message.required' => Lang::get('message.valid_message_req'),
                'captcha' => Lang::get('message.valid_captcha_req'),
            ]);
        $inquiry_id = ContactMessage::create([
            "name" => $request->cs_name,
            "email" => $request->cs_email,
            "dial_code" => $request->dial_code,
            "phone" => str_replace(' ', '', $request->cs_phone),
            "message" => $request->cs_message,
            "type" => 1,
            "record_ip" => $request->ip(),
        ])->id;

        if ($inquiry_id > 0) {
            $mailInfo = Settings::first() ?: "info@ritzycare.com";
            $mailTo = ($mailInfo->customercare_email) ?: "info@ritzycare.com";
            Mail::to($mailTo)->send(new ContactMail($request));
            Session::flash('success', Lang::get('message.thanks_contact_us'));
        } else {
            Session::flash('danger', Lang::get('message.something_went_wrong'));
        }
        return back();
    }

    /**
     * FAQ List
     *
     * @return FAQ List
     *
     */

    public function faqList()
    {
        return view('front.faq-list');
    }

    /**
     * User Registration
     *
     * @return Registartion Page View
     *
     */

    public function getRegistration()
    {
        if (auth()->guard('web-front')->user()) {
            Session::flash('success', Lang::get('message.succ_logged_in'));
            return redirect('/');
        }
        $programs = AppProgramme::where('status', 1)->whereIn('programme_type', [0, 1])->get();
        return view('front.registration', compact('programs'));
    }

    /**
     * Check user email availablity
     *
     * @param $email
     *
     * @return bool
     *
     */

    public function validateCustomerEmail(Request $request)
    {
        return User::whereEmail($request->email)->where('token_status', 1)->count();
    }

    /**
     * Register New User
     *
     * @param $request
     *
     * @return $sent verification link to customer
     *
     */

    public function postRegistration(Request $request)
    {
        $this->validate($request,
            [
                'usr_name' => 'required|regex:/^[A-Za-z. -]+$/',
                'usr_email' => 'required|email|regex:/^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/|unique:users,email',
                'usr_password' => 'required|min:5',
                'usr_cpassword' => 'required|same:usr_password',
                'usr_phone' => 'required|min:8|max:8|regex:/[0-9]/',
                'captcha' => 'required|captcha',
            ], [
                'usr_name.*' => Lang::get('message.valid_name_req'),
                'usr_email.*' => Lang::get('message.valid_email_req'),
                'usr_password.required' => Lang::get('message.valid_password_req'),
                'usr_password.min' => Lang::get('message.valid_password_min'),
                'usr_cpassword.required' => Lang::get('message.valid_cpassword_req'),
                'usr_cpassword.same' => Lang::get('message.valid_cpassword_same'),
                'usr_phone.*' => Lang::get('message.valid_phone_req'),
                'captcha.*' => Lang::get('message.valid_captcha_req'),
            ]);
        $activationToken = AppHelpers::generateAlphaNumericCode(32);
        $activationLink = url('account-verfication/' . $activationToken);
        $check = User::whereEmail($request->usr_email)->first();
        if ($check) {
            $check->name = $request->usr_name;
            $check->password = bcrypt($request->usr_password);
            $check->dial_code = '974';
            $check->phone_number = $request->usr_phone;
            $check->verification_token = base64_encode($activationToken);
            $check->token_expiry = Carbon::now()->addDay(7);
            $check->last_login_ip = $request->ip();
            $check->save();
            $this->sendActivationLink($request->usr_email, $activationLink);
            Session::flash('success', Lang::get('message.acc_activation_link_resent'));
        } else {
            $usr = User::create([
                'name' => $request->usr_name,
                'email' => $request->usr_email,
                'password' => bcrypt($request->usr_password),
                'dial_code' => '974',
                'phone_number' => $request->usr_phone,
                'verification_token' => base64_encode($activationToken),
                'token_expiry' => Carbon::now()->addDay(7),
                'last_login_ip' => $request->ip(),
            ]);
            $this->sendActivationLink($request->usr_email, $activationLink);
            Session::flash('success', Lang::get('message.acc_activation_link'));
        }
        return redirect()->intended('/');
    }

    /**
     *
     * User Email Activation
     *
     * @param $email, $link
     *
     * @return void
     */

    public function sendActivationLink($mailTo = "", $link = "")
    {
        Mail::to($mailTo)->send(new UserActivationMail($link));
    }

    /**
     *
     * Verify Registered User Account
     *
     * @param $token
     *
     * @return void
     *
     */

    public function verifyUserAccount($token = "")
    {
        $getTokenInfo = User::where('verification_token', $token)->first();
        if ($getTokenInfo) {
            $tokenExpiry = Carbon::createFromFormat('Y-m-d H:i:s', $getTokenInfo->token_expiry);
            $currentDate = Carbon::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'));
            $tokenStat = $tokenExpiry->gte($currentDate);
            if ($tokenStat == true) {
                User::where('id', $getTokenInfo->id)->update([
                    'token_status' => 1,
                    'email_verified_at' => date('Y-m-d H:i:s'),
                    'is_active' => 1,
                ]);
                Auth::guard('web-front')->loginUsingId($getTokenInfo->id);
                Session::flash('success', Lang::get('message.success_login_1') . ' ' . ucwords(strtolower(Auth::user()->guard('web-front')->name)) . ', ' . Lang::get('message.success_login_3'));
                return redirect('/');
            } else {
                Session::flash('danger', Lang::get('message.token_expired'));
                return redirect('/register');
            }
        } else {
            Session::flash('danger', Lang::get('message.invalid_token'));
            return redirect('/register');
        }
    }

    /**
     * User Login
     *
     * @return Login Page View
     *
     */

    public function getLogin()
    {
        if (auth()->guard('web-front')->user()) {
            Session::flash('success', Lang::get('message.succ_logged_in'));
            return redirect('/');
        }
        return view('front.user-auth');
    }

    /**
     *
     * Validate User Credentials and Login
     *
     * @param $request
     *
     * @return bool
     *
     */

    public function postLogin(Request $request)
    {
        $this->validate($request,
            [
                'usr_email' => 'required|email|regex:/^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/',
                'usr_password' => 'required|min:5',
            ], [
                'usr_email.*' => Lang::get('message.valid_email_req'),
                'usr_password.required' => Lang::get('message.valid_password_req'),
                'usr_password.min' => Lang::get('message.valid_password_min'),
            ]);

        $user_data = User::where('email', $request->usr_email)->first();
        if($user_data) {
            $user_exst = $user_data->count();
            if ($user_exst == 0) {
                Session::flash('danger', Lang::get('message.user_not_register'));
                return redirect()->back();
            }
        } else {
            Session::flash('danger', Lang::get('message.user_not_register'));
            return redirect()->back();
        }
        if ($user_data->first()->token_status == 0) {
            $activationToken = AppHelpers::generateAlphaNumericCode(32);
            $activationLink = url('account-verfication/' . $activationToken);
            $user_data->verification_token = base64_encode($activationToken);
            $user_data->token_expiry = Carbon::now()->addDay(7);
            $user_data->last_login_ip = $request->ip();
            $user_data->save();
            $this->sendActivationLink($request->usr_email, $activationLink);
            Session::flash('success', Lang::get('message.acc_activation_link_resent'));
            return redirect()->intended($request->ref_url);
        }
        if (Auth::guard('web-front')->attempt(['email' => $request->usr_email, 'password' => $request->usr_password, 'token_status' => 1, 'is_active' => 1], false)) {
            $user_data->last_login_ip = $request->ip();
            $user_data->last_login = Carbon::now();
            $user_data->save();            
            Session::put('uid', Auth::guard('web-front')->user()->id);
            Session::put('puid', $user_data->is_subscribed);
            $this->assign_cart_items();
            Session::flash('success', Lang::get('message.success_login_1') . ' ' . ucwords(strtolower(Auth::guard('web-front')->user()->name)) . ', ' . Lang::get('message.success_login_2'));
            return redirect()->intended($request->ref_url);
        } else {
            Session::flash('danger', Lang::get('message.fail_logged_in'));
            return redirect()->back();
        }
    }

    /**
     * 
     * Assign user cart item
     * 
     */

    public function assign_cart_items()
    {
        if(Cart::content()->count() > 0) {
            foreach(Cart::content() as $item)
            {
                $cartexits = ShoppingCart::where(['ref_id' => $item->rowId,'user_id' => auth()->guard('web-front')->user()->id])->count();
                if($cartexits > 0) {
                    ShoppingCart::where('ref_id',$item->rowId)->update([
                        'quantity' => $item->qty,
                        'device_type' => 0,
                    ]);
                } else {
                    $cart = new ShoppingCart;
                    $cart->user_id = Session::get('uid');
                    $cart->user_type = Session::get('puid');
                    $cart->ref_id = $item->rowId;
                    $cart->cart_id = $item->id;
                    $cart->item_id = $item->options->item_id;
                    $cart->item_name = $item->name;
                    $cart->price = AppHelpers::formatNumber(((Session::get('puid') === 0)?$item->price:$item->options->member_selling_price));
                    $cart->quantity = $item->qty;
                    $cart->options = json_encode($item->options);
                    $cart->device_id = Session::get('_token');
                    $cart->device_type = 0;
                    $cart->save();
                }
            }  
            Cart::destroy();          
        }

        $usrCart = ShoppingCart::where('user_id', auth()->guard('web-front')->user()->id)->get();
        if(count($usrCart) > 0) {
            foreach($usrCart as $uc) {
                $optAry = json_decode($uc->options,true);
                $pCart = Cart::add([
                    'id' => $uc->cart_id,
                    'name' => $uc->item_name,
                    'price' => AppHelpers::formatNumber(((Session::get('puid') === 0)?$uc->price:$optAry['member_selling_price'])),
                    'qty' => $uc->quantity,
                    'options' => $optAry,
                ]);
                ShoppingCart::whereId($uc->id)->where('user_id', auth()->guard('web-front')->user()->id)->update([
                    'ref_id' => $pCart->rowId,
                ]);
            }
        }

    }

    /**
     *
     * User Logout
     *
     */

    public function userLogout()
    {
        Auth::guard('web-front')->logout();
        $language = session('locale');
        session()->flush();
        Session::put('locale', $language);
        return Redirect::to('/')->with('success', Lang::get('message.logged_out'));
    }

    /**
     * User - Forgot Password
     *
     * @return View
     *
     */

    public function getForgotPassword()
    {
        if (auth()->guard('web-front')->user()) {
            Session::flash('success', Lang::get('message.succ_logged_in'));
            return redirect('/');
        }
        return view('front.forgot-password');
    }

    /**
     * Generate Password Reset Link
     *
     * @param @request
     *
     * @return bool
     *
     */

    public function postForgotPassword(Request $request)
    {
        $this->validate($request,
            [
                'usr_email' => 'required|email',
            ]);
        $user_details = User::where('email', $request->usr_email)->first();
        if ($user_details) {
            $activationToken = AppHelpers::generateAlphaNumericCode(64, "random");
            $forgotToken = new ForgotPassword;
            $forgotToken->email = $user_details->email;
            $forgotToken->token = $activationToken;
            $forgotToken->expiry_on = Carbon::now()->addDay(7);
            $forgotToken->created_at = Carbon::now();
            $forgotToken->save();

            $activationLink = url('recover-password/' . $activationToken);
            Mail::to($request->usr_email)->send(new ResetPasswordMail($activationLink));

            Session::flash('success', Lang::get('messages.forgot_pass_succ'));
            return redirect('/');
        } else {
            Session::flash('danger', Lang::get('messages.user_not_register'));
            return redirect()->back();
        }
    }

    /**
     * Forgot Password - Generate New Password
     *
     * @param $request $token
     *
     * @return bool
     *
     */

    public function getGeneratePassword($activationToken = "")
    {
        $checkTokenStat = ForgotPassword::where(['token' => $activationToken, 'token_status' => 0])->where('expiry_on', '>=', Carbon::now())->first();
        if ($checkTokenStat) {
            $userEmail = base64_encode($checkTokenStat->email);
            return view('front.reset-password', compact('userEmail'));
        } else {
            Session::flash('danger', Lang::get('message.forgot_token_expired'));
            return redirect('/');
        }
    }

    /**
     * Forgot Password - Update New Password
     *
     * @param $request $token
     *
     * @return bool
     *
     */

    public function postUpdatePassword(Request $request, $activationToken = "")
    {
        $this->validate($request,
            [
                'password' => 'required|min:5|regex:/^(?=.*[a-zA-Z])(?=.*[0-9]).+$/',
                'confirm_password' => 'required |same:password',
            ],
            [
                'password.regex' => Lang::get('message.password_rule_txt'),
                'confirm_password.same' => Lang::get('message.cpassword_rule_txt'),
            ]);

        $user = User::where('email', base64_decode($request->ref_token))->first();
        if ($user) {
            $user->password = bcrypt($request->password);
            $user->save();
            ForgotPassword::where(['token' => $activationToken, 'token_status' => 0])
                ->update([
                    'token_status' => 1,
                ]);
            Session::flash('success', Lang::get('message.password_reset_succ'));
            return redirect('/');
        }
    }

    /**
     * Affiliate Information Page
     *
     * @return Affiliate View
     */

    public function getAffiliateInfo()
    {
        return view('front.affiliate');
    }

    /**
     * Check affiliate email availablity
     *
     * @param $email
     *
     * @return bool
     *
     */

    public function validateAffiliateEmail(Request $request)
    {
        return AffiliateUsers::where('user_email', $request->email)->count();
    }

    /**
     *
     * Enroll affiliate information
     *
     * @param $request
     *
     * @return bool
     *
     */

    public function postAffiliateInfo(Request $request)
    {
        $this->validate($request,
            [
                'who_am' => 'required',
                'ap_name' => 'required|regex:/^[A-Za-z. -]+$/',
                'ap_email' => 'required|email|regex:/^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/|unique:affiliate_users,user_email',
                'ap_country' => 'required|regex:/^[A-Za-z. -]+$/',
                'dial_code' => 'required',
                'ap_phone' => 'required|min:8|regex:/[0-9]/',
                'ap_fb_link' => 'nullable',
                'ap_insta_link' => 'nullable',
                'ap_other_link' => 'nullable',
                'captcha' => 'required|captcha',
            ], [
                'ap_name.*' => Lang::get('message.valid_name_req'),
                'ap_email.required' => Lang::get('message.valid_email_req'),
                'ap_email.email' => Lang::get('message.valid_email_req'),
                'ap_email.regex' => Lang::get('message.valid_email_req'),
                'ap_email.unique' => Lang::get('message.email_already_taken'),
                'ap_country.*' => Lang::get('message.valid_country_req'),
                'ap_phone.*' => Lang::get('message.valid_phone_req'),
                'captcha.*' => Lang::get('message.valid_captcha_req'),
            ]);

        $check = AffiliateUsers::where('user_email', $request->usr_email)->first();
        if ($check) {
            $check->user_type = $request->who_am;
            $check->user_name = $request->ap_name;
            $check->user_email = $request->ap_email;
            $check->dial_code = ($request->dial_code != '') ? $request->dial_code : "974";
            $check->phone_number = $request->ap_phone;
            $check->country = $request->ap_country;
            $check->website = $request->ap_website;
            $check->fb_info = $request->ap_fb_link;
            $check->insta_info = $request->ap_insta_link;
            $check->other_info = $request->ap_other_link;
            $check->is_subscribed = (isset($request->subscription)) ? 1 : 0;
            $check->status = 0;
            $check->record_ip = $request->ip();
            $check->save();
        } else {
            $aff_usr = new AffiliateUsers;
            $aff_usr->user_type = $request->who_am;
            $aff_usr->user_name = $request->ap_name;
            $aff_usr->user_email = $request->ap_email;
            $aff_usr->dial_code = ($request->dial_code != '') ? $request->dial_code : "974";
            $aff_usr->phone_number = $request->ap_phone;
            $aff_usr->country = $request->ap_country;
            $aff_usr->website = $request->ap_website;
            $aff_usr->fb_info = $request->ap_fb_link;
            $aff_usr->insta_info = $request->ap_insta_link;
            $aff_usr->other_info = $request->ap_other_link;
            $aff_usr->is_subscribed = (isset($request->subscription)) ? 1 : 0;
            $aff_usr->status = 0;
            $aff_usr->record_ip = $request->ip();
            $aff_usr->save();
        }

        $mailInfo = Settings::first() ?: "info@ritzycare.com";
        $mailTo = ($mailInfo->customercare_email) ?: "info@ritzycare.com";
        Mail::to($mailTo)->send(new UserActivationMail($request));

        Session::flash('success', Lang::get('message.aff_thanks_note'));
        return redirect()->intended('/');
    }

    /**
     * Competition Page
     *
     * @return Competition View
     */

    public function getCompetitionInfo()
    {
        return view('front.competition');
    }

    /**
     *
     * Enroll competition information
     *
     * @param $request
     *
     * @return bool
     *
     */

    public function postCompetitionInfo(Request $request)
    {
        $this->validate($request,
            [
                'comp_fname' => 'required|regex:/^[A-Za-z. -]+$/',
                'comp_lname' => 'required|regex:/^[A-Za-z. -]+$/',
                'comp_email' => 'required|email|regex:/^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/',
                'compt_nationality' => 'required|regex:/^[0-9]+$/',
                'dial_code' => 'required',
                'comp_phone' => 'required|min:8|regex:/[0-9]/',
                'comp_smaccount' => 'required',
                'comp_height' => 'nullable',
                'comp_weight' => 'nullable',
                'captcha' => 'required|captcha',
            ], [
                'comp_fname.*' => Lang::get('message.valid_fname_req'),
                'comp_lname.*' => Lang::get('message.valid_lname_req'),
                'comp_email.required' => Lang::get('message.valid_email_req'),
                'comp_email.email' => Lang::get('message.valid_email_req'),
                'comp_email.regex' => Lang::get('message.valid_email_req'),
                'compt_nationality.*' => Lang::get('message.valid_nationality_req'),
                'comp_phone.*' => Lang::get('message.valid_phone_req'),
                'comp_smaccount.*' => Lang::get('message.valid_sm_acc_req'),
                'captcha.*' => Lang::get('message.valid_captcha_req'),
            ]);

        $compt = new Competition;
        $compt->first_name = $request->comp_fname;
        $compt->last_name = $request->comp_lname;
        $compt->email = $request->comp_email;
        $compt->dial_code = ($request->dial_code != '') ? $request->dial_code : "974";
        $compt->phone_number = $request->comp_phone;
        $compt->nationality_id = $request->compt_nationality;
        $compt->social_account = $request->comp_smaccount;
        $compt->height = $request->comp_height;
        $compt->weight = $request->comp_weight;
        if (isset($request->compt_file)) {
            $fileName = time() . '.' . $request->compt_file->getClientOriginalExtension();
            $request->compt_file->move(public_path('uploads/competitions'), $fileName);
            $compt->file_name = $fileName;
        }
        $compt->is_agree = (isset($request->compt_agree)) ? 1 : 0;
        $compt->is_permission = (isset($request->compt_permission)) ? 1 : 0;
        $compt->record_ip = $request->ip();
        $compt->status = 1;
        $compt->modified_by = 0;
        $compt->app_type = 0;
        $compt->save();

        $mailInfo = Settings::first() ?: "info@ritzycare.com";
        $mailTo = ($mailInfo->customercare_email) ?: "info@ritzycare.com";
        Mail::to($mailTo)->send(new CompetitionRegisterMail($request));

        Session::flash('success', Lang::get('message.compt_thanks_note'));
        return redirect()->intended('/');
    }

    /**
     * Vendor Registration Page
     *
     * @return Registration View
     */

    public function getVendorRegistration()
    {
        return view('front.vendor-registration');
    }

    /**
     *
     * Enroll vendor information
     *
     * @param $request
     *
     * @return bool
     *
     */

    public function postVendorRegistration(Request $request)
    {
        $this->validate($request,
            [
                'ven_name' => 'required|regex:/^[A-Za-z. -]+$/',
                'ven_bname' => 'required|regex:/^[A-Za-z. -]+$/',
                'ven_email' => 'required|email|regex:/^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/|unique:vendor_registrations,vendor_email',
                'ven_store_addr' => 'required',
                'dial_code' => 'required',
                'ven_phone' => 'required|min:8|regex:/[0-9]/',
                'ven_building_no' => 'required|numeric',
                'ven_street_no' => 'required|numeric',
                'ven_zone_no' => 'required|numeric',
                'ven_selling_item' => 'required',
                'captcha' => 'required|captcha',
            ], [
                'ven_name.*' => Lang::get('message.valid_name_req'),
                'ven_bname.*' => Lang::get('message.valid_bname_req'),
                'ven_email.required' => Lang::get('message.valid_email_req'),
                'ven_email.email' => Lang::get('message.valid_email_req'),
                'ven_email.regex' => Lang::get('message.valid_email_req'),
                'ven_email.unique' => Lang::get('message.email_already_taken'),
                'ven_store_addr.*' => Lang::get('message.valid_store_addr_req'),
                'ven_phone.*' => Lang::get('message.valid_phone_req'),
                'ven_building_no.*' => Lang::get('message.valid_building_no_req'),
                'ven_street_no.*' => Lang::get('message.valid_street_no_req'),
                'ven_zone_no.*' => Lang::get('message.valid_zone_no_req'),
                'ven_selling_item.*' => Lang::get('message.valid_sell_item_req'),
                'captcha.*' => Lang::get('message.valid_captcha_req'),
            ]);

        $vendor = new VendorRegistration;
        $vendor->vendor_name = $request->ven_name;
        $vendor->business_name = $request->ven_bname;
        $vendor->vendor_email = $request->ven_email;
        $vendor->dial_code = ($request->dial_code != '') ? $request->dial_code : "974";
        $vendor->phone_number = $request->ven_phone;
        $vendor->store_address = $request->ven_store_addr;
        $vendor->building_no = $request->ven_building_no;
        $vendor->street_no = $request->ven_street_no;
        $vendor->zone_no = $request->ven_zone_no;
        $vendor->store_portfolio = $request->ven_selling_item;
        $vendor->record_ip = $request->ip();
        $vendor->status = 0;
        $vendor->modified_by = 0;
        $vendor->save();

        $mailInfo = Settings::first() ?: "info@ritzycare.com";
        $mailTo = ($mailInfo->customercare_email) ?: "info@ritzycare.com";
        Mail::to($mailTo)->send(new VendorRegistrationMail($request));

        Session::flash('success', Lang::get('message.vendor_thanks_note'));
        return redirect()->intended('/');
    }

    /**
     * Reward Programme
     *
     * @return $view - Reward programme
     *
     */

    public function getRewardProgramme()
    {
        $rewardPro = AppProgramme::where(['programme_type' => 2, 'status' => 1])->get();
        return view('front.reward-program', compact('rewardPro'));
    }

    /**
     * User Subscription
     *
     * @param $request
     *
     * @return bool
     *
     */

    public function userSubscription(Request $request)
    { 
        $this->validate($request,
            [
                'subscribe_name' => 'required|regex:/^[A-Za-z. -]+$/',
                'subscribe_email' => 'required|email|regex:/^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/|unique:users,email',
                'subscribe_phone' => 'required|min:8|regex:/[0-9]/',
                'subscribe_spam' => 'nullable',
            ], [
                'subscribe_name.*' => Lang::get('message.valid_name_req'),
                'subscribe_email.*' => Lang::get('message.valid_email_req'),
                'subscribe_phone.*' => Lang::get('message.valid_phone_req'),
            ]);

        if(isset($request->subscribe_spam) && $request->subscribe_spam !== '') {
            Session::flash('danger', Lang::get('message.something_went_wrong'));
            return back();
        } 

        $email_subsciption = EmailSubscription::where('email', $request->subscribe_email)->first();
        if (!$email_subsciption) {
            $email_subsciption = new EmailSubscription;
            $email_subsciption->user_id = (!auth()->guard('web-front')->user() ? 0 : auth()->guard('web-front')->user()->id);
            $email_subsciption->user_name = $request->subscribe_name;
            $email_subsciption->email = $request->subscribe_email;            
            $email_subsciption->dial_code = '974';
            $email_subsciption->phone_number = $request->subscribe_phone;
            $email_subsciption->status = 1;
            $email_subsciption->save();
            Session::flash('success', Lang::get('message.succ_subscribe'));
            return back();
        } else {
            Session::flash('danger', Lang::get('message.already_subscribe'));
            return back();
        }
    }

    /**
     * All Video List
     *
     * @return Video List
     *
     */

    public function allVideo()
    {
        $isListing = 2;
        $page_title = Lang::get('message.promo_videos');        
        return view('front.all-video-list', compact('page_title', 'isListing'));
        
    }
      /**
     * Monthly Deals
     */
    public function monthlyDeals()
    {
        return view('front.monthly-deals');
    }
    /**
     * Reviews Video
     */
    public function reviewsVideo()
    {
        $videoReviews = VideoReview::where('status',1)->get();
        return view('front.reviews-video', compact('videoReviews'));
    }
    
    /**
     * Reviews
     */
    public function reviews()
    {
        return view('front.reviews');
    }
      /**
     * Members Only
     */
    public function membersOnly()
    {
        return view('front.members-only');
    }    
     /**
     * Deal Listing
     */
    public function dealListing()
    {
        $isListing = 1;
        $page_title = Lang::get('message.new_products');
        return view('front.deal-listing', compact('page_title', 'isListing'));
    }
     

}
