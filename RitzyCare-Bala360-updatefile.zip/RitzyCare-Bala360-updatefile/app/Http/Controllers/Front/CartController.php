<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\ItemImages;
use App\Models\ItemInventory;
use App\Models\Items;
use App\Models\ShoppingCart;
use Auth;
use Cart;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Lang;
use Session;
use AppHelpers;

class CartController extends Controller
{

    /**
     * Cart Listing
     *
     * @return $cart view
     */

    public function getCartInformation()
    {
        return view('front.cart-list');
    }

    /**
     * Add Items Into Cart.
     *
     * @return bool
     *
     */

    public function postAddToCart(Request $request)
    {
        $itemInfo = Items::leftjoin('categories', 'categories.id', 'items.category_id')->where('items.id', $request->item_id)->where(['items.status' => 1, 'items.is_active' => 1])->select('items.id', 'items.item_name', 'items.item_rcin', 'items.is_variants', 'items.is_inventory_track', 'items.item_group', 'categories.id as category_id', 'categories.category_name')->first();
        if ($itemInfo) {
            $itemInventory = ItemInventory::whereId($request->attr_id)->first();
            if ($itemInventory) {
                if ($itemInfo->is_variants === 1 && $request->img_type === 2) {
                    $itemImgDet = ItemImages::where(['item_attribute_id' => $request->attr_id, 'item_id' => $itemInfo->id])->first();
                } else {
                    $itemImgDet = ItemImages::where('item_id', $itemInfo->id)->first();
                }

                $optAry = array('item_id' => $itemInfo->id, 'item_code' => $itemInfo->item_rcin, 'item_name_en' => $itemInfo->getTranslation('item_name', 'en'), 'item_name_ar' => $itemInfo->getTranslation('item_name', 'ar'), 'has_variant' => $itemInfo->is_variants, 'variant_id' => $request->attr_id, 'has_inventory_track' => $itemInfo->is_inventory_track, 'stock' => $itemInventory->quantity, 'image' => $itemImgDet->image_name, 'item_category_id' => $itemInfo->category_id, 'item_category' => $itemInfo->category_name, 'base_price' => $itemInventory->base_price, 'selling_price' => $itemInventory->selling_price, 'discount' => $itemInventory->discount, 'member_discount' => $itemInventory->member_discount, 'member_selling_price' => $itemInventory->member_selling_price, 'item_type' => $itemInfo->item_group);

                $cpCart = Cart::content()->where('id', $request->attr_id);
                if(count($cpCart) > 0) {
                    foreach($cpCart as $cpk => $cpv) {
                        Cart::remove($cpk);
                    }                   
                }

                $usrItemPrice = AppHelpers::formatNumber($itemInventory->selling_price);
                if (auth()->guard('web-front')->user()) {
                    if(auth()->guard('web-front')->user()->is_subscribed === 1) {
                        $usrItemPrice = AppHelpers::formatNumber($itemInventory->member_selling_price);
                    }
                }

                $pCart = Cart::add([
                            'id' => $request->attr_id,
                            'name' => $itemInfo->item_name,
                            'price' => $usrItemPrice,
                            'qty' => $request->cust_qty,
                            'options' => $optAry,
                        ]);

                if (auth()->guard('web-front')->user()) {
                    $checkEx = ShoppingCart::where(['user_id' => Session::get('uid'), 'cart_id' => $request->attr_id, 'item_id' => $itemInfo->id])->first();
                    if($checkEx) {
                        $checkEx->user_id = Session::get('uid');
                        $checkEx->user_type = auth()->guard('web-front')->user()->is_subscribed;
                        $checkEx->ref_id = ($pCart->rowId)?$pCart->rowId:"";
                        $checkEx->price = $usrItemPrice;
                        $checkEx->quantity = $request->cust_qty;
                        $checkEx->options = json_encode($optAry);
                        $checkEx->save();
                    } else {
                        $cart = new ShoppingCart;
                        $cart->user_id = Session::get('uid');
                        $cart->user_type = auth()->guard('web-front')->user()->is_subscribed;
                        $cart->ref_id = ($pCart->rowId)?$pCart->rowId:"";
                        $cart->cart_id = $request->attr_id;
                        $cart->item_id = $itemInfo->id;
                        $cart->item_name = $itemInfo->item_name;
                        $cart->price = $usrItemPrice;
                        $cart->quantity = $request->cust_qty;
                        $cart->options = json_encode($optAry);
                        $cart->device_id = Session::get('_token');
                        $cart->device_type = 0;
                        $cart->save();
                    }
                }

                if ($itemInfo->item_group == 1) {
                    $respMsg = Lang::get('cart.pro_added_cart');
                } else if ($itemInfo->item_group == 2) {
                    $respMsg = Lang::get('cart.ser_added_cart');
                } else {
                    $respMsg = Lang::get('cart.item_added_cart');
                }
                $this->data['message'] = $respMsg;
                $this->data['cart_count'] = Cart::content()->count();
                return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
            } else {
                $respMsg = Lang::get('cart.item_cart_fail');
                $this->data['message'] = $respMsg;
                $this->data['cart_count'] = Cart::content()->count();
                return response()->json(['Response_Status' => false, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
            }
        } else {
            $respMsg = Lang::get('cart.item_cart_fail');
            $this->data['message'] = $respMsg;
            $this->data['cart_count'] = Cart::content()->count();
            return response()->json(['Response_Status' => false, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
        }
    }

    /**
     * Update Cart Quantity
     *
     * @return bool
     *
     */

    public function updateCartQty(Request $request)
    {
        Cart::update($request->row_id, $request->cust_qty);
        if (auth()->guard('web-front')->user()) {
            $updateQty = ShoppingCart::where(['user_id' => Session::get('uid'), 'ref_id' => $request->row_id])->first();
            if($updateQty) {                
                $updateQty->quantity = $request->cust_qty;
                $updateQty->save();
            }
        }
        $this->data['message'] = Lang::get('cart.item_updated_cart');
        $this->data['cart_count'] = Cart::content()->count();
        $this->data['cart_amount'] = AppHelpers::formatNumber(Cart::subtotal());
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * Remove Item from Cart
     *
     * @return bool
     */

    public function removeCartQty(Request $request)
    {
        if ($request->remove_type == 1) {
            Cart::remove($request->row_id);
            if (auth()->guard('web-front')->user()) {
                $updateQty = ShoppingCart::where(['user_id' => Session::get('uid'), 'ref_id' => $request->row_id])->delete();                
            }
            $this->data['message'] = Lang::get('cart.item_removed_cart');
        } else {
            Cart::destroy();
            if (auth()->guard('web-front')->user()) {
                $updateQty = ShoppingCart::where('user_id',Session::get('uid'))->delete();                
            }
            $this->data['message'] = Lang::get('cart.cart_cleared');
        }
        $this->data['cart_count'] = Cart::content()->count();
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * Checkout Information
     *
     * @return $checkout view
     */

    public function getCheckoutInformation()
    {
        if (Cart::content()->count() === 0) {
            return back();
        }
        return view('front.checkout');
    }

    /** 
     * 
     * Set Delivery Information
     * 
     * @return bool
     * 
     */

    public function confDeliveryInfo(Request $request)
    {
        Session::forget(['delivery_method','sch_delivery_date','sch_delivery_slot']);
        $delMethod = ($request->delivery_method) ?? '1';
        $schDelDate = ($request->sch_del_date) ?? '';
        $schDelSlot = ($request->sch_del_slot) ?? '';
        Session::put('delivery_method',$delMethod);
        if($delMethod == 3) {
            Session::put('sch_delivery_date',$schDelDate);
            Session::put('sch_delivery_slot',$schDelSlot);
        }   
        return 1;     
    }
}
