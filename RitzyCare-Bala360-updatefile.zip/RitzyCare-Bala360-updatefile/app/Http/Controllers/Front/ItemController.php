<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Items;
use App\Models\ItemViewHistory;
use App\Models\PromoAds;
use Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Lang;
use Request;
use Illuminate\Http\Response;
use Session;

class ItemController extends Controller
{
    /**
     * Listout all new products.
     *
     * @return $ new product list
     *
     */

    public function getNewProducts()
    {
        $isListing = 1;
        $page_title = Lang::get('message.new_products');
        return view('front.item-listing', compact('page_title', 'isListing'));
    }

    /**
     * Item Details
     *
     * @param $slug
     *
     * @return $Item Details
     *
     */

    public function getItemDetails($slug = "")
    {
        $itemInfo = Items::with('getItemParentImage')->whereSlug($slug)->first();
        if (!empty($itemInfo->id)) {
            /*$nowTimeDate = Carbon::now();
            $newTime = Carbon::now()->subHour();*/
            $token = Session::get('_token');
            $uid = Session::get('uid');
            $condition = "guest_token = '" . $token . "'";
            $checkUniqueView = ItemViewHistory::where('item_id', $itemInfo->id)->whereRaw($condition)->count();
            if ($checkUniqueView == 0) {
                $itmView = new ItemViewHistory;
                $itmView->user_id = $uid;
                $itmView->guest_token = $token;
                $itmView->item_id = $itemInfo->id;
                $itmView->category_id = $itemInfo->category_id;
                $itmView->sub_cate_id = $itemInfo->sub_category_id;
                $itmView->secsub_cate_id = $itemInfo->sec_subcategory_id;
                $itmView->third_cate_id = $itemInfo->third_category_id;
                $itmView->record_ip = Request::ip();
                $itmView->save();
            } else {
                $updateUniqueView = ItemViewHistory::where('item_id', $itemInfo->id)->whereRaw($condition)->first();
                $updateUniqueView->user_id = $uid;
                $updateUniqueView->guest_token = $token;
                $updateUniqueView->record_ip = Request::ip();
                $updateUniqueView->updated_at = Carbon::now();
                $updateUniqueView->save();
            }
        }
        return view('front.item-details', compact('itemInfo', 'slug'));
    }    

    /**
     * Listout all services.
     *
     * @return $ service list
     *
     */

    public function getNewServices()
    {      
        $isListing = 2;
        $page_title = Lang::get('message.service');
        return view('front.item-listing', compact('page_title', 'isListing'));
    }

    /**
     * Get all flash deals list      
     */

    public function getFlashDealsListing()
    {       
        $isDeals = 1;
        $page_title = Lang::get('message.flash_deals');
        return view('front.deal-listing', compact('page_title', 'isDeals'));
    }

    /**
     * Get all weekly deals list      
     */

    public function getWeeklyDealsListing()
    {       
        $isDeals = 2;
        $page_title = Lang::get('message.weekly_deals');
        return view('front.deal-listing', compact('page_title', 'isDeals'));
    }

    /**
     * Get all monthly deals list      
     */

    public function getMonthlyDeals()
    {         
        $ismemberDeals = 3;
        $page_title = Lang::get('message.monthly_deals');
        return view('front.monthly-deals', compact('page_title', 'ismemberDeals'));
    }

     /**
     * Get all exclusive deals list      
     */

    public function getExclusiveDealsListing()
    {       
        $isDeals = 4;
        $page_title = Lang::get('message.exclusive_deals');
        return view('front.deal-listing', compact('page_title', 'isDeals'));
    }

    /**
     * Get all promo video list      
     */

    public function getPromoVideo()
    {         
        $isVideos = 1;
        $page_title = Lang::get('message.promo_videos');
        return view('front.all-video-list', compact('page_title', 'isVideos'));
    }
    
      /**
     * Get all customer reviews video list     
     */ 

    public function getReviewsVideo()
    {         
     
        $page_title = Lang::get('message.customer_review_video');
        return view('front.reviews-video', compact('page_title'));
    }

     /**
     * Get all customer reviews list     
     */ 

    public function getReviewsCustomer()
    {         
        $isreviewsCustomer = 3;
        $page_title = Lang::get('message.customer_review');
        return view('front.reviews', compact('page_title', 'isreviewsCustomer'));
    }

     /**
     * Get all member deals list     
     */ 

    public function getMembersDeals()
    {         
        $ismemberDeals = 5;
        $page_title = Lang::get('message.members_deals');
        return view('front.monthly-deals', compact('page_title', 'ismemberDeals'));
    }
        
    /**
     * Listout best sellers items.
     *
     * @return $ best sellers items list
     *
     */

    public function getBestSellers()
    {
        $page_title = Lang::get('message.best_sellers');
        return view('front.best-sellers', compact('page_title'));
    }

    /**
     *
     * Category based item listing
     *
     * @param Category slug
     *
     * @return Category List
     */

    public function getCategoryBasedItems($main = "", $subCate = "", $secSubCate = "", $thirdCate = "")
    {
        $isListing = 0;
        $page_title = Str::title($main);
        $cateType = 0;
        $cateSlug = "";
        if ($main != '') {
            $cateType = 1;
            $cateSlug = $main;
            if ($subCate != '') {
                $cateType = 2;
                $cateSlug = $subCate;
                if ($secSubCate != '') {
                    $cateType = 3;
                    $cateSlug = $secSubCate;
                    if ($thirdCate != '') {
                        $cateType = 4;
                        $cateSlug = $thirdCate;
                    }
                }
            }
        }
        return view('front.item-listing', compact('page_title', 'isListing', 'cateType', 'cateSlug'));
    }

    /**
     *
     * Item listing left side - MPU Ad
     * @return $banner image
     */

    public function getMPUAdImage()
    {
        $adsList = PromoAds::where(['status' => 1, 'app_type' => 0])->inRandomOrder()->limit(1)->select('id', 'ad_title', 'ad_image', 'redirect_type', 'redirect_url', 'start_date', 'end_date', 'slug', 'app_type')->get();
        $this->data['image_root'] = cdn('uploads/ads');
        $this->data['promo_ads'] = $adsList;
        return response()->json(['Response_Status' => true, 'Response_Data' => $this->data])->setStatusCode(Response::HTTP_OK);
    }

    /**
     * Item Search
     *
     * @return $searchlist view
     *
     */

    public function getSearchList()
    {
        $isListing = 0;
        $searchStr = $page_title = Request::query('q');
        return view('front.item-listing', compact('page_title', 'isListing','searchStr'));
    }

    /**
     * Brand Based Item List 
     *
     * @return $branlist view
     *
     */

    public function getBrandItemList($brandID,$slug)
    {
        $isListing = 0;
        $page_title = ucwords(str_replace('-', ' ', $slug));
        return view('front.item-listing', compact('page_title', 'isListing','brandID'));
    }
}
