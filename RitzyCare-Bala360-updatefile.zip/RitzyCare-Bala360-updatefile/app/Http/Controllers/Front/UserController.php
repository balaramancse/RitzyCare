<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserShippingAddress;
use Auth;
use Illuminate\Http\Request;
use Lang;
use Session;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct()
    {
        $this->middleware('auth:web-front');
    }

    /**
     * Show User Profile.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     *
     */

    public function getMyAccount()
    {
        $isMyAcc = 1;
        return view('front.user.my-account', compact('isMyAcc'));
    }

    /**
     * Update User Profile Information
     *
     * @param $request
     *
     * @return bool
     *
     */

    public function postMyAccount(Request $request)
    {
        $this->validate($request, [
            'user_name' => 'required',
            'user_dob' => 'required|date',
            'phone_number' => 'required|regex:/[0-9]/',
        ], [
            'user_name.required' => Lang::get('message.valid_name_req'),
            'user_dob.*' => Lang::get('message.valid_dob_req'),
            'phone_number.*' => Lang::get('message.valid_phone_req'),
        ]);

        $user_id = Auth::guard('web-front')->user()->id;
        $user = User::where('id', $user_id)->first();
        $user->name = $request->user_name;
        $user->dob = $request->user_dob;
        $user->phone_number = $request->phone_number;
        $user->save();

        Session::flash('success', Lang::get('home.profile_update_succ'));
        return back();
    }

    /**
     * Show User Change Password.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     *
     */

    public function getChangePassword()
    {
        $isCPass = 1;
        return view('front.user.change-password', compact('isCPass'));
    }

    /**
     * Update User Profile Information
     *
     * @param $request
     *
     * @return bool
     *
     */

    public function updatePassword(Request $request)
    {
        $this->validate($request,
            [
                'password' => 'required|min:5|regex:/^(?=.*[a-zA-Z])(?=.*[0-9]).+$/',
                'confirm_password' => 'required |same:password',
            ],
            [
                'password.regex' => Lang::get('message.password_rule_txt'),
                'confirm_password.same' => Lang::get('message.cpassword_rule_txt'),
            ]);

        $user_id = Auth::guard('web-front')->user()->id;
        $user = User::where('id', $user_id)->first();
        if ($user) {
            $user->password = bcrypt($request->password);
            $user->save();
            Session::flash('success', Lang::get('home.pass_update_succ'));
            return back();
        }
    }

    /**
     * Show User Change Password.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     *
     */

    public function getShippingAddress()
    {
        $isAddrBk = 1;
        return view('front.user.shipping-address', compact('isAddrBk'));
    }

    /**
     * Show User WishList
     *  
     * @return \Illuminate\Contracts\Support\Renderable
     * 
     */

    public function getUserWishList()
    {
        $isWishList = 1;
        return view('front.user.user-wishlist', compact('isWishList'));
    }

    /**
     * Show User Recently Viewed
     *  
     * @return \Illuminate\Contracts\Support\Renderable
     * 
     */

    public function getUserRecentlyViewed()
    {
        $isRecVew = 1;
        return view('front.user.recently-viewed', compact('isRecVew'));
    }

    /**
     * Get User Earned Points
     *  
     * @return \Illuminate\Contracts\Support\Renderable
     * 
     */

    public function getMyPoint()
    {
        $isMyPont = 1;
        return view('front.user.user-points', compact('isMyPont'));
    }

    /**
     * Get User Coupon Information
     *  
     * @return \Illuminate\Contracts\Support\Renderable
     * 
     */

    public function getMyCoupon()
    {
        $isMyCoup = 1;
        return view('front.user.user-coupons', compact('isMyCoup'));
    }

    /**
     * Get User Wallet Information
     *  
     * @return \Illuminate\Contracts\Support\Renderable
     * 
     */

    public function getMyWallet()
    {
        $isMyWall = 1;
        return view('front.user.user-wallet', compact('isMyWall'));
    }

    /**
     * Get User Order Information
     *  
     * @return \Illuminate\Contracts\Support\Renderable
     * 
     */

    public function getMyOrder()
    {
        return view('front.user.user-order');
    }

    /**
     * Get User Order Details
     *  
     * @return \Illuminate\Contracts\Support\Renderable
     * 
     */

    public function getMyOrderDetails()
    {
        return view('front.user.user-order-details');
    }
}
