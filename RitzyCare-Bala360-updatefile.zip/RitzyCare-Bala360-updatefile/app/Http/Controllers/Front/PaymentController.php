<?php

namespace App\Http\Controllers\Front;

use AppHelpers;
use App\Helpers\PayPal;
use App\Http\Controllers\Controller;
use App\Models\ItemInventory;
use App\Models\Order;
use App\Models\OrderBillingInfo;
use App\Models\OrderDetail;
use App\Models\OrderShippingInfo;
use App\Models\Transaction;
use App\Models\TransactionHistory;
use Auth;
use Cart;
use CreditCard;
use Exchange;
use Illuminate\Http\Request;
use Lang;
use Redirect;
use Session;
use App\Jobs\OrderNotification;
use OrderNotificationHelper;

class PaymentController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct()
    {
        $this->middleware('auth:web-front');
    }

    /** PAYMENT PROCESS REQUEST - ALL PAYMENT */

    public function processOrderPayment(Request $request)
    {
        $request->validate([
            'ship_fname' => 'required|regex:/^[A-Za-z _-]+$/',
            'ship_lname' => 'required|regex:/^[A-Za-z _-]+$/',
            'ship_phone' => 'required|numeric',
            'ship_email' => 'required|email',
            'ship_addr' => 'required',
            'ship_building_no' => 'required|numeric',
            'ship_street_no' => 'required|numeric',
            'ship_zone_no' => 'required|numeric',
            'is_billaddr' => 'nullable',
            'bill_fname' => 'required_with_all:is_billaddr|nullable|regex:/^[A-Za-z _-]+$/',
            'bill_lname' => 'required_with_all:is_billaddr|nullable|regex:/^[A-Za-z _-]+$/',
            'bill_phone' => 'required_with_all:is_billaddr|nullable|numeric',
            'bill_email' => 'required_with_all:is_billaddr|nullable|email',
            'bill_addr' => 'required_with_all:is_billaddr',
            'bill_building_no' => 'required_with_all:is_billaddr|nullable|numeric',
            'bill_street_no' => 'required_with_all:is_billaddr|nullable|numeric',
            'bill_zone_no' => 'required_with_all:is_billaddr|nullable|numeric',
            'payment_option' => 'required|numeric',
        ]);

        if (Cart::content()->count() > 0) {
            $isOutOfStock = $isLowStock = $isProduct = 0;
            $outOfStock = $lowStock = array();
            foreach (Cart::content() as $cart) {
                $getStock = ItemInventory::where(['item_id' => $cart->options->item_id, 'id' => $cart->options->variant_id, 'status' => 1])->first();
                if ($getStock) {
                    if ($cart->options->item_type == 1) {
                        $isProduct = 1;
                    }
                    if ($getStock->quantity > 0 && $getStock->quantity < $cart->qty) {
                        $isLowStock = 0;
                        $lowStock[] = array('item_id' => $cart->options->item_id, 'variant_id' => $cart->options->variant_id);
                    }
                    if ($getStock->quantity <= 0) {
                        $outOfStock[] = array('item_id' => $cart->options->item_id, 'variant_id' => $cart->options->variant_id);
                        $isOutOfStock = 1;
                    }
                } else {
                    $outOfStock[] = array('item_id' => $cart->options->item_id, 'variant_id' => $cart->options->variant_id);
                    $isOutOfStock = 1;
                }
            }
            if ($isOutOfStock == 1 && $isLowStock == 0) {
                Session::flash('danger', Lang::get('cart.payment_out_stock'));
                return redirect('cart')->with('out_stock', $outOfStock);
            }
            if ($isOutOfStock == 0 && $isLowStock == 1) {
                Session::flash('danger', Lang::get('cart.payment_low_stock'));
                return redirect('cart')->with('low_stock', $lowStock);
            }
            if ($isOutOfStock == 1 && $isLowStock == 1) {
                Session::flash('danger', Lang::get('cart.payment_stock_blocker'));
                return redirect('cart')->with(['out_stock' => $lowStock, 'low_stock' => $lowStock]);
            }

            $userID = Auth::guard('web-front')->user()->id;
            $userType = Auth::guard('web-front')->user()->is_subscribed; // 1 - Premium User, 0 - Normal User
            $subTot = AppHelpers::formatNumber(Cart::subtotal());
            $deliveryFee = AppHelpers::getDeliveryFee(Session::get('delivery_method'));
            $grandTot = $usdConvert = AppHelpers::formatNumber(($subTot + $deliveryFee));

            $isCouponUse = $isPointsUse = $pointsAmount = 0;
            $couponCode = $rewardPoints = '';

            /** Coupon code & Redeem amount needs to be deduct from $grandTot - Yet to implement (30-08-2021) */

            if ($request->payment_option == 3) { // Paypal
                $usdConvert = AppHelpers::formatNumber(Exchange::convert()->from('QAR')->to('USD')->amount($usdConvert)->get());
            }

            $payID = 'RP' . date('Ymdhis');
            $payRef = 'RPWB' . date('Ymdhis');

            $transID = Transaction::createTransaction($request, $payID, $payRef, $userID, $subTot, $deliveryFee, $grandTot, $isCouponUse, $couponCode, $isPointsUse, $rewardPoints, $pointsAmount, $usdConvert, $isProduct);

            TransactionHistory::logTransactionHistory(Cart::content(), $transID, $payID);

            Session::put('cart_pay_ref', $payID);
            Session::put('cart_pay_mode', $request->payment_option);
            Session::save();

            if ($request->payment_option == 1) { // Credit Card
                $loading = cdn('uploads/loading.svg');
                $crePay = new CreditCard;
                $reqStr = $crePay->getPaymentRequest($grandTot, $payID, $payRef);
                echo "<html>
                    <title>" . $reqStr['site_name'] . ' ' . $reqStr['meta_title'] . "</title>
                    <body onload='javascript:document.redirectForm.submit();' style='background:white;'>
                    <div style='margin-left: 45%;margin-top: 20%;'>
                    <a><img src='" . $loading . "' /></a>
                    </div>
                    <form action='" . $reqStr['redirect_url'] . "' method='POST' name='redirectForm'>
                    " . $reqStr['body_content'] . "
                    </form>
                    </body>
                    </html>";
                exit;
            } else if ($request->payment_option == 2) { // Debit Card

            } else if ($request->payment_option == 3) { // PayPal
                try {
                    $paypal = new PayPal;
                    $response = $paypal->purchase([
                        'amount' => $paypal->formatAmount($usdConvert),
                        'transactionId' => $payID,
                        'currency' => 'USD',
                        'cancelUrl' => route('item-payment-cancelled'),
                        'returnUrl' => route('item-payment-completed'),
                    ]);

                    if ($response->isRedirect()) {
                        $response->redirect();
                    }

                    return redirect()->back()->with([
                        'message' => $response->getMessage(),
                    ]);
                } catch (\Exception$e) {
                    exit('Sorry, there was an error processing your payment. Please try again later.');
                }
            } else if ($request->payment_option == 4) { // COD
                $transInfo = self::completeOrder();
                if ($transInfo) {
                    return redirect('payment/success')->with(['trans_info' => $transInfo, 'status' => 200]);
                } else {
                    Session::flash('danger', Lang::get('cart.payment_failed'));
                    $transInfo = array('ack' => Lang::get('cart.payment_failed'));
                    return redirect('payment/failed')->with(['trans_info' => $transInfo, 'status' => 400]);
                }
            } else if ($request->payment_option == 5) { // RitzyPay

            }

        } else {
            Session::flash('danger', Lang::get('cart.something_wrong'));
            return back();
        }
    }

    /** ONLINE PAYMENT STATUS UPDATE */

    public function updatePaymentStatus(Request $request)
    {
        $payMode = Session::get('cart_pay_mode');
        if ($payMode == 1) { // Credit Card - MIGS
            $gateway = new CreditCard;
            $gatewayResp = $gateway->decodePaymentResponse($request);
            $request['bt_ack'] = $gatewayResp['data']['ack'];
            $request['bt_status'] = $gatewayResp['status'];
            $request['bt_ref'] = $gatewayResp['data']['vpc_TransactionNo'];
            $transInfo = self::completeOrder($request);
            if ($transInfo) {
                return redirect('payment/success')->with(['trans_info' => $transInfo, 'status' => 200]);
            } else {
                Session::flash('danger', Lang::get('cart.payment_failed'));
                $transInfo = array('ack' => Lang::get('cart.payment_failed'));
                return redirect('payment/failed')->with(['trans_info' => $transInfo, 'status' => 400]);
            }
        } else if ($payMode == 3) { // PayPal
            $cartPayRef = Session::get('cart_pay_ref');
            $transInfo = Transaction::where('payment_id', $cartPayRef)->first();

            $paypal = new PayPal;
            $response = $paypal->complete([
                'amount' => $paypal->formatAmount($transInfo->total_amount),
                'transactionId' => $cartPayRef,
                'currency' => 'USD',
                'cancelUrl' => route('item-payment-cancelled'),
                'returnUrl' => route('item-payment-completed'),
            ]);

            if ($response->isSuccessful()) {
                $transInfo = self::completeOrder($response);
                if ($transInfo) {
                    return redirect('payment/success')->with(['trans_info' => $transInfo, 'status' => 200]);
                } else {
                    Session::flash('danger', Lang::get('cart.payment_failed'));
                    $transInfo = array('ack' => Lang::get('cart.payment_failed'));
                    return redirect('payment/failed')->with(['trans_info' => $transInfo, 'status' => 400]);
                }
            } else {

            }
        }
    }

    /** ORDER COMPLETE */

    public function completeOrder($gwResp = '')
    {
        $cartPayRef = Session::get('cart_pay_ref');
        if ($cartPayRef != '') {
            $transInfo = Transaction::updateTransactionStatus($cartPayRef, $gwResp);
            if ($transInfo) {
                return self::successOrder($transInfo);
            } else {
                return false;
            }
        }
    }

    /** ORDER SUCCESS */

    public function successOrder($transDetails = "")
    {
        $orderID = 'RCP' . date('Ymdhis');

        $cartPayRef = Session::get('cart_pay_ref');
        $deliveryMethod = Session::get('delivery_method');

        $schDelSlot = "";
        if ($deliveryMethod != 3) {
            $deliveryDate = date('Y-m-d H:i:s', AppHelpers::getDeliveryDate($deliveryMethod));
        } else {
            $deliveryDate = date('Y-m-d', strtotime(Session::get('sch_delivery_date')));
            $schDelSlot = Session::get('sch_delivery_slot');
        }

        $userID = Auth::guard('web-front')->user()->id;

        $orderDet = Order::createOrder($orderID, $cartPayRef, $userID, $transDetails->is_delivery, $deliveryMethod, $deliveryDate, $schDelSlot);

        $orderUID = $orderDet['order_uid'];

        OrderDetail::createOrderDetail($cartPayRef, $orderUID, $orderID, $transDetails->is_delivery);

        $shipID = OrderShippingInfo::createOrderShippingInfo($transDetails, $orderUID, $orderID);

        if ($transDetails->is_billing == 1 && $shipID > 0) {
            OrderBillingInfo::createOrderShippingInfo($transDetails, $orderUID, $orderID, $shipID);
        }

        OrderNotification::dispatch($orderID, Session::get('locale'));

        //$this->sendNotification($orderID);

        if ($transDetails->payment_mode == 4) {
            $transAck = Lang::get('cart.payment_succ');
            $bankRef = $cartPayRef;
        } else {
            $transAck = $transDetails->acknowledgement;
            $bankRef = $transDetails->transaction_ref;
        }

        $transInfo = array('transaction_date' => $transDetails->created_at, 'transaction_ref' => $orderID, 'bank_ref' => $bankRef, 'transaction_amt' => $transDetails->transaction_amount, 'tracking_code' => $orderDet['tracking_code'], 'delivery_code' => $orderDet['delivery_code'], 'ack' => $transAck);

        return $transInfo;

    }

    /** SEND ORDER CONFIRMATION NOTIFICATION */

    public function sendNotification($orderID = "")
    {
        OrderNotification::dispatch($orderID, 'ar');
        //OrderNotificationHelper::sendNotification($orderID, 'en');
        exit;
    }
}
