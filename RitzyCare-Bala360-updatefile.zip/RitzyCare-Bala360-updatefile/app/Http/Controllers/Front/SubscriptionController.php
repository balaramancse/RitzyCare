<?php

namespace App\Http\Controllers\Front;

use AppHelpers;
use App\Helpers\PayPal;
use App\Http\Controllers\Controller;
use App\Mail\PlanSubscriptionAdminMail;
use App\Mail\PlanSubscriptionMail;
use App\Models\AppProgramme;
use App\Models\Settings;
use App\Models\SubscriptionTransaction;
use App\Models\User;
use App\Models\UserSubscription;
use Carbon\Carbon;
use Exchange;
use Illuminate\Http\Request;
use Lang;
use Mail;
use Redirect;
use Session;

class SubscriptionController extends Controller
{

    private $errorExists = false;
    private $errorMessage;
    private $postData;
    private $responseMap;
    private $secureHashSecret;
    private $hashInput;
    private $message;

    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct()
    {
        $this->middleware('auth:web-front');
    }

    /**
     * Membership Plan Details
     *
     * @return $view
     *
     */

    public function getMemebershipPlans()
    {
        $programs = AppProgramme::where('status', 1)->whereIn('programme_type', [0, 1])->get();
        return view('front.user.membership-plans', compact('programs'));
    }

    /**
     * Membership Plan Payment
     *
     * @return $view
     *
     */

    public function postSubscriptionPayment(Request $request)
    {
        $this->validate($request, [
            'plan_id' => 'required|numeric|regex:/[0-9]/',
            'pay_type' => 'required|numeric|regex:/[0-9]/',
        ], [
            'plan_id.*' => Lang::get('message.valid_subs_plan'),
            'pay_type.*' => Lang::get('message.valid_payment_req'),
        ]);

        $planInfo = AppProgramme::where('status', 1)->whereId($request->plan_id)->first();
        if ($planInfo) {
            $userID = auth()->guard('web-front')->user()->id;
            $payID = "WB" . date('Ymdhis');

            $subTrans = new SubscriptionTransaction;
            $subTrans->payment_id = $payID;
            $subTrans->correlation_id = $payID;
            $subTrans->payment_type = 0; // 0 - Sale, 1 - Authorize
            $subTrans->payment_mode = $request->pay_type;
            $subTrans->payment_status = SubscriptionTransaction::PAYMENT_PENDING;
            $subTrans->plan_id = $request->plan_id;
            $subTrans->user_id = $userID;
            $subTrans->plan_name = $planInfo->title;
            $subTrans->plan_amount = $planInfo->price;
            $subTrans->plan_validity = (is_numeric($planInfo->duration)) ? $planInfo->duration : 1;
            $subTrans->plan_benefits = $planInfo->description;
            $subTrans->transaction_ip = $request->ip();
            $subTrans->save();

            if ($request->pay_type == 1) { // MIGS - CREDIT CARD REQUEST
                $loading = cdn('uploads/pay_loading.gif');
                Session::put('subs_pay_mode', $request->pay_type);
                Session::put('subs_pay_id', $payID);
                $settings = Settings::first();
                $secureSecret = $settings->migs_secret_key;
                $netamt = number_format((float) ($planInfo->price), 2, '.', '');
                $paymentdata = array(
                    "vpc_AccessCode" => $settings->migs_access_code,
                    "vpc_Amount" => ($netamt * 100),
                    "vpc_Command" => 'pay',
                    "vpc_Locale" => 'en',
                    "vpc_MerchTxnRef" => $payID,
                    "vpc_Merchant" => $settings->migs_merchant_id,
                    "vpc_OrderInfo" => $payID,
                    "vpc_ReturnURL" => route('subscription-payment-completed'),
                    "vpc_Currency" => 'QAR',
                    "vpc_Version" => '1',
                );
                ksort($paymentdata);
                $html = $hashinput = "";
                foreach ($paymentdata as $key => $value) {
                    if (strlen($value) > 0) {
                        $html .= '<input type="hidden" name="' . $key . '" value="' . $value . '"/><br>';
                        if ((strlen($value) > 0) && ((substr($key, 0, 4) == "vpc_") || (substr($key, 0, 5) == "user_"))) {
                            $hashinput .= $key . "=" . $value . "&";
                        }
                    }
                }
                $hashinput = rtrim($hashinput, "&");
                $html .= '<input type="hidden" name="vpc_SecureHash" value="' . strtoupper(hash_hmac('SHA256', $hashinput, pack('H*', $secureSecret))) . '"/><input type="hidden" name="vpc_SecureHashType" value="SHA256">';

                $this->Migs_Url = "https://migs-mtf.mastercard.com.au/vpcpay";
                if ($settings->payment_mode == 1) {
                    $this->Migs_Url = "https://migs.mastercard.com.au/vpcpay";
                }

                echo "<html>
                    <title>" . $settings->site_name . ' ' . $settings->meta_title . "</title>
                    <body onload='javascript:document.redirectForm.submit();' style='background:white;'>
                    <div style='margin-left: 45%;margin-top: 20%;'>
                    <a><img src='" . $loading . "' /></a>
                    </div>
                    <form action='" . $this->Migs_Url . "' method='POST' name='redirectForm'>
                    " . $html . "
                    </form>
                    </body>
                    </html>";
                exit;
            } else if ($request->pay_type == 3) {
                try {
                    $paypal = new PayPal;
                    Session::put('subs_pay_mode', $request->pay_type);
                    Session::put('subs_pay_id', $payID);
                    $convertedPrice = Exchange::convert()->from('QAR')->to('USD')->amount($planInfo->price)->get();
                    $response = $paypal->purchase([
                        'amount' => $paypal->formatAmount($convertedPrice),
                        'transactionId' => $payID,
                        'currency' => 'USD',
                        'cancelUrl' => route('subscription-payment-cancelled'),
                        'returnUrl' => route('subscription-payment-completed'),
                    ]);

                    if ($response->isRedirect()) {
                        $response->redirect();
                    }

                    return redirect()->back()->with([
                        'message' => $response->getMessage(),
                    ]);
                } catch (\Exception $e) {
                    exit('Sorry, there was an error processing your payment. Please try again later.');
                }
            }
        } else {
            Session::flash('danger', Lang::get('message.plan_not_exist'));
            return redirect()->back();
        }
    }

    /** Handle Payment Response */

    public function updatePaymentStatus(Request $request)
    {
        $payMode = Session::get('subs_pay_mode');
        $orderID = Session::get('subs_pay_id');
        $settings = Settings::first();

        if ($payMode == 1) {
            $vpc_Txn_Secure_Hash = array_key_exists("vpc_SecureHash", $request->all()) ? $request->vpc_SecureHash : "";
            unset($request->vpc_SecureHash);
            $this->errorExists = false;

            if (strlen($settings->migs_secret_key) > 0 && $request->vpc_TxnResponseCode != "7" && $request->vpc_TxnResponseCode != "F" && $request->vpc_TxnResponseCode != "No Value Returned") {

                foreach ($request->all() as $key => $value) {
                    if (($key != "vpc_SecureHash") && ($key != "vpc_SecureHashType") && (substr($key, 0, 4) == "vpc_")) {
                        $this->addDigitalOrderField($key, $value);
                    }
                }

                $secure_data = $this->hashAllFields();
                if ($vpc_Txn_Secure_Hash == $secure_data) {
                    $this->hashValidated = 0;
                } else {
                    $this->hashValidated = 1;
                    $this->errorExists = true;
                }
                $this->errorExists = $this->hashValidated = 0;
                $amount = array_key_exists("vpc_Amount", $request->all()) ? $request->vpc_Amount : "";
                $locale = array_key_exists("vpc_Locale", $request->all()) ? $request->vpc_Locale : "";
                $batchNo = array_key_exists("vpc_BatchNo", $request->all()) ? $request->vpc_BatchNo : "";
                $command = array_key_exists("vpc_Command", $request->all()) ? $request->vpc_Command : "";
                $message = array_key_exists("vpc_Message", $request->all()) ? $request->vpc_Message : "";
                $version = array_key_exists("vpc_Version", $request->all()) ? $request->vpc_Version : "";
                $cardType = array_key_exists("vpc_Card", $request->all()) ? $request->vpc_Card : "";
                $orderInfo = array_key_exists("vpc_OrderInfo", $request->all()) ? $request->vpc_OrderInfo : "";
                $receiptNo = array_key_exists("vpc_ReceiptNo", $request->all()) ? $request->vpc_ReceiptNo : "";
                $merchantID = array_key_exists("vpc_Merchant", $request->all()) ? $request->vpc_Merchant : "";
                $merchTxnRef = array_key_exists("vpc_MerchTxnRef", $request->all()) ? $request->vpc_MerchTxnRef : "";
                $authorizeID = array_key_exists("vpc_AuthorizeId", $request->all()) ? $request->vpc_AuthorizeId : "";
                $transactionNo = array_key_exists("vpc_TransactionNo", $request->all()) ? $request->vpc_TransactionNo : "";
                $acqResponseCode = array_key_exists("vpc_AcqResponseCode", $request->all()) ? $request->vpc_AcqResponseCode : "";
                $txnResponseCode = array_key_exists("vpc_TxnResponseCode", $request->all()) ? $request->vpc_TxnResponseCode : "";
                $riskOverallResult = array_key_exists("vpc_RiskOverallResult", $request->all()) ? $request->vpc_RiskOverallResult : "";
                // Obtain the 3DS response
                $vpc_3DSECI = array_key_exists("vpc_3DSECI", $request->all()) ? $request->vpc_3DSECI : "";
                $vpc_3DSXID = array_key_exists("vpc_3DSXID", $request->all()) ? $request->vpc_3DSXID : "";
                $vpc_3DSenrolled = array_key_exists("vpc_3DSenrolled", $request->all()) ? $request->vpc_3DSenrolled : "";
                $vpc_3DSstatus = array_key_exists("vpc_3DSstatus", $request->all()) ? $request->vpc_3DSstatus : "";
                $vpc_VerToken = array_key_exists("vpc_VerToken", $request->all()) ? $request->vpc_VerToken : "";
                $vpc_VerType = array_key_exists("vpc_VerType", $request->all()) ? $request->vpc_VerType : "";
                $vpc_VerStatus = array_key_exists("vpc_VerStatus", $request->all()) ? $request->vpc_VerStatus : "";
                $vpc_VerSecurityLevel = array_key_exists("vpc_VerSecurityLevel", $request->all()) ? $request->vpc_VerSecurityLevel : "";
                // CSC Receipt Data
                $cscResultCode = array_key_exists("vpc_CSCResultCode", $request->all()) ? $request->vpc_CSCResultCode : "";
                $ACQCSCRespCode = array_key_exists("vpc_AcqCSCRespCode", $request->all()) ? $request->vpc_AcqCSCRespCode : "";

                $txnResponseCodeDesc = "";
                $cscResultCodeDesc = "";
                $avsResultCodeDesc = "";

                if ($txnResponseCode != "No Value Returned") {
                    $txnResponseCodeDesc = $this->getResultDescription($txnResponseCode);
                }

                if ($cscResultCode != "No Value Returned") {
                    $cscResultCodeDesc = $this->getCSCResultDescription($cscResultCode);
                }

                $subTransInfo = SubscriptionTransaction::where('payment_id', $orderInfo)->first();

                if ($txnResponseCode == "0" && $this->errorExists == 0 && $transactionNo != 0) {
                    if ($subTransInfo) {
                        $subscriptionID = AppHelpers::userSubscriptionID();
                        $userSubs = new UserSubscription;
                        $userSubs->subscription_id = $subscriptionID;
                        $userSubs->subs_pay_ref = $orderInfo;
                        $userSubs->plan_id = $subTransInfo->plan_id;
                        $userSubs->user_id = $subTransInfo->user_id;
                        $userSubs->plan_name = $subTransInfo->plan_name;
                        $userSubs->plan_amount = $subTransInfo->plan_amount;
                        $userSubs->plan_validity = $subTransInfo->plan_validity;
                        $userSubs->plan_benefits = $subTransInfo->plan_benefits;
                        $userSubs->start_date = Carbon::now();
                        $userSubs->end_date = Carbon::now()->addMonths($subTransInfo->plan_validity);
                        $userSubs->plan_status = 1;
                        $userSubs->approve_status = 1;
                        $userSubs->save();

                        $subTransInfo->transaction_ref = $request->vpc_TransactionNo;
                        $subTransInfo->acknowledgement = $txnResponseCodeDesc;
                        $subTransInfo->payment_status = 1;
                        $subTransInfo->transaction_log = json_encode($request->all());
                        $subTransInfo->save();

                        $transInfo = array('transaction_date' => $subTransInfo->created_at, 'transaction_ref' => $orderInfo, 'bank_ref' => $request->vpc_TransactionNo, 'plan_name' => $subTransInfo->plan_name, 'transaction_amt' => $subTransInfo->plan_amount, 'ack' => $txnResponseCodeDesc);

                        User::where('id', $subTransInfo->user_id)->update(['is_subscribed' => 1]);

                        self::sendNotification(auth()->guard('web-front')->user()->email, $transInfo);

                        Session::forget(['subs_pay_mode', 'subs_pay_id']);
                        return redirect('payment/subscription/success')->with('trans_info', $transInfo);

                    } else {
                        $subTransInfo->acknowledgement = $txnResponseCodeDesc;
                        $subTransInfo->payment_status = 2;
                        $subTransInfo->transaction_log = json_encode($request->all());
                        $subTransInfo->save();

                        $transInfo = array('transaction_date' => $subTransInfo->created_at, 'transaction_ref' => $orderInfo, 'bank_ref' => '', 'plan_name' => $subTransInfo->plan_name, 'transaction_amt' => $subTransInfo->plan_amount, 'ack' => $txnResponseCodeDesc);
                        Session::forget(['subs_pay_mode', 'subs_pay_id']);
                        return redirect('payment/subscription/failed')->with('trans_info', $transInfo);
                    }
                } else {
                    $transInfo = array('transaction_date' => $subTransInfo->created_at, 'transaction_ref' => $orderInfo, 'bank_ref' => '', 'plan_name' => $subTransInfo->plan_name, 'transaction_amt' => $subTransInfo->plan_amount, 'ack' => $txnResponseCodeDesc);
                    Session::forget(['subs_pay_mode', 'subs_pay_id']);
                    return redirect('payment/subscription/failed')->with('trans_info', $transInfo);
                }

            } else {
                $errorMsg = Lang::get('credit_pay_failed') . $txnResponseCodeDesc . Lang::get('order_prob');
                Session::flash('danger', $errorMsg);
                return redirect('membership-plans');
            }
        } else if ($payMode == 3) {

            $subTransInfo = SubscriptionTransaction::where('payment_id', $orderID)->first();

            $paypal = new PayPal;

            $response = $paypal->complete([
                'amount' => $paypal->formatAmount($subTransInfo->plan_amount),
                'transactionId' => $orderID,
                'currency' => 'USD',
                'cancelUrl' => route('subscription-payment-cancelled'),
                'returnUrl' => route('subscription-payment-completed'),
            ]);

            if ($response->isSuccessful()) {
                $subscriptionID = AppHelpers::userSubscriptionID();
                $userSubs = new UserSubscription;
                $userSubs->subscription_id = $subscriptionID;
                $userSubs->subs_pay_ref = $orderID;
                $userSubs->plan_id = $subTransInfo->plan_id;
                $userSubs->user_id = $subTransInfo->user_id;
                $userSubs->plan_name = $subTransInfo->plan_name;
                $userSubs->plan_amount = $subTransInfo->plan_amount;
                $userSubs->plan_validity = $subTransInfo->plan_validity;
                $userSubs->plan_benefits = $subTransInfo->plan_benefits;
                $userSubs->start_date = Carbon::now();
                $userSubs->end_date = Carbon::now()->addMonths($subTransInfo->plan_validity);
                $userSubs->plan_status = 1;
                $userSubs->approve_status = 1;
                $userSubs->save();

                $subTransInfo->transaction_ref = $response->getTransactionReference();
                $subTransInfo->acknowledgement = 'Success';
                $subTransInfo->payment_status = SubscriptionTransaction::PAYMENT_COMPLETED;
                $subTransInfo->transaction_log = (($response->getData()) ? json_encode($response->getData()) : "");
                $subTransInfo->save();

                $transInfo = array('transaction_date' => $subTransInfo->created_at, 'transaction_ref' => $orderID, 'bank_ref' => $response->getTransactionReference(), 'plan_name' => $subTransInfo->plan_name, 'transaction_amt' => $subTransInfo->plan_amount, 'ack' => Lang::get('message.trans_succ'));

                User::where('id', $subTransInfo->user_id)->update(['is_subscribed' => 1]);
                self::sendNotification(auth()->guard('web-front')->user()->email, $transInfo);

                Session::forget(['subs_pay_mode', 'subs_pay_id']);
                return redirect('payment/subscription/success')->with('trans_info', $transInfo);
            } else {
                $subTransInfo->acknowledgement = 'Cancelled';
                $subTransInfo->payment_status = SubscriptionTransaction::PAYMENT_FAILED;
                $subTransInfo->transaction_log = (($response->getData()) ? json_encode($response->getData()) : "");
                $subTransInfo->save();

                $transInfo = array('transaction_date' => $subTransInfo->created_at, 'transaction_ref' => $orderID, 'bank_ref' => '', 'plan_name' => $subTransInfo->plan_name, 'transaction_amt' => $subTransInfo->plan_amount, 'ack' => Lang::get('message.trans_failed'));

                Session::forget(['subs_pay_mode', 'subs_pay_id']);
                return redirect('payment/subscription/failed')->with('trans_info', $transInfo);
            }
        } else {
            Session::flash('danger', Lang::get('message.something_went_wrong'));
            return redirect('/membership-plans');
        }
    }

    /** Email Notification */

    public function sendNotification($email = "", $transInfo = "")
    {
        $transInfo = json_decode(json_encode($transInfo), FALSE); // Array to object conversion
        Mail::to($email)->send(new PlanSubscriptionMail($transInfo));
        Mail::to(env('MAIL_FROM_ADDRESS'))->send(new PlanSubscriptionAdminMail($transInfo));
    }

    /** Digitial Order Payment Response Parameters */

    public function addDigitalOrderField($field, $value)
    {
        if (strlen($value) == 0) {
            return false;
        }
        if (strlen($field) == 0) {
            return false;
        }
        $this->postData .= (($this->postData == "") ? "" : "&") . urlencode($field) . "=" . urlencode($value);
        $this->hashInput .= $field . "=" . $value . "&";
        return true;
    }

    /** Hashing Payment Parameters */

    public function hashAllFields()
    {
        $this->hashInput = rtrim($this->hashInput, "&");
        return strtoupper(hash_hmac('SHA256', $this->hashInput, pack("H*", $this->secureHashSecret)));
    }

    /** Payment Response Description */

    public function getResultDescription($responseCode)
    {
        switch ($responseCode) {
            case "0":$result = "Transaction Successful";
                break;
            case "?":$result = "Transaction status is unknown";
                break;
            case "E":$result = "Referred";
                break;
            case "1":$result = "Transaction Declined";
                break;
            case "2":$result = "Bank Declined Transaction";
                break;
            case "3":$result = "No Reply from Bank";
                break;
            case "4":$result = "Expired Card";
                break;
            case "5":$result = "Insufficient funds";
                break;
            case "6":$result = "Error Communicating with Bank";
                break;
            case "7":$result = "Payment Server detected an error";
                break;
            case "8":$result = "Transaction Type Not Supported";
                break;
            case "9":$result = "Bank declined transaction (Do not contact Bank)";
                break;
            case "A":$result = "Transaction Aborted";
                break;
            case "B":$result = "Fraud Risk Blocked";
                break;
            case "C":$result = "Transaction Cancelled";
                break;
            case "D":$result = "Deferred transaction has been received and is awaiting processing";
                break;
            case "E":$result = "Transaction Declined - Refer to card issuer";
                break;
            case "F":$result = "3D Secure Authentication failed";
                break;
            case "I":$result = "Card Security Code verification failed";
                break;
            case "L":$result = "Shopping Transaction Locked (Please try the transaction again later)";
                break;
            case "M":$result = "Transaction Submitted (No response from acquirer)";
                break;
            case "N":$result = "Cardholder is not enrolled in Authentication scheme";
                break;
            case "P":$result = "Transaction has been received by the Payment Adaptor and is being processed";
                break;
            case "R":$result = "Transaction was not processed - Reached limit of retry attempts allowed";
                break;
            case "S":$result = "Duplicate SessionID (Amex Only)";
                break;
            case "T":$result = "Address Verification Failed";
                break;
            case "U":$result = "Card Security Code Failed";
                break;
            case "V":$result = "Address Verification and Card Security Code Failed";
                break;
            default:$result = "Unable to be determined";
        }
        return $result;
    }

    /** Payment Response CSR Description */

    public function getCSCResultDescription($cscResultCode)
    {
        if ($cscResultCode != "") {
            switch ($cscResultCode) {
                case "Unsupported":$result = "CSC not supported or there was no CSC data provided";
                    break;
                case "M":$result = "Exact code match";
                    break;
                case "S":$result = "Merchant has indicated that CSC is not present on the card (MOTO situation)";
                    break;
                case "P":$result = "Code not processed";
                    break;
                case "U":$result = "Card issuer is not registered and/or certified";
                    break;
                case "N":$result = "Code invalid or not matched";
                    break;
                default:$result = "Unable to be determined";
                    break;
            }
        } else {
            $result = "null response";
        }
        return $result;
    }

    public function sendMOTODigitalOrder($vpcURL, $proxyHostAndPort = "", $proxyUserPwd = "")
    {
        $message = "";
        if (strlen($this->postData) == 0) {
            return false;
        }

        ob_start();
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $vpcURL);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $this->postData);
        if (strlen($proxyHostAndPort) > 0) {
            if (strlen($proxyUserPwd) > 0) {
                curl_setopt($ch, CURLOPT_PROXY, $proxyHostAndPort, CURLOPT_PROXYUSERPWD, $proxyUserPwd);
            } else {
                curl_setopt($ch, CURLOPT_PROXY, $proxyHostAndPort);
            }
        }
        //turn on/off cert validation
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 0 = don't verify peer, 1 = do verify
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); // 0 = don't verify hostname, 1 = check for existence of hostame, 2 = verify
        curl_exec($ch);
        $response = ob_get_contents();
        ob_end_clean();
        $this->errorMessage = "";
        if (strchr($response, "<HTML>") || strchr($response, "<html>")) {;
            $this->errorMessage = $response;
        } else {
            if (curl_error($ch)) {
                $this->errorMessage = "curl_errno=" . curl_errno($ch) . " (" . curl_error($ch) . ")";
            }

        }
        curl_close($ch);
        $this->responseMap = array();
        if (strlen($message) == 0) {
            $pairArray = explode("&", $response);
            foreach ($pairArray as $pair) {
                $param = explode("=", $pair);
                $this->responseMap[urldecode($param[0])] = urldecode($param[1]);
            }
            return true;
        } else {
            return false;
        }
    }

    public function getDigitalOrder($vpcURL)
    {
        $redirectURL = $vpcURL . "?" . $this->postData;
        return $redirectURL;
    }

    public function decryptDR($digitalReceipt)
    {
        if (!$this->socketCreated) {
            return false;
        }

        if ($this->errorExists) {
            return false;
        }

        $cmdResponse = $this->sendCommand("3,$digitalReceipt");
        if (substr($cmdResponse, 0, 1) != "1") {
            $cmdResponse = $this->sendCommand("4,PaymentClient.Error");
            if (substr($cmdResponse, 0, 1) == "1") {$exception = substr($cmdResponse, 2);}
            $this->errorMessage = "(11) Digital Order has not created correctly - decryptDR($digitalReceipt) failed - $exception";
            $this->errorExists = true;
            return false;
        }
        $this->payClientTimeout = $this->SHORT_SOCKET_TIMEOUT;
        $this->nextResult();
        return true;
    }

    public function getResultField($field)
    {
        return $this->null2unknown($field);
    }

    public function getErrorMessage()
    {
        return $this->errorMessage;
    }

    public function setSecureSecret($secret)
    {
        $this->secureHashSecret = $secret;
    }

    private function null2unknown($key)
    {
        if (array_key_exists($key, $this->responseMap)) {
            if (!is_null($this->responseMap[$key])) {
                return $this->responseMap[$key];
            }
        }
        return "No Value Returned";
    }

    /** CREDIT CARD PAYMENT END */
}
