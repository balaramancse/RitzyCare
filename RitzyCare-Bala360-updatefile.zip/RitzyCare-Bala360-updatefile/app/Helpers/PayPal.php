<?php

namespace App\Helpers;

use Omnipay\Omnipay;
use App\Models\Settings;

/**
 * Class PayPal
 * @package App
 */
class PayPal
{
    /**
     * @return mixed
     */
    public function gateway()
    {
        $setting = Settings::first();

        $gateway = Omnipay::create('PayPal_Express');

        $gateway->setUsername($setting->paypal_account);
        $gateway->setPassword($setting->paypal_api);
        $gateway->setSignature($setting->paypal_signature);        
        if ($setting->payment_mode == 1) {
            $gateway->setTestMode(false);
        } else {
            $gateway->setTestMode(true);
        }

        return $gateway;
    }

    /**
     * @param array $parameters
     * @return mixed
     */
    public function purchase(array $parameters)
    {
        $response = $this->gateway()
            ->purchase($parameters)
            ->send();

        return $response;
    }

    /**
     * @param array $parameters
     */
    public function complete(array $parameters)
    {
        $response = $this->gateway()
            ->completePurchase($parameters)
            ->send();

        return $response;
    }

    /**
     * @param $amount
     */
    public function formatAmount($amount)
    {
        return number_format($amount, 2, '.', '');
    }

    /**
     * @param $order
     */
    public function getCancelUrl($order)
    {
        return route('paypal.checkout.cancelled', $order->id);
    }

    /**
     * @param $order
     */
    public function getReturnUrl($order)
    {
        return route('paypal.checkout.completed', $order->id);
    }

    /**
     * @param $order
     */
    public function getNotifyUrl($order)
    {
        //$env = config('services.paypal.sandbox') ? "sandbox" : "live";

        //return route('webhook.paypal.ipn', [$order->id, $env]);
    }
}