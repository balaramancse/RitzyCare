<?php

use App\Models\Category;
use App\Models\Items;
use App\Models\Settings;
use App\Models\UserSubscription;
use Carbon\Carbon;

class AppHelpers
{

    /** GET VENDOR PAY CYCLE START & END DATE */

    public static function getPayCycleDetails($pay_cycle)
    {
        switch ($pay_cycle) {
            case 0: // Custom Date
                $payCStart = date('Y-m-d H:i:s');
                $payCEnd = date('Y-m-d H:i:s', strtotime('+1 month', strtotime($payCStart)));
                break;
            case 1: // Every 15 days once
                $payCStart = date('Y-m-d H:i:s');
                $payCEnd = date('Y-m-d H:i:s', strtotime('+15 days'));
                break;
            case 2: // Every 30 days once
                $payCStart = date('Y-m-d H:i:s');
                $payCEnd = date('Y-m-d H:i:s', strtotime('+30 days'));
                break;
            case 3: // Every month 15th
                $payCStart = date('Y-m-d H:i:s');
                $payCEnd = date('Y-m-d H:i:s', mktime(0, 0, 0, date('n') + (date('j') >= 15), 15));
                break;
            case 4: // Every month end
                $payCStart = date('Y-m-d H:i:s');
                $payCEnd = (date('t') == date('d')) ? date('Y-m-t H:i:s', strtotime('next month')) : date('Y-m-t H:i:s');
                break;
            default:
                $payCStart = date('Y-m-d H:i:s');
                $payCEnd = date('Y-m-d H:i:s', strtotime('+30 days'));
        }
        $data['startDate'] = $payCStart;
        $data['endDate'] = $payCEnd;
        return $data;
    }

    /** GET ATTRIBUTE TYPE DESC */

    public static function getAttributeTypeDesc($aType = "")
    {
        $attrTypeConst = config('ritzycare.attribute_type_const');

        return $attrTypeConst[$aType];
    }

    /** GET ALPHA NUMERIC SEQUENCE */

    public static function generateAlphaNumericCode($charLimit = 6, $rType = "uppercase")
    {
        if ($rType == "uppercase") {
            return strtoupper(substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstvwxyz", 5)), 0, $charLimit));
        } else {
            return substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstvwxyz", 5)), 0, $charLimit);
        }
    }

    /** GET ATTRIBUTE CATEGORY */

    public static function getAttributeCategory($cateID = "")
    {
        $attrCate = array('0' => 'Text', '1' => 'Color', '2' => 'Image');
        return $attrCate[$cateID];
    }

    /** GENERATE BREADCRUMB */

    public static function getCategoryByProduct($value = '')
    {
        $item = Items::whereSlug($value)->where(['status' => 1, 'is_active' => 1])->first();
        if ($item) {
            $maincat_data = Category::whereId($item->category_id)->whereStatus(1)->first();
            $subcat_data = Category::whereId($item->sub_category_id)->whereStatus(1)->first();
            $secsub_data = Category::whereId($item->sec_subcategory_id)->whereStatus(1)->first();
            $third_data = Category::whereId($item->third_category_id)->whereStatus(1)->first();
        }
        $data['main'] = (isset($maincat_data)) ? $maincat_data->category_name : null;
        $data['main_slug'] = (isset($maincat_data)) ? $maincat_data->slug : null;
        $data['sub'] = (isset($subcat_data)) ? $subcat_data->category_name : null;
        $data['sub_slug'] = (isset($subcat_data)) ? $subcat_data->slug : null;
        $data['secsub'] = (isset($secsub_data)) ? $secsub_data->category_name : null;
        $data['secsub_slug'] = (isset($secsub_data)) ? $secsub_data->slug : null;
        $data['third'] = (isset($third_data)) ? $third_data->category_name : null;
        $data['third_slug'] = (isset($third_data)) ? $third_data->slug : null;

        return $data;
    }

    /** NUMBER FORMAT */

    public static function formatNumber($num = "")
    {
        return number_format($num, 1, ".", "") + 0;
    }

    /** GET AFFILIATE USER TYPE */

    public static function getAffUserType($uType = "", $lang = "")
    {
        $usr_type = Config::get('ritzycare.affiliate_who_am');
        $lang = ($lang == 'ar') ? "ar" : "en";
        return $usr_type[$uType][$lang];
    }

    /** STRING MASKING - MIDDLE PART */

    public static function stringToSecret(string $string = null)
    {
        if (!$string) {
            return null;
        }
        $length = strlen($string);
        $visibleCount = (int) round($length / 4);
        $hiddenCount = $length - ($visibleCount * 2);
        return substr($string, 0, $visibleCount) . str_repeat('*', $hiddenCount) . substr($string, ($visibleCount * -1), $visibleCount);
    }

    /** GENERATE PLAN SUBSCRIPTION ID */

    public static function userSubscriptionID()
    {
        $subsID = "000000";
        $checkPrev = UserSubscription::orderby('id', 'desc')->first();
        if ($checkPrev) {
            $lastID = explode('US', $checkPrev->subscription_id);
            $lastIDSufix = array_values(array_filter($lastID));
            $subsID = sprintf("%06d", ($lastIDSufix[0] + 1));
        }
        return "US" . $subsID;
    }

    /** GET DELIVERY METHOD BASED DELIVERY HOURS */

    public static function getDeliveryHours($delType = 1)
    {
        return (($delType == 1) ? Settings::first()->express_delivery_hrs . ' - ' . (Settings::first()->express_delivery_hrs + 4) : Settings::first()->standard_delivery_hrs + 4);
    }

    /** GET DELIVERY SLOT DESC */

    public static function deliverySlotDesc($slotID = '9AM')
    {
        return Config::get('ritzycare.delivery_slots')[$slotID];
    }
    
    /** GET DELIVERY METHOD BASED DELIVERY HOURS */

    public static function getDeliveryFee($delType = 1)
    {
        if ($delType == 1) {
            $delFee = (Settings::first()) ? Settings::first()->express_delivery : 0;
        } else if ($delType == 2) {
            $delFee = (Settings::first()) ? Settings::first()->standard_delivery : 0;
        } else if ($delType == 3) {
            $delFee = (Settings::first()) ? Settings::first()->scheduled_delivery : 0;
        }
        return $delFee;
    }

    /** GET DELIVERY DATE BASED ON DELIVERY METHOD */

    public static function getDeliveryDate($delivery_option = "")
    {
        $setting = Settings::first();
        $delivery_date = strtotime(Carbon::tomorrow());
        $current_time = strtotime(date('h:i:s A'));
        if ($delivery_option == 1) { //Express Delivery
            if ($current_time < strtotime('03:00:00PM')) {
                $delivery_date = strtotime(date("d-m-Y h:i:s A", strtotime('+' . $setting->express_delivery_hrs . ' hours')));
            } else {
                $delivery_date = strtotime(date("Y-m-d H:i", mktime(18, 00, 0, date('n'), date('j') + 1, date('Y'))));
            }
        } elseif ($delivery_option == 2) { //Standard Delivery
            if ($current_time < strtotime('10:00:00PM')) {
                $delivery_date = strtotime(date("d-m-Y H:i", strtotime('+' . $setting->standard_delivery_hrs . ' hours')));
            } else {
                $delivery_date = strtotime(date("Y-m-d H:i", mktime(18, 00, 0, date('n'), date('j') + 1, date('Y'))));
            }
        } elseif ($delivery_option == 3) { //Scheduled Delivery
            $delivery_date = 0;
        }
        return $delivery_date;
    }

    /** GET TRACKING & DELIVERY ALPHA NUMERIC SEQUENCE */

    public static function getTDCode($charLimit = 6, $rType = "")
    {
        if ($rType == "tracking") {
            return "RCTK".substr(str_shuffle(str_repeat("0123456789", 5)), 0, $charLimit);
        } else {
            return substr(str_shuffle(str_repeat("0123456789", 5)), 0, $charLimit);
        }
    }

    /** GET PAYMENT MODE TEXT */

    public static function getPaymentMethodDesc($payMode = "")
    {
        $pay_modes = array('1' => Lang::get('cart.credt_card'), '2' => Lang::get('cart.debt_card'), '3' => Lang::get('cart.paypal'), '4' => Lang::get('cart.cod'), '5' => Lang::get('cart.ritzy_pay'));
        
        return $pay_modes[$payMode];
    } 

    /** GET DELIVERY MODE TEXT */

    public static function getDeliveryMethodDesc($delMode = "")
    {
        $del_modes = array('1' => Lang::get('cart.express'), '2' => Lang::get('cart.standard'), '3' => Lang::get('cart.scheduled_txt'));
        
        return $del_modes[$delMode];
    } 
}
