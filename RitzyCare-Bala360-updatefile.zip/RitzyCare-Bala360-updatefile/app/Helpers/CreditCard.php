<?php

use App\Models\Settings;

class CreditCard
{
    private $errorExists = false;
    private $errorMessage;
    private $postData;
    private $responseMap;
    private $secureHashSecret;
    private $hashInput;
    private $message;

    public function __construct()
    {
        $settings = Settings::first();
        $this->secureSecret = $settings->migs_secret_key;
        $this->accessCode = $settings->migs_access_code;
        $this->merchantId = $settings->migs_merchant_id;
        $this->paymentMode = $settings->payment_mode;
        $this->siteName = $settings->site_name;
        $this->metaTitle = $settings->meta_title;
    }

    /** GENERATE CREDITCARD PAYMENT REQUEST */

    public function getPaymentRequest($grandTot, $payID, $payRef)
    {
        $paymentdata = array(
            "vpc_AccessCode" => $this->accessCode,
            "vpc_Amount" => ($grandTot * 100),
            "vpc_Command" => 'pay',
            "vpc_Locale" => 'en',
            "vpc_MerchTxnRef" => $payID,
            "vpc_Merchant" => $this->merchantId,
            "vpc_OrderInfo" => $payRef,
            "vpc_ReturnURL" => route('item-payment-completed'),
            "vpc_Currency" => 'QAR',
            "vpc_Version" => '1',
        );
        ksort($paymentdata);
        $html = $hashinput = "";
        foreach ($paymentdata as $key => $value) {
            if (strlen($value) > 0) {
                $html .= '<input type="hidden" name="' . $key . '" value="' . $value . '"/><br>';
                if ((strlen($value) > 0) && ((substr($key, 0, 4) == "vpc_") || (substr($key, 0, 5) == "user_"))) {
                    $hashinput .= $key . "=" . $value . "&";
                }
            }
        }

        $hashinput = rtrim($hashinput, "&");
        $html .= '<input type="hidden" name="vpc_SecureHash" value="' . strtoupper(hash_hmac('SHA256', $hashinput, pack('H*', $this->secureSecret))) . '"/><input type="hidden" name="vpc_SecureHashType" value="SHA256">';

        $this->Migs_Url = "https://migs-mtf.mastercard.com.au/vpcpay";
        if ($this->paymentMode == 1) {
            $this->Migs_Url = "https://migs.mastercard.com.au/vpcpay";
        }

        $responseData = array('redirect_url' => $this->Migs_Url, 'body_content' => $html, 'site_name' => $this->siteName, 'meta_title' => $this->metaTitle);

        return $responseData;
    }

    /** Response Handle - After Payment */

    public function decodePaymentResponse($request)
    {
        $vpc_Txn_Secure_Hash = array_key_exists("vpc_SecureHash", $request->all()) ? $request->vpc_SecureHash : "";
        unset($request->vpc_SecureHash);
        $this->errorExists = false;
        
        if (strlen($this->secureSecret) > 0 && $request->vpc_TxnResponseCode != "7" && $request->vpc_TxnResponseCode != "F" && $request->vpc_TxnResponseCode != "No Value Returned") {

            foreach ($request->all() as $key => $value) {
                if (($key != "vpc_SecureHash") && ($key != "vpc_SecureHashType") && (substr($key, 0, 4) == "vpc_")) {
                    $this->addDigitalOrderField($key, $value);
                }
            }

            $secure_data = $this->hashAllFields();
            if ($vpc_Txn_Secure_Hash == $secure_data) {
                $this->hashValidated = 0;
            } else {
                $this->hashValidated = 1;
                $this->errorExists = true;
            }
            $this->errorExists = $this->hashValidated = 0;
            $amount = array_key_exists("vpc_Amount", $request->all()) ? $request->vpc_Amount : "";
            $locale = array_key_exists("vpc_Locale", $request->all()) ? $request->vpc_Locale : "";
            $batchNo = array_key_exists("vpc_BatchNo", $request->all()) ? $request->vpc_BatchNo : "";
            $command = array_key_exists("vpc_Command", $request->all()) ? $request->vpc_Command : "";
            $message = array_key_exists("vpc_Message", $request->all()) ? $request->vpc_Message : "";
            $version = array_key_exists("vpc_Version", $request->all()) ? $request->vpc_Version : "";
            $cardType = array_key_exists("vpc_Card", $request->all()) ? $request->vpc_Card : "";
            $orderInfo = array_key_exists("vpc_OrderInfo", $request->all()) ? $request->vpc_OrderInfo : "";
            $receiptNo = array_key_exists("vpc_ReceiptNo", $request->all()) ? $request->vpc_ReceiptNo : "";
            $merchantID = array_key_exists("vpc_Merchant", $request->all()) ? $request->vpc_Merchant : "";
            $merchTxnRef = array_key_exists("vpc_MerchTxnRef", $request->all()) ? $request->vpc_MerchTxnRef : "";
            $authorizeID = array_key_exists("vpc_AuthorizeId", $request->all()) ? $request->vpc_AuthorizeId : "";
            $transactionNo = array_key_exists("vpc_TransactionNo", $request->all()) ? $request->vpc_TransactionNo : "";
            $acqResponseCode = array_key_exists("vpc_AcqResponseCode", $request->all()) ? $request->vpc_AcqResponseCode : "";
            $txnResponseCode = array_key_exists("vpc_TxnResponseCode", $request->all()) ? $request->vpc_TxnResponseCode : "";
            $riskOverallResult = array_key_exists("vpc_RiskOverallResult", $request->all()) ? $request->vpc_RiskOverallResult : "";
            // Obtain the 3DS response
            $vpc_3DSECI = array_key_exists("vpc_3DSECI", $request->all()) ? $request->vpc_3DSECI : "";
            $vpc_3DSXID = array_key_exists("vpc_3DSXID", $request->all()) ? $request->vpc_3DSXID : "";
            $vpc_3DSenrolled = array_key_exists("vpc_3DSenrolled", $request->all()) ? $request->vpc_3DSenrolled : "";
            $vpc_3DSstatus = array_key_exists("vpc_3DSstatus", $request->all()) ? $request->vpc_3DSstatus : "";
            $vpc_VerToken = array_key_exists("vpc_VerToken", $request->all()) ? $request->vpc_VerToken : "";
            $vpc_VerType = array_key_exists("vpc_VerType", $request->all()) ? $request->vpc_VerType : "";
            $vpc_VerStatus = array_key_exists("vpc_VerStatus", $request->all()) ? $request->vpc_VerStatus : "";
            $vpc_VerSecurityLevel = array_key_exists("vpc_VerSecurityLevel", $request->all()) ? $request->vpc_VerSecurityLevel : "";
            // CSC Receipt Data
            $cscResultCode = array_key_exists("vpc_CSCResultCode", $request->all()) ? $request->vpc_CSCResultCode : "";
            $ACQCSCRespCode = array_key_exists("vpc_AcqCSCRespCode", $request->all()) ? $request->vpc_AcqCSCRespCode : "";

            $txnResponseCodeDesc = "";
            $cscResultCodeDesc = "";
            $avsResultCodeDesc = "";

            if ($txnResponseCode != "No Value Returned") {
                $txnResponseCodeDesc = $this->getResultDescription($txnResponseCode);
            }

            if ($cscResultCode != "No Value Returned") {
                $cscResultCodeDesc = $this->getCSCResultDescription($cscResultCode);
            }
            
            if ($txnResponseCode == "0" && $this->errorExists == 0 && $transactionNo != 0) {
                $transInfo = array('vpc_TransactionNo' => $request->vpc_TransactionNo, 'ack' => $txnResponseCodeDesc);
                $data = array('status' => 200, 'data' => $transInfo);
            } else {
                $transInfo = array('vpc_TransactionNo' => '', 'ack' => $txnResponseCodeDesc);
                $data = array('status' => 204, 'data' => $transInfo);               
            }
            return $data;
        } else {
            $resp['ack'] = "Failed";
            $data = array('status' => 400, 'data' => $resp);
            return $data;
        }
    }

    /** Digitial Order Payment Response Parameters */

    public function addDigitalOrderField($field, $value)
    {
        if (strlen($value) == 0) {
            return false;
        }
        if (strlen($field) == 0) {
            return false;
        }
        $this->postData .= (($this->postData == "") ? "" : "&") . urlencode($field) . "=" . urlencode($value);
        $this->hashInput .= $field . "=" . $value . "&";
        return true;
    }

    /** Hashing Payment Parameters */

    public function hashAllFields()
    {
        $this->hashInput = rtrim($this->hashInput, "&");
        return strtoupper(hash_hmac('SHA256', $this->hashInput, pack("H*", $this->secureHashSecret)));
    }

    /** Payment Response Description */

    public function getResultDescription($responseCode)
    {
        switch ($responseCode) {
            case "0":$result = "Transaction Successful";
                break;
            case "?":$result = "Transaction status is unknown";
                break;
            case "E":$result = "Referred";
                break;
            case "1":$result = "Transaction Declined";
                break;
            case "2":$result = "Bank Declined Transaction";
                break;
            case "3":$result = "No Reply from Bank";
                break;
            case "4":$result = "Expired Card";
                break;
            case "5":$result = "Insufficient funds";
                break;
            case "6":$result = "Error Communicating with Bank";
                break;
            case "7":$result = "Payment Server detected an error";
                break;
            case "8":$result = "Transaction Type Not Supported";
                break;
            case "9":$result = "Bank declined transaction (Do not contact Bank)";
                break;
            case "A":$result = "Transaction Aborted";
                break;
            case "B":$result = "Fraud Risk Blocked";
                break;
            case "C":$result = "Transaction Cancelled";
                break;
            case "D":$result = "Deferred transaction has been received and is awaiting processing";
                break;
            case "E":$result = "Transaction Declined - Refer to card issuer";
                break;
            case "F":$result = "3D Secure Authentication failed";
                break;
            case "I":$result = "Card Security Code verification failed";
                break;
            case "L":$result = "Shopping Transaction Locked (Please try the transaction again later)";
                break;
            case "M":$result = "Transaction Submitted (No response from acquirer)";
                break;
            case "N":$result = "Cardholder is not enrolled in Authentication scheme";
                break;
            case "P":$result = "Transaction has been received by the Payment Adaptor and is being processed";
                break;
            case "R":$result = "Transaction was not processed - Reached limit of retry attempts allowed";
                break;
            case "S":$result = "Duplicate SessionID (Amex Only)";
                break;
            case "T":$result = "Address Verification Failed";
                break;
            case "U":$result = "Card Security Code Failed";
                break;
            case "V":$result = "Address Verification and Card Security Code Failed";
                break;
            default:$result = "Unable to be determined";
        }
        return $result;
    }

    /** Payment Response CSR Description */

    public function getCSCResultDescription($cscResultCode)
    {
        if ($cscResultCode != "") {
            switch ($cscResultCode) {
                case "Unsupported":$result = "CSC not supported or there was no CSC data provided";
                    break;
                case "M":$result = "Exact code match";
                    break;
                case "S":$result = "Merchant has indicated that CSC is not present on the card (MOTO situation)";
                    break;
                case "P":$result = "Code not processed";
                    break;
                case "U":$result = "Card issuer is not registered and/or certified";
                    break;
                case "N":$result = "Code invalid or not matched";
                    break;
                default:$result = "Unable to be determined";
                    break;
            }
        } else {
            $result = "null response";
        }
        return $result;
    }

    public function sendMOTODigitalOrder($vpcURL, $proxyHostAndPort = "", $proxyUserPwd = "")
    {
        $message = "";
        if (strlen($this->postData) == 0) {
            return false;
        }

        ob_start();
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $vpcURL);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $this->postData);
        if (strlen($proxyHostAndPort) > 0) {
            if (strlen($proxyUserPwd) > 0) {
                curl_setopt($ch, CURLOPT_PROXY, $proxyHostAndPort, CURLOPT_PROXYUSERPWD, $proxyUserPwd);
            } else {
                curl_setopt($ch, CURLOPT_PROXY, $proxyHostAndPort);
            }
        }
        //turn on/off cert validation
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 0 = don't verify peer, 1 = do verify
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); // 0 = don't verify hostname, 1 = check for existence of hostame, 2 = verify
        curl_exec($ch);
        $response = ob_get_contents();
        ob_end_clean();
        $this->errorMessage = "";
        if (strchr($response, "<HTML>") || strchr($response, "<html>")) {;
            $this->errorMessage = $response;
        } else {
            if (curl_error($ch)) {
                $this->errorMessage = "curl_errno=" . curl_errno($ch) . " (" . curl_error($ch) . ")";
            }

        }
        curl_close($ch);
        $this->responseMap = array();
        if (strlen($message) == 0) {
            $pairArray = explode("&", $response);
            foreach ($pairArray as $pair) {
                $param = explode("=", $pair);
                $this->responseMap[urldecode($param[0])] = urldecode($param[1]);
            }
            return true;
        } else {
            return false;
        }
    }

    public function getDigitalOrder($vpcURL)
    {
        $redirectURL = $vpcURL . "?" . $this->postData;
        return $redirectURL;
    }

    public function decryptDR($digitalReceipt)
    {
        if (!$this->socketCreated) {
            return false;
        }

        if ($this->errorExists) {
            return false;
        }

        $cmdResponse = $this->sendCommand("3,$digitalReceipt");
        if (substr($cmdResponse, 0, 1) != "1") {
            $cmdResponse = $this->sendCommand("4,PaymentClient.Error");
            if (substr($cmdResponse, 0, 1) == "1") {$exception = substr($cmdResponse, 2);}
            $this->errorMessage = "(11) Digital Order has not created correctly - decryptDR($digitalReceipt) failed - $exception";
            $this->errorExists = true;
            return false;
        }
        $this->payClientTimeout = $this->SHORT_SOCKET_TIMEOUT;
        $this->nextResult();
        return true;
    }

    public function getResultField($field)
    {
        return $this->null2unknown($field);
    }

    public function getErrorMessage()
    {
        return $this->errorMessage;
    }

    public function setSecureSecret($secret)
    {
        $this->secureHashSecret = $secret;
    }

    private function null2unknown($key)
    {
        if (array_key_exists($key, $this->responseMap)) {
            if (!is_null($this->responseMap[$key])) {
                return $this->responseMap[$key];
            }
        }
        return "No Value Returned";
    }
}
