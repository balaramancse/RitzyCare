<?php

use App\Models\Order;
use Illuminate\Support\Facades\Mail;
use App\Mail\OrderPlacementMail;

class OrderNotificationHelper
{

    /** SEND ORDER CONFIRMATION NOTIFICATION - CUSTOMER & VENDOR, ADMIN */

    public static function sendNotification($orderID = "", $contentLang = "")
    {
        App::setLocale($contentLang);

        $orderInfo = Order::with(['orderDetail' => function($q){ $q->join('items','items.id','order_details.item_id'); $q->join('item_inventories','item_inventories.id','order_details.inventory_id'); $q->join('item_attributes','item_attributes.id','item_inventories.attribute_id'); $q->leftjoin('attribute_types','attribute_types.id','item_attributes.attr_type_id'); $q->select('order_details.*','items.item_name','item_attributes.variant_type','item_attributes.attribute_type','item_attributes.attribute_value','attribute_types.attribute_name'); }, 'shipInfo', 'billInfo','customerInfo'])->join('transactions','transactions.payment_id','orders.payment_id')->select('orders.*','transactions.payment_mode','transactions.total_amount','transactions.delivery_amount','transactions.points_amount','transactions.is_coupon_used','transactions.transaction_amount')->where('order_id', $orderID)->first();

        if ($orderInfo) {            
            $appLocale = 'en';
            if($contentLang == 'ar') {
                $appLocale = 'ar';
            }

            $barCode = \DNS1D::getBarcodePNG($orderInfo->delivery_verification_code, "C93", 3, 33, array(1, 1, 1), true);
            $barCodeImg = '<img src="data:image/png;base64,' . $barCode . '" alt="barcode" width="152" height="40" />';

            $isBill = 0;
            if($orderInfo->billInfo !='') {
                $isBill = 1;
            }

            $invoiceHTML = '<table width="700" border="0" cellspacing="0" cellpadding="0" align="center" style="margin:0 auto;background-color: #fff;color: #212121; border-top: 4px solid #0B483C; border-bottom: 4px solid #0B483C; border-left: 1px solid #0B483C; border-right: 1px solid #0B483C;font-family: \'Open Sans\', Arial;">
                    <tr style="background: #F0FFFC;">
                        <td align="center">
                            <table width="660" border="0" cellspacing="0" cellpadding="0" align="center" style="margin:0 auto;">
                            <tr>
                                <td height="20" colspan="3"></td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <img src="'.cdn('uploads/logo.png').'" width="77">
                                </td>
                                <td align="right" width="152">
                                    '.$barCodeImg.'
                                </td>
                            </tr>
                            <tr>
                                <td height="20" colspan="3"></td>
                            </tr>
                            <tr>
                                <td>
                                    <h4 style="margin: 0 0 15px; color: #000; font-weight: 600; font-size: 14px">'.Lang::get('message.inv_customer_info').'</h4>
                                    <h3 style="margin: 0 0 10px; color: #000; font-weight: 700; font-size: 16px">'.ucwords($orderInfo->customerInfo->name).'</h3>
                                    <p style="margin: 0; color: #000; font-weight: 400; font-size: 14px;"><strong>P:</strong> +'.$orderInfo->customerInfo->dial_code.' '.$orderInfo->customerInfo->phone_number.' <br> <strong>E:</strong> '.$orderInfo->customerInfo->email.'</p>
                                </td>
                                <td>
                                    <h4 style="margin: 0 0 15px; color: #000; font-weight: 600; font-size: 14px">'.Lang::get('message.inv_ship_info').'</h4>
                                    <h3 style="margin: 0 0 10px; color: #000; font-weight: 700; font-size: 16px">'.ucwords($orderInfo->shipInfo->first_name).'</h3>
                                    <p style="margin: 0; color: #000; font-weight: 400; font-size: 14px;"><strong>P:</strong>  +974 '.$orderInfo->shipInfo->phone_number.'  <br> <strong>E:</strong> '.$orderInfo->shipInfo->email.' <br> <strong>A:</strong>'.Lang::get('cart.building_no').': '.$orderInfo->shipInfo->building_no.'<br>'.Lang::get('cart.street_no').': '.$orderInfo->shipInfo->street_no.'<br>'.Lang::get('cart.zone_no').': '.$orderInfo->shipInfo->zone_no.'<br>'.Lang::get('cart.address').': '.$orderInfo->shipInfo->address.'</p>
                                </td>
                                ';
                                if($isBill == 1) {
                                    $invoiceHTML .= '<td>
                                        <h4 style="margin: 0 0 15px; color: #000; font-weight: 600; font-size: 14px">'.Lang::get('message.inv_bill_info').'</h4>
                                        <h3 style="margin: 0 0 10px; color: #000; font-weight: 700; font-size: 16px">'.ucwords($orderInfo->billInfo->first_name).'</h3>
                                        <p style="margin: 0; color: #000; font-weight: 400; font-size: 14px;"><strong>P:</strong>  +974 '.$orderInfo->billInfo->phone_number.'  <br> <strong>E:</strong> '.$orderInfo->billInfo->email.' <br> <strong>A:</strong>'.Lang::get('cart.building_no').': '.$orderInfo->billInfo->building_no.'<br>'.Lang::get('cart.street_no').': '.$orderInfo->billInfo->street_no.'<br>'.Lang::get('cart.zone_no').': '.$orderInfo->billInfo->zone_no.'<br>'.Lang::get('cart.address').': '.$orderInfo->billInfo->address.'</p>
                                    </td>'; 
                                }
            $invoiceHTML .= '</tr>
                            <tr>
                                <td height="20" colspan="3"></td>
                            </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td align="center">
                            <table width="660" border="0" cellspacing="0" cellpadding="0" align="center" style="margin:0 auto;">
                            <tr>
                                <td height="20"></td>	
                            </tr>
                            <tr>
                                <td><h3 style="margin: 0 0 10px; color: #153E32; font-weight: 700; font-size: 16px; text-align: center;">'.Lang::get('message.order_summary').'</h3></td>	
                            </tr>
                            <tr>
                                <td style="border-bottom: 2px solid #908A55">
                                <table width="660" border="0" cellspacing="0" cellpadding="0" align="center">
                                    <tr style="background: #908A55;">
                                        <td width="40" style="color: #fff; padding: 10px 10px; text-transform: uppercase; font-size: 11px; font-weight: 600">#</td>
                                        <td width="350" style="color: #fff; padding: 10px 5px; text-transform: uppercase; font-size: 13px; font-weight: 600">'.Lang::get('message.inv_item_desc').'</td>
                                        <td width="90" style="color: #fff; padding: 10px 5px; text-transform: uppercase; font-size: 13px; font-weight: 600">'.Lang::get('message.price').'</td>
                                        <td width="70" style="color: #fff; padding: 10px 5px; text-transform: uppercase; font-size: 13px; font-weight: 600">'.Lang::get('message.inv_qty').'</td> 
                                        <td width="110" style="color: #fff; padding: 10px 10px; text-transform: uppercase; font-size: 13px; font-weight: 600; text-align: right">'.Lang::get('message.inv_total').'</td> 
                                    </tr>'; 
                                $i = 1;
                                foreach($orderInfo->orderDetail as $od) {
                                    $item_name = json_decode($od->item_name)->$appLocale;                                    
                                    $isAttr = 0;  
                                    $attrHTML = "";                                   
                                    if($od->variant_type == 1) {
                                        $isAttr = 1;
                                        if($od->attribute_type != 0) {
                                            $attrHTML .= "<br>".json_decode($od->attribute_name)->$appLocale.': <p style="width:0; border:8px solid '.$od->attribute_value.'"></p>'; 
                                        } else {
                                            $attrHTML .= "<br>".json_decode($od->attribute_name)->$appLocale.': '.$od->attribute_value; 
                                        }
                                    }                                    
                                    $invoiceHTML .= '<tr style="border-bottom: 1px solid #F0F0F0">
                                    <td width="40" style="color: #3A3A3A; padding: 10px 10px; font-size: 13px; font-weight: 600;border-bottom: 1px solid #F0F0F0">'.$i.'</td>
                                    <td width="350" style="color: #3A3A3A; padding: 10px 5px; font-size: 13px; border-bottom: 1px solid #F0F0F0"><span style="font-weight: 700; color: #153E32">'.(($od->item_group == 1)?Lang::get('message.inv_product'):Lang::get('message.service')).'</span><br>'.$item_name.$attrHTML.'</td>
                                    <td width="90" style="color: #3A3A3A; padding: 10px 5px; font-size: 13px; font-weight: 700;border-bottom: 1px solid #F0F0F0">QAR '.$od->order_amount.'</td>
                                    <td width="70" style="color: #3A3A3A; padding: 10px 5px; text-transform: uppercase; font-size: 13px; font-weight: 700;border-bottom: 1px solid #F0F0F0; text-align: center">'.$od->order_qty.'</td> 
                                    <td width="110" style="color: #3A3A3A; padding: 10px 10px; font-size: 13px; font-weight: 700; text-align: right;border-bottom: 1px solid #F0F0F0">QAR '.$od->total_amount.'</td>
                                    </tr>';
                                    $i++;
                                }               
            $invoiceHTML .= '   </table>  
                                </td>	
                            </tr> 	
                            </table>  
                        </td>
                    </tr>
                    <tr>
                        <td height="20" colspan="3"></td>   
                    </tr>
                    <tr>
                        <td colspan="3" align="center">
                            <table width="660" border="0" cellspacing="0" cellpadding="0" align="center" style="margin: 0 auto">
                                <tr>
                                    <td valign="top">
                                        <h4 style="margin: 0 0 5px; color: #153E32; font-weight: 700; font-size: 15px">'.Lang::get('message.pay_method').'</h4>
                                        <p style="margin: 0 0 15px; color: #000; font-weight: 400; font-size: 13px;line-height: 20px">'.AppHelpers::getPaymentMethodDesc($orderInfo->payment_mode).'</p>
                                        <h4 style="margin: 0 0 5px; color: #153E32; font-weight: 700; font-size: 15px">'.Lang::get('cart.delivery').'</h4>
                                        <p style="margin:  0 0 15px; color: #000; font-weight: 400; font-size: 13px;line-height: 20px">'.AppHelpers::getDeliveryMethodDesc($orderInfo->delivery_method).' <br>'.Lang::get('message.inv_delivery_date').': '.(($orderInfo->delivery_method != 3)?date('d-m-Y h:i:s A', strtotime($orderInfo->delivery_date)):date('d-m-Y', strtotime($orderInfo->delivery_date)).' '.AppHelpers::deliverySlotDesc($orderInfo->delivery_slot)).'</p>	
                                    </td>
                                        
                                    <td align="right" valign="top">                                    
                                        <table width="250" border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                            <td style="padding: 10px">
                                                <table width="250" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td style="font-size: 15px; font-weight: 400;color: #000; padding: 10px;border: 1px solid #fff; border-width: 1px 0">'.Lang::get('message.inv_sub_total').'</td>
                                                    <td align="right" style="font-size: 15px; font-weight: 700;color: #000; text-align: right; padding: 10px;border: 1px solid #fff; border-width: 1px 0">QAR '.AppHelpers::formatNumber($orderInfo->total_amount - $orderInfo->delivery_amount).'</td>	
                                                </tr>
                                                <tr style="border: 1px solid #fff; background: #EFFEFB;">
                                                    <td style="font-size: 14px; font-weight: 400;color: #000; padding: 10px;border: 1px solid #fff; border-width: 1px 0">'.Lang::get('message.inv_del_fee').'</td>
                                                    <td align="right" style="font-size: 15px; font-weight: 700;color: #000; text-align: right; padding: 10px;border: 1px solid #fff; border-width: 1px 0">QAR '.$orderInfo->delivery_amount.'</td>	
                                                </tr>';
                                                
                                if($orderInfo->is_coupon_used == 1) { // Based on business rule needs to bind
                                    $invoiceHTML .= '<tr style="border: 1px solid #fff; background: #EFFEFB;">
                                                    <td style="font-size: 14px; font-weight: 400;color: #000; padding: 10px;border: 1px solid #fff; border-width: 1px 0">'.Lang::get('message.inv_coupon_amt').'</td>
                                                    <td align="right" style="font-size: 15px; font-weight: 700;color: #000; text-align: right; padding: 10px;border: 1px solid #fff; border-width: 1px 0">QAR 3000</td>	
                                                </tr>';
                                }

                                if($orderInfo->points_amount > 0) {
                                    $invoiceHTML .= '<tr style="border: 1px solid #fff; background: #EFFEFB;">
                                                    <td style="font-size: 14px; font-weight: 400;color: #000; padding: 10px;border: 1px solid #fff; border-width: 1px 0">'.Lang::get('message.inv_reward_amt').'</td>
                                                    <td align="right" style="font-size: 15px; font-weight: 700;color: #000; text-align: right; padding: 10px;border: 1px solid #fff; border-width: 1px 0">QAR '.$orderInfo->points_amount.'</td>	
                                                </tr>';
                                }

                                $invoiceHTML .= '<tr style="border: 1px solid #fff; background: #153E32;">
                                                    <td style="font-size: 14px; font-weight: 400;color: #fff; padding: 10px;border: 1px solid #fff; border-width: 1px 0">'.Lang::get('message.inv_total').'</td>
                                                    <td align="right" style="font-size: 15px; font-weight: 700;color: #fff; text-align: right; padding: 10px;border: 1px solid #fff; border-width: 1px 0">QAR '.$orderInfo->transaction_amount.'</td>	
                                                </tr>  
                                                </table>  
                                            </td>
                                            </tr>	
                                        </table>
                                    </td>  
                                </tr> 
                            </table>
                        </td>   
                    </tr>
                    <tr>
                        <td height="20" colspan="3"></td>   
                    </tr>
                    <tr>
                        <td colspan="3" style="font-size: 12px; text-align: center; font-weight: 700">* '.Lang::get('message.inv_sign_txt').'</td>   
                    </tr>
                    <tr>
                        <td height="10" colspan="3"></td>   
                    </tr>
                </table>';  

            $pdf_invoice = App::make('dompdf.wrapper');
            $pdf_invoice->loadHTML($invoiceHTML)->setPaper('a2')->setWarnings(false)->save(public_path('uploads/orders/'.$orderID.'.pdf'));

            $data['invoice_html'] = $invoiceHTML;
            $data['order_id'] = $orderID;
            $data['attachment_file'] = public_path('uploads/orders/'.$orderID.'.pdf');
            
            Mail::to($orderInfo->customerInfo->email)->send(new OrderPlacementMail($data));
        }
    }
}
