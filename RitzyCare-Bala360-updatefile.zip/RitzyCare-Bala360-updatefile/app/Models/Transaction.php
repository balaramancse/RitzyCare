<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    use HasFactory;

    const PAYMENT_PENDING = 0;
    const PAYMENT_COMPLETED = 1;
    const PAYMENT_FAILED = 2;
    const PAYMENT_SUCC = "Success";
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'payment_id',
        'correlation_id',
        'transaction_ref',
        'acknowledgement',
        'payment_type',
        'payment_mode',
        'payment_status',        
        'user_id',
        'sub_total',
        'delivery_amount',
        'total_amount',
        'is_coupon_used',
        'coupon_code',
        'is_points_used',
        'reward_points',
        'points_amount',
        'transaction_amount',
        'usd_amount',
        'ship_first_name',
        'ship_last_name',  
        'ship_phone_number',
        'ship_email',            
        'ship_address',
        'ship_building_no',
        'ship_street_no',
        'ship_zone_no',            
        'is_billing',
        'bill_first_name',
        'bill_last_name',  
        'bill_phone_number',
        'bill_email',            
        'bill_address',
        'bill_building_no',
        'bill_street_no',
        'bill_zone_no',
        'is_delivery',   
        'transaction_ip',
        'transaction_log',      
    ];

    /** CREATE TRANSACTION */

    public static function createTransaction($request, $payID, $payRef, $userID, $subTot, $deliveryFee, $grandTot, $isCouponUse = "", $couponCode = "", $isPointsUse = "", $rewardPoints = "", $pointsAmount = "", $usdConvert = "", $isProduct = "")
    {
        $transID = Transaction::create(['payment_id' => $payID, 'correlation_id' => $payRef, 'payment_type' => 0, 'payment_mode' => $request->payment_option, 'payment_status' => self::PAYMENT_PENDING, 'user_id' => $userID, 'sub_total' => $subTot, 'delivery_amount' => $deliveryFee, 'total_amount' => $grandTot, 'is_coupon_used' => $isCouponUse, 'coupon_code' => $couponCode, 'is_points_used' => $isPointsUse, 'reward_points' => $rewardPoints, 'points_amount' => $pointsAmount, 'transaction_amount' => $grandTot, 'usd_amount' => $usdConvert, 'ship_first_name' => $request->ship_fname, 'ship_last_name' => $request->ship_lname, 'ship_phone_number' => $request->ship_phone, 'ship_email' => $request->ship_email, 'ship_address' => $request->ship_addr, 'ship_building_no' => $request->ship_building_no, 'ship_street_no' => $request->ship_street_no, 'ship_zone_no' => $request->ship_zone_no, 'is_billing' => (($request->bill_addr) ? 1 : 0), 'bill_first_name' => $request->bill_fname, 'bill_last_name' => $request->bill_lname, 'bill_phone_number' => $request->bill_phone, 'bill_email' => $request->bill_email, 'bill_address' => $request->bill_addr, 'bill_building_no' => $request->bill_building_no, 'bill_street_no' => $request->bill_street_no, 'bill_zone_no' => $request->bill_zone_no, 'is_delivery' => $isProduct, 'transaction_ip' => $request->ip()])->id;

        return $transID;
    }

    /** UPDATE TRANSACTION STATUS */

    public static function updateTransactionStatus($cartPayRef = "", $gatewayResp = "")
    {
        $transInfo = self::where('payment_id', $cartPayRef)->first();        
        if ($transInfo) { 
            if ($transInfo->payment_mode == 4) {
                $transInfo->acknowledgement = self::PAYMENT_SUCC;
                $transInfo->save();
                return $transInfo;
            } else {   
                if($transInfo->payment_mode == 1) {  // CreditCard      
                    $transInfo->transaction_ref = $gatewayResp->bt_ref;
                    $transInfo->payment_status  = ($gatewayResp->bt_status == 200)?1:2;
                    $transInfo->acknowledgement = $gatewayResp->bt_ack;
                    $transInfo->transaction_log = json_encode($gatewayResp->all());
                    $transInfo->save();
                    return $transInfo;
                } else if($transInfo->payment_mode == 3) { // PayPal
                    $transInfo->transaction_ref = $gatewayResp->getTransactionReference();
                    $transInfo->payment_status  = 1;
                    $transInfo->acknowledgement = self::PAYMENT_SUCC;
                    $transInfo->transaction_log = (($gatewayResp->getData()) ? json_encode($gatewayResp->getData()) : "");
                    $transInfo->save();
                    return $transInfo;
                }
            }
        } else {
            return false;
        }
    }
}
