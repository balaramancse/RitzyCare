<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\TransactionHistory;

class OrderDetail extends Model
{
    use HasFactory;
    use SoftDeletes;

    const ORDER_PENDING = 0;    

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'order_id',
        'master_order_id',
        'sub_order_id',
        'tracking_code',
        'item_id',
        'item_group',
        'vendor_id',        
        'inventory_id',
        'order_qty',
        'order_amount',
        'total_amount',
        'order_status',
        'is_delivery_required',
        'shipped_date',
        'driver_id',
        'driver_assigned_date',
        'dispatch_date',
        'comments',   
    ];

    /** CAPTURE ORDER DETAILS */

    public static function createOrderDetail($cartPayRef, $orderUID, $orderID, $isDelivery)
    {
        $od = 1;
        $transOrderDetails = TransactionHistory::join('item_inventories', 'item_inventories.id', 'transaction_histories.variant_id')->where('payment_id', $cartPayRef)->select('transaction_histories.*', 'item_inventories.vendor_id')->get();
        foreach ($transOrderDetails as $t) {
            $trackingCode = date('Yhis');
            $subOrderID = $orderID . $od;

            $orderDetails = new OrderDetail;
            $orderDetails->order_id = $orderUID;
            $orderDetails->master_order_id = $orderID;
            $orderDetails->sub_order_id = $subOrderID;
            $orderDetails->tracking_code = $trackingCode;
            $orderDetails->item_id = $t->item_id;
            $orderDetails->item_group = $t->item_type;
            $orderDetails->vendor_id = $t->vendor_id;
            $orderDetails->inventory_id = $t->variant_id;
            $orderDetails->order_qty = $t->item_qty;
            $orderDetails->order_amount = $t->item_amount;
            $orderDetails->total_amount = $t->transaction_amount;
            $orderDetails->order_status = self::ORDER_PENDING;
            $orderDetails->is_delivery_required = $isDelivery;
            $orderDetails->save();

            $od++;                
        }
        
        return 1;
    }
}
