<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Translatable\HasTranslations;

class Category extends Model
{
    use HasFactory;
    use HasTranslations;
    use SoftDeletes;

    public $translatable = ['category_name'];
    protected $dates = ['deleted_at'];

    protected $fillable = ['main_category_id', 'sub_category_id', 'category_name', 'meta_title', 'meta_keywords', 'meta_description', 'status', 'slug', 'modified_by', 'app_type', 'created_at', 'updated_at'];

    public static function subCategoryCount($categoryID)
    {
        $subCate = Category::where('categories.main_category_id',$categoryID)->count();
        return $subCate;
    }

    public function parentCategory()
    {
        return $this->belongsTo(self::class , 'main_category_id','id');
    }

    public static function nestedCategoryCount($categoryID)
    {
        $subCate = Category::where('categories.sub_category_id',$categoryID)->count();
        return $subCate;
    }

    /** Get Main Category Based Sub Category */

    public function subCategories()
    {
        return $this->hasMany(self::class , 'main_category_id','id');
    }
}
