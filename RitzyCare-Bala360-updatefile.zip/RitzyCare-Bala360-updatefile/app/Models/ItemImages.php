<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItemImages extends Model
{
    use HasFactory;

    const DEFAULT_IMAGE = "uploads/items/";
    const NO_IMAGE = "uploads/no-images/item-no-image.jpg";
}
