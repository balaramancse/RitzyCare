<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderShippingInfo extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'order_id',
        'master_order_id',
        'first_name',
        'last_name',
        'phone_number',
        'email',
        'address',        
        'building_no',
        'street_no',
        'zone_no',
        'is_billing'     
    ];

    /** CAPTURE SHIPPING INFO */

    public static function createOrderShippingInfo($transDetails, $orderUID, $orderID)
    {
        $shipID = self::create(['order_id' => $orderUID, 'master_order_id' => $orderID, 'first_name' => $transDetails->ship_first_name, 'last_name' => $transDetails->ship_last_name, 'phone_number' => $transDetails->ship_phone_number, 'email' => $transDetails->ship_email, 'address' => $transDetails->ship_address, 'building_no' => $transDetails->ship_building_no,'street_no' => $transDetails->ship_street_no, 'zone_no' => $transDetails->ship_zone_no, 'is_billing' => $transDetails->is_billing])->id;

        return $shipID;
    }
}
