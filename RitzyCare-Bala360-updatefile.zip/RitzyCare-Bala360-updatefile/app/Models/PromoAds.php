<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class PromoAds extends Model
{
    use HasFactory;
    use HasTranslations;    
    
    public $translatable = ['ad_title'];
    protected $dates = ['deleted_at'];
}
