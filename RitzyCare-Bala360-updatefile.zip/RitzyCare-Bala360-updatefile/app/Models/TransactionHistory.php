<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use AppHelpers;
use App\Models\ItemInventory;

class TransactionHistory extends Model
{
    use HasFactory;
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'transaction_id',
        'payment_id',
        'item_id',
        'item_sku',
        'item_type',
        'has_variant',
        'variant_id',
        'has_inventory_track',
        'item_qty',
        'item_amount',
        'transaction_amount',
        'cart_info'        
    ];

    /** TRANSACTION HISTORIES */

    public static function logTransactionHistory($cartInfo, $transID, $payID)
    {
        foreach ($cartInfo as $c) {               
            $getStock = ItemInventory::where(['item_id' => $c->options->item_id, 'id' => $c->options->variant_id, 'status' => 1])->first();                
            if ($getStock) {
                $transHis = new TransactionHistory;
                $transHis->transaction_id = $transID;
                $transHis->payment_id = $payID;
                $transHis->item_id = $c->options->item_id;
                $transHis->item_sku = $c->options->item_code;
                $transHis->item_type = $c->options->item_type;
                $transHis->has_variant = $c->options->has_variant;
                $transHis->variant_id = $c->options->variant_id;
                $transHis->has_inventory_track = $c->options->has_inventory_track;
                $transHis->item_qty = $c->qty;
                $transHis->item_amount = $c->price;
                $transHis->transaction_amount = AppHelpers::formatNumber(($c->qty * $c->price));
                $transHis->cart_info = json_encode($c);
                $transHis->save();
            }
        }
    }
}
