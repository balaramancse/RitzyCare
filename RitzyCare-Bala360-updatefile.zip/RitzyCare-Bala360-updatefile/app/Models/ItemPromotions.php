<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItemPromotions extends Model
{
    use HasFactory;

    /** Get Item Information */

    public function itemInfo()
    {
        return $this->belongsTo('App\Models\Items', 'item_id', 'id');
    }

    /** Fetch Parent Attribute Image */

    public function ItemParentImage()
    {
        return $this->itemImages()->where('image_type', '=', 0);
    }

    /** Attribute Image */

    public function itemImages()
    {
        return $this->belongsTo('App\Models\ItemImages', 'item_id', 'item_id')->orderBy('image_name')->groupBy('item_id');
    }
    
    /** Wishlist Items */

    public function wishList()
    {
        return $this->hasMany(UserWishList::class,'item_id','item_id');
    }
}
