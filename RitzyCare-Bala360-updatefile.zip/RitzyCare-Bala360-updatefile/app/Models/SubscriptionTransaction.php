<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubscriptionTransaction extends Model
{
    use HasFactory;    

    const PAYMENT_PENDING = 0;
    const PAYMENT_COMPLETED = 1;
    const PAYMENT_FAILED = 2;
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'payment_id',
        'transaction_ref',
        'correlation_id',
        'acknowledgement',
        'payment_type',
        'payment_mode',
        'payment_status',
        'plan_id',
        'user_id',
        'plan_name',
        'plan_amount',
        'plan_validity',
        'plan_benefits',        
        'transaction_ip',
        'transaction_log'
    ];
}
