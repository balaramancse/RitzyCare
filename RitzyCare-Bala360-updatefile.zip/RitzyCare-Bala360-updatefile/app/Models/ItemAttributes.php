<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;
use Illuminate\Database\Eloquent\SoftDeletes;

class ItemAttributes extends Model
{
    use HasFactory;
    use HasTranslations;
    use SoftDeletes;

    public $translatable = ['variant_name'];
    protected $dates = ['deleted_at'];

    /** Get Variant Parent Image */

    public function getVariantParentImage()
    {
        return $this->variantImages()->where('image_type', '=', 0);
    }

    /** Get Variant Child Images */

    public function getVariantChildImages()
    {
        return $this->variantImages()->where('image_type', '=', 1);
    }

    /** Variant Images */

    public function variantImages()
    {
        return $this->hasMany('App\Models\ItemImages', 'item_attribute_id', 'id');
    }    

    /** Inventory Attribute Details */

    public function inventoryAttributes()
    {
        return $this->hasMany('App\Models\ItemInventory', 'attribute_id', 'id');
    }

    /** Inventory Item Details */

    public function inventoryItem()
    {
        return $this->belongsTo('App\Models\Items', 'item_id', 'id');
    }    
}
