<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderBillingInfo extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'order_id',
        'shipping_ref_id',
        'master_order_id',
        'first_name',
        'last_name',
        'phone_number',
        'email',
        'address',        
        'building_no',
        'street_no',
        'zone_no'          
    ];

    /** CAPTURE SHIPPING INFO */

    public static function createOrderShippingInfo($transDetails, $orderUID, $orderID, $shipID)
    {
        $billInfo = new OrderBillingInfo;
        $billInfo->order_id = $orderUID;
        $billInfo->shipping_ref_id = $shipID;
        $billInfo->master_order_id = $orderID;
        $billInfo->first_name = $transDetails->bill_first_name;
        $billInfo->last_name = $transDetails->bill_last_name;
        $billInfo->phone_number = $transDetails->bill_phone_number;
        $billInfo->email = $transDetails->bill_email;
        $billInfo->address = $transDetails->bill_address;
        $billInfo->building_no = $transDetails->bill_building_no;
        $billInfo->street_no = $transDetails->bill_street_no;
        $billInfo->zone_no = $transDetails->bill_zone_no;
        $billInfo->save();
    }
}
