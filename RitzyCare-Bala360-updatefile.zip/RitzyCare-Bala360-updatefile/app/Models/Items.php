<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Translatable\HasTranslations;
use willvincent\Rateable\Rateable;

class Items extends Model
{
    use HasFactory;
    use HasTranslations;
    use SoftDeletes;
    use Rateable;

    public $translatable = ['item_name', 'item_description', 'item_summary'];
    protected $dates = ['deleted_at'];

    /** Parent Attribute Details */

    public function itemParentAttributes()
    {
        return $this->hasMany('App\Models\ItemAttributes', 'item_id', 'id');
    }

    /** Attribute Image */

    public function itemImages()
    {
        return $this->hasMany('App\Models\ItemImages', 'item_id', 'id')->orderBy('image_type');
    }

    /** Fetch Parent Attribute Details */

    public function getItemParentData()
    {
        return $this->itemParentAttributes()->where('variant_type', '=', 0);

    }

    /** Fetch Parent Attribute Image */

    public function getItemParentImage()
    {
        return $this->itemImages()->where('image_type', '=', 0);
    }

    /** Fetch Child Attribute Images */

    public function getItemChildImages()
    {
        return $this->itemImages()->where('image_type', '=', 1);
    }

    /** Fetch Item Specification */

    public function getItemSpec()
    {
        return $this->hasMany('App\Models\ItemSpecifications', 'item_id', 'id');
    }
    
    /** Fetch Child Attributes */

    public function getItemAttribute()
    {
        return $this->itemChildAttributes()->where('variant_type', '=', 1);
    }

    /** Get Child Attributes */

    public function itemChildAttributes()
    {
        return $this->hasMany('App\Models\ItemAttributes', 'item_id', 'id')->orderBy('variant_type');
    }

    /** Get Total Inventory */

    public function getTotalInventory()
    {
        return $this->hasMany('App\Models\ItemInventory', 'item_id', 'id')->orderBy('selling_price');
    }

    /** Get Item Promotions */

    public function getItemPromotions()
    {
        return $this->hasMany('App\Models\ItemPromotions', 'item_id', 'id');
    }

    /** Item Rating & Review */

    public function ratings()
    {
        return $this->hasMany('App\Models\Rating','rateable_id','id');
    }

    /** Wishlist Items */

    public function wishList()
    {
        return $this->hasMany(UserWishList::class,'item_id','id');
    }
}
