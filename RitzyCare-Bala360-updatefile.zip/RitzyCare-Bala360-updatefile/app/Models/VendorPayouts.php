<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VendorPayouts extends Model
{
    use HasFactory;

    protected $fillable = ['vendor_id','paycycle_start','paycycle_end','total_sales','total_paid','total_outstanding'];
}
