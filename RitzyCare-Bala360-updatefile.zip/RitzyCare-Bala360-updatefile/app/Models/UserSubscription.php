<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserSubscription extends Model
{
    use HasFactory;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'subscription_id',
        'subs_pay_ref',
        'plan_id',
        'user_id',
        'plan_name',
        'plan_amount',
        'plan_validity',
        'plan_benefits',
        'start_date',
        'end_date',
        'plan_status',
        'approve_status'        
    ];
}
