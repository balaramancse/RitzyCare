<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use AppHelpers;

class Order extends Model
{
    use HasFactory;

    const ORDER_PENDING = 0;
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'order_id',
        'payment_id',
        'user_id',
        'tracking_code',
        'order_status',
        'is_delivery',
        'delivery_method',        
        'delivery_date',
        'delivery_slot',
        'delivery_verification_code',
        'is_delivery_verified',
        'delivered_date',
        'driver_id',
        'driver_assigned_date',
        'drivery_rating'    
    ];

    /** CREATE ORDER */

    public static function createOrder($orderID, $cartPayRef, $userID, $isDelivery, $deliveryMethod, $deliveryDate, $schDelSlot = '')
    {
        $trackingCode = AppHelpers::getTDCode(8, 'tracking');
        $deliveryCode = AppHelpers::getTDCode(6);

        $orderUID = self::create(['order_id' => $orderID, 'payment_id' => $cartPayRef, 'user_id' => $userID, 'tracking_code' => $trackingCode, 'order_status' => self::ORDER_PENDING, 'is_delivery_required' => $isDelivery, 'delivery_method' => $deliveryMethod, 'delivery_date' => $deliveryDate, 'delivery_slot' => (($deliveryMethod == 3) ? $schDelSlot : ""), 'delivery_verification_code' => $deliveryCode])->id;

        $data = array('order_uid' => $orderUID, 'tracking_code' => $trackingCode, 'delivery_code' => $deliveryCode);
        return $data;
    }

    /** GET ORDER DETAILS */

    public function orderDetail()
    {
        return $this->hasMany('App\Models\OrderDetail', 'order_id', 'id');
    }

    /** GET ORDER BASED SHIPPING INFO */

    public function shipInfo()
    {
        return $this->hasOne('App\Models\OrderShippingInfo', 'order_id', 'id');
    }

    /** GET ORDER BASED BILLING INFO */

    public function billInfo()
    {
        return $this->hasOne('App\Models\OrderBillingInfo', 'order_id', 'id');
    }

     /** GET CUSTOMER INFO */

     public function customerInfo()
     {
         return $this->hasOne('App\Models\User', 'id', 'user_id');
     }
}
