<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ItemInventory extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $dates = ['deleted_at'];

    /** Inventory Attribute Details */

    public function inventoryAttributes()
    {
        return $this->belongsTo('App\Models\ItemAttributes', 'attribute_id', 'id');
    }

    /** Inventory Item Details */

    public function inventoryItem()
    {
        return $this->belongsTo('App\Models\Items', 'item_id', 'id');
    }

    /** Inventory Vendor Details */

    public function inventoryVendors()
    {
        return $this->belongsTo('App\Models\Admin', 'vendor_id', 'id');
    }

    /** Fetch Parent Attribute Image */

    public function ItemParentImage()
    {
        return $this->itemImages()->where('image_type', '=', 0);
    }

    /** Attribute Image */

    public function itemImages()
    {
        return $this->hasMany('App\Models\ItemImages', 'item_id', 'item_id')->orderBy('image_name')->groupBy('item_id');
    }
    
    /** Wishlist Items */

    public function wishList()
    {
        return $this->hasMany(UserWishList::class,'item_id','item_id');
    }
}
