<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Translatable\HasTranslations;

class Stores extends Model
{
    use HasFactory;
    use HasTranslations;
    use SoftDeletes;

    public $translatable = ['store_name'];
    protected $dates = ['deleted_at'];

    /** To fetch vendor information */

    public function merchant()
    {
        return $this->belongsTo('App\Models\Admin', 'vendor_id', 'id');
    }

    /** To fetch zone information */

    public function zone()
    {
        return $this->hasOne('App\Models\Zones', 'id', 'zone_id');
    }

    /** To fetch area information */

    public function area()
    {
        return $this->hasOne('App\Models\Area', 'id', 'area_id');
    }
}
