<?php

return [

    'vendor_pay_cycle' => [1 => "Every 15 days once", 2 => "Every 30 days once", 3 => "Every month 15th", 4 => "Every month end"],

    'attribute_type_const' => [0 => "Text", 1 => "Color", 2 => "Image"],

    'social_media_config' => [0 => "Facebook", 1 => "Twitter", 2 => "Instagram", 3 => "Linkedin", 4 => "Snapchat", 5 => "Youtube"],

    'history_action_type' => [1 => "Created", 2 => "Updated", 3 => "Paused"],

    'social_links' => ['facebook' => 'https://facebook.com', 'twitter' => 'https://twitter.com', 'instagram' => 'https://instagram.com', 'youtube' => 'https://youtube.com', 'snapchat' => 'https://snapchat.com'],

    'affiliate_who_am' => [1 => array("en" => "An Influencer", "ar" => "مؤثر"), 2 => array("en" => "A Model", "ar" => "موديل"), 3 => array("en" => "A Blogger", "ar" => "مدون"), 4 => array("en" => "An Actor", "ar" => "ممثل"), 5 => array("en" => "Others", "ar" => 'آحرون')],

    'vendor_reg_terms' => ['en' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'ar' => 'لوريم إيبسوم هو ببساطة نص شكلي يستخدم في صناعة الطباعة والتنضيد. كان Lorem Ipsum هو النص الوهمي القياسي في الصناعة منذ القرن الخامس عشر الميلادي ، عندما أخذت طابعة غير معروفة لوحًا من النوع وتدافعت عليه لعمل كتاب عينة.'],

    'delivery_slots' => ["09AM" => "09.00 AM - 12.00 PM", "12PM" => "12.00 PM - 03.00 PM", "03PM" => "03.00 PM - 06.00 PM", "06PM" => "06.00 PM - 09.00 PM", "09PM" => "09.00 PM - 10.00 PM"],

    'delivery_status' => [0 => "Pending", 1 => "Verified", 2 => "Partial Shipped", 3 => "Shipped", 4 => "Delivery In Process", 5 => "Delivered", 6 => "Hold", 7 => "Cancelled", 8 => "Partially Refunded", 9 => "Refunded"],
];
