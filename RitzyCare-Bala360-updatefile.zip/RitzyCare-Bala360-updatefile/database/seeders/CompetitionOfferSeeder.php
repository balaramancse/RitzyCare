<?php

namespace Database\Seeders;

use App\Models\CompetitionOffer;
use Illuminate\Database\Seeder;

class CompetitionOfferSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $comptOffer = new CompetitionOffer;
        $offer_en = "Get early access to sales, exclusive discounts, enjoy free products and services, and more";
        $offer_ar = "احصل على وصول مبكر إلى المبيعات والخصومات الحصرية واستمتع بالمنتجات والخدمات المجانية والمزيد";
        $comptOffer->setTranslation('offer_name', 'en', $offer_en)->setTranslation('offer_name', 'ar',$offer_ar); 
        $comptOffer->status = 1;
        $comptOffer->modified_by = 0;
        $comptOffer->app_type = 0;            
        $comptOffer->save();

        $comptOffer = new CompetitionOffer;
        $offer_en = "The opportunity to be featured on Ritzy.care social media’s & website";
        $offer_ar = "فرصة الظهور على مواقع الشبكات الاجتماعية وموقع Ritzy.care";
        $comptOffer->setTranslation('offer_name', 'en', $offer_en)->setTranslation('offer_name', 'ar',$offer_ar); 
        $comptOffer->status = 1;
        $comptOffer->modified_by = 0;
        $comptOffer->app_type = 0;            
        $comptOffer->save();

        $comptOffer = new CompetitionOffer;
        $offer_en = "Inclusion in exclusive Ritzy.care upcoming contests and giveaways";
        $offer_ar = "الإدراج في المسابقات والهدايا القادمة من Ritzy.care الحصرية";
        $comptOffer->setTranslation('offer_name', 'en', $offer_en)->setTranslation('offer_name', 'ar',$offer_ar); 
        $comptOffer->status = 1;
        $comptOffer->modified_by = 0;
        $comptOffer->app_type = 0;            
        $comptOffer->save();
    }
}
