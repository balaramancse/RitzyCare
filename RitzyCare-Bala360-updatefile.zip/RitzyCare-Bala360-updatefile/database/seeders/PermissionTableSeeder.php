<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermissionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //$permissions['dashboard'] = array('role-list','role-create','role-edit','role-delete','product-list','product-create','product-edit','product-delete');

        $permissions['dashboard'][0] = "Dashboard";
        $permissions['dashboard'][1] = array('dashboard-list');
        $permissions['roles'][0] = "Roles";
        $permissions['roles'][1] = array('role-list', 'role-create', 'role-edit', 'role-delete');

        $permissions['settings'][0] = "Settings Module";
        $permissions['settings'][1] = array('setting-list');

        $permissions['gs_social_settings'][0] = "Social Media Settings";
        $permissions['gs_social_settings'][1] = array('sm-setting-list', 'sm-setting-update');
        $permissions['gs_social_reviews'][0] = "Social Media Reviews";
        $permissions['gs_social_reviews'][1] = array('sm-review-list', 'sm-review-add', 'sm-review-edit', 'sm-review-status', 'sm-review-delete', 'sm-review-highlight');
        $permissions['gs_payment_settings'][0] = "Payment Settings";
        $permissions['gs_payment_settings'][1] = array('gs-payment-list', 'gs-payment-list-update');
        $permissions['gs_module_settings'][0] = "Module Settings";
        $permissions['gs_module_settings'][1] = array('gs-module-list', 'gs-module-update');
        $permissions['gs_banner_settings'][0] = "Banner Settings";
        $permissions['gs_banner_settings'][1] = array('gs-banner-list', 'gs-banner-add', 'gs-banner-edit', 'gs-banner-status', 'gs-banner-delete');
        $permissions['gs_zone_settings'][0] = "Zone Settings";
        $permissions['gs_zone_settings'][1] = array('gs-zone-list', 'gs-zone-add', 'gs-zone-edit', 'gs-zone-status', 'gs-zone-delete');
        $permissions['gs_area_settings'][0] = "Area Settings";
        $permissions['gs_area_settings'][1] = array('gs-area-list', 'gs-area-add', 'gs-area-edit', 'gs-area-status', 'gs-area-delete');
        $permissions['gs_category_settings'][0] = "Category Settings";
        $permissions['gs_category_settings'][1] = array('gs-category-list', 'gs-category-add', 'gs-category-edit', 'gs-category-status', 'gs-category-delete');
        $permissions['gs_brand_settings'][0] = "Brand Settings";
        $permissions['gs_brand_settings'][1] = array('gs-brand-list', 'gs-brand-add', 'gs-brand-edit', 'gs-brand-status', 'gs-brand-delete');
        $permissions['gs_attribute_settings'][0] = "Attribute Settings";
        $permissions['gs_attribute_settings'][1] = array('gs-attribute-list', 'gs-attribute-add', 'gs-attribute-edit');
        $permissions['gs_page_settings'][0] = "Static Page Settings";
        $permissions['gs_page_settings'][1] = array('gs-page-list', 'gs-page-add', 'gs-page-edit', 'gs-page-status', 'gs-page-delete');
        $permissions['gs_promo_settings'][0] = "Promotional Ad & Video Settings";
        $permissions['gs_promo_settings'][1] = array('gs-promo-list', 'gs-promo-add', 'gs-promo-edit', 'gs-promo-status', 'gs-promo-delete');
        $permissions['gs_app_program'][0] = "App Programme Settings";
        $permissions['gs_app_program'][1] = array('gs-app-pro-list', 'gs-app-pro-add', 'gs-app-pro-edit', 'gs-app-pro-status');
        $permissions['gs_faq'][0] = "Faq Settings";
        $permissions['gs_faq'][1] = array('gs-faq-list', 'gs-faq-add', 'gs-faq-edit', 'gs-faq-status', 'gs-faq-delete');

        $permissions['cs_manage_cust'][0] = "Customer Module Settings";
        $permissions['cs_manage_cust'][1] = array('cs-cust-list', 'cs-cust-email-mask', 'cs-cust-phone-mask', 'cs-cust-status');
        $permissions['cs_premium_cust'][0] = "Premium Customer Settings";
        $permissions['cs_premium_cust'][1] = array('cs-pro-cust-list', 'cs-pro-cust-email-mask', 'cs-pro-cust-phone-mask');
        $permissions['cs_affiliate_cust'][0] = "Affiliate Customer Settings";
        $permissions['cs_affiliate_cust'][1] = array('cs-aff-cust-list', 'cs-aff-cust-email-mask', 'cs-aff-cust-phone-mask', 'cs-aff-cust-status');
        $permissions['cs_manage_enq'][0] = "Enquiry Settings";
        $permissions['cs_manage_enq'][1] = array('cs-enq-list', 'cs-enq-email-mask', 'cs-enq-phone-mask');
        $permissions['cs_manage_subs'][0] = "Subscriber Settings";
        $permissions['cs_manage_subs'][1] = array('cs-sub-list', 'cs-sub-email-mask', 'cs-sub-phone-mask', 'cs-sub-status');

        $permissions['item_settings'][0] = "Item Settings";
        $permissions['item_settings'][1] = array('item-list', 'item-add', 'item-edit', 'item-status', 'item-delete', 'item-highlight', 'item-inventory', 'item-inventory-add', 'item-inventory-edit', 'item-variant-list', 'item-vendor-list', 'item-vendor-status');

        $permissions['vendor_settings'][0] = "Vendor Settings";
        $permissions['vendor_settings'][1] = array('vendor-list', 'vendor-add', 'vendor-edit', 'vendor-status', 'vendor-delete', 'vendor-email-unmask', 'vendor-phone-unmask');

        $permissions['app_user_settings'][0] = "Application User Settings";
        $permissions['app_user_settings'][1] = array('app-user-list', 'app-user-add', 'app-user-edit', 'app-user-status', 'app-user-delete');

        $permissions['order_management'][0] = "Order Management";
        $permissions['order_management'][1] = array('order-list', 'order-add', 'order-edit', 'order-status', 'order-invoice-view', 'order-info-mask');

        foreach ($permissions as $key => $permission) {
            foreach ($permission[1] as $p) {
                Permission::create(['name' => $p, 'group_name' => $key, 'readable_group_name' => $permission[0]]);
            }
        }
    }
}
