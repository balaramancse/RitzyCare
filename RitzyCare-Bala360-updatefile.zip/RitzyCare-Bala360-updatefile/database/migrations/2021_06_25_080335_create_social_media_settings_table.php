<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSocialMediaSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('social_media_settings', function (Blueprint $table) {
            $table->id();
            $table->text('facebook')->nullable();
            $table->text('twiter')->nullable();
            $table->text('linkedin')->nullable();
            $table->text('youtube')->nullable();
            $table->text('snapchat')->nullable();
            $table->text('instagram')->nullable();
            $table->text('android_app')->nullable();
            $table->text('ios_app')->nullable();
            $table->text('google_analytics')->nullable();
            $table->text('google_tag')->nullable();
            $table->text('facebook_sdk')->nullable();
            $table->integer('app_type')->comment('0 - Both, 1 - Men, 2 - Women')->default(0);
            $table->index('app_type');
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('social_media_settings');
    }
}
