<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('items', function (Blueprint $table) {
            $table->id();
            $table->text('item_name')->nullable();
            $table->index('item_name');
            $table->string('category_id')->nullable();
            $table->string('sub_category_id')->nullable();
            $table->string('sec_subcategory_id')->nullable();
            $table->string('third_category_id')->nullable();
            $table->integer('brand_id')->nullable();
            $table->index('brand_id');
            $table->longText('item_description')->nullable();
            $table->longText('item_summary')->nullable();           
            $table->integer('item_group')->comment('1 - Product, 2 - Service')->default(1)->nullable();
            $table->index('item_group');
            $table->string('item_sku')->unique()->nullable();
            $table->index('item_sku');
            $table->string('item_rcin')->unique()->nullable();
            $table->index('item_rcin');
            $table->text('meta_title')->nullable();
            $table->text('meta_description')->nullable();
            $table->text('meta_keywords')->nullable();
            $table->text('slug')->nullable();
            $table->integer('is_inventory_track')->comment('0 - Unlimited, 1 - Limited')->default(0)->nullable();
            $table->integer('is_variants')->comment('0 - No, 1 - Yes')->default(0)->nullable();
            $table->integer('is_active')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->index('is_active');            
            $table->integer('status')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->index('status');
            $table->integer('modified_by')->default(0);
            $table->integer('app_type')->comment('0 - Both, 1 - Men, 2 - Women')->default(0);
            $table->index('app_type');
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
            $table->softDeletes();
        }); 
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('items');
    }
}
