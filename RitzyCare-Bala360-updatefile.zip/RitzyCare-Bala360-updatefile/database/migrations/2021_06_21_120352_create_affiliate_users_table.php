<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAffiliateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('affiliate_users', function (Blueprint $table) {
            $table->id();
            $table->integer('user_type')->comment('Desc - Ref App Config')->nullable();
            $table->string('user_name')->nullable();
            $table->string('user_email')->nullable();
            $table->string('dial_code')->default('974')->nullable();
            $table->string('phone_number')->nullable();
            $table->string('country')->nullable();
            $table->longText('website')->nullable();
            $table->longText('fb_info')->nullable();
            $table->longText('insta_info')->nullable();
            $table->longText('other_info')->nullable();
            $table->integer('is_subscribed')->comment('0 - No, 1 - Yes')->default(1)->nullable();
            $table->integer('status')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->ipAddress('record_ip')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')); 
            $table->softDeletes(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('affiliate_users');
    }
}
