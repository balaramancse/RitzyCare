<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrderDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('order_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained();  
            $table->index('order_id'); 
            $table->string('master_order_id')->nullable();
            $table->string('sub_order_id')->nullable();
            $table->string('tracking_code')->nullable();  
            $table->integer('item_id')->nullable();
            $table->integer('item_group')->nullable();            
            $table->integer('vendor_id')->nullable();
            $table->integer('inventory_id')->nullable();
            $table->integer('order_qty')->nullable();
            $table->double('order_amount')->nullable();
            $table->double('total_amount')->nullable();
            $table->integer('order_status')->comment('Ref - Config')->default(0)->nullable();
            $table->integer('is_delivery_required')->comment('0 - No, 1 - Yes')->default(1)->nullable();           
            $table->dateTime('shipped_date')->nullable();            
            $table->integer('driver_id')->nullable();
            $table->dateTime('driver_assigned_date')->nullable();
            $table->dateTime('dispatch_date')->nullable();
            $table->text('comments')->nullable();  
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')); 
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('order_details');
    }
}
