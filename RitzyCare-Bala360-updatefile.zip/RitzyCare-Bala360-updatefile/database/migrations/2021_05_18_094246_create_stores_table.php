<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStoresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stores', function (Blueprint $table) {
            $table->id();
            $table->integer('vendor_id')->default(0);
            $table->string('store_name')->nullable();
            $table->string('contact_number')->nullable();
            $table->integer('building_no')->default(0)->nullable();
            $table->integer('street_no')->default(0)->nullable();
            $table->integer('zone_no')->default(0)->nullable();
            $table->text('landmark')->nullable();
            $table->integer('po_box')->default(0)->nullable();
            $table->string('sm_name')->nullable();
            $table->string('sm_email')->nullable();
            $table->string('sm_contact_number')->nullable();
            $table->string('fm_name')->nullable();
            $table->string('fm_email')->nullable();
            $table->string('fm_contact_number')->nullable();
            $table->integer('zone_id')->default(0)->nullable();
            $table->integer('area_id')->default(0)->nullable();      
            $table->string('slug')->nullable();      
            $table->integer('is_active')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->integer('status')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->integer('modified_by')->default(0);
            $table->integer('app_type')->comment('0 - Both, 1 - Men, 2 - Women')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('stores');
    }
}
