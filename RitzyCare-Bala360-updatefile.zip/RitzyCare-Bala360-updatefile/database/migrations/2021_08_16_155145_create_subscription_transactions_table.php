<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSubscriptionTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('subscription_transactions', function (Blueprint $table) {
            $table->id();
            $table->string('payment_id')->nullable();
            $table->string('transaction_ref')->comment('Bank Transaction ID')->nullable(); 
            $table->string('correlation_id')->comment('Third party pay ref')->nullable();
            $table->text('acknowledgement')->nullable();  
            $table->integer('payment_type')->default(0)->comment('0 - Sale, 1 - Authorize')->nullable();
            $table->integer('payment_mode')->comment('1 - Credit Card, 2 - Debit Card, 3 - Paypal')->nullable();
            $table->integer('payment_status')->default(0)->comment('0 - Pending, 1 - Success, 2 - Failed')->nullable();
            $table->integer('plan_id')->nullable();
            $table->integer('user_id')->nullable();
            $table->text('plan_name')->nullable();
            $table->double('plan_amount')->nullable();
            $table->integer('plan_validity')->nullable();
            $table->longText('plan_benefits')->nullable();            
            $table->ipAddress('transaction_ip')->nullable();
            $table->longText('transaction_log')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subscription_transactions');
    }
}
