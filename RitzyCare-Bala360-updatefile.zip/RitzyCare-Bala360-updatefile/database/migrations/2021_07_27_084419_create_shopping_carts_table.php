<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateShoppingCartsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('shopping_carts', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id')->nullable();
            $table->integer('user_type')->default(0)->comment('0 - Normal, 1 - Premium')->nullable();
            $table->string('ref_id')->comment('Package - rowId')->nullable();
            $table->integer('cart_id')->nullable();
            $table->integer('item_id')->nullable();
            $table->string('item_name')->nullable();
            $table->double('price')->nullable();
            $table->integer('quantity')->default(1)->nullable();
            $table->longText('options')->nullable();
            $table->text('device_id')->nullable();
            $table->integer('device_type')->default(0)->comment('0 - Web, 1 - Android, 2 - IOS')->nullable();            
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('shopping_carts');
    }
}
