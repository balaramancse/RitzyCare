<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemInventoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_inventories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('item_id')->constrained();  
            $table->integer('attribute_id')->default(0)->nullable();
            $table->index('attribute_id'); 
            $table->integer('vendor_id')->default(0)->nullable();
            $table->index('vendor_id');
            $table->integer('store_id')->default(0)->nullable();
            $table->index('store_id');
            $table->double('base_price')->default(0)->nullable();
            $table->index('base_price');
            $table->double('selling_price')->default(0)->nullable();
            $table->index('selling_price');
            $table->integer('quantity')->default(0)->nullable();
            $table->index('quantity');            
            $table->integer('purchase_count')->default(0)->nullable();
            $table->index('purchase_count');
            $table->integer('status')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->index('status');
            $table->integer('modified_by')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')); 
            $table->softDeletes(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_inventories');
    }
}
