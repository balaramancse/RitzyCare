<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddVendorRelatedColumnIntoAdminsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('admins', function (Blueprint $table) {
            $table->string('last_name')->after('name')->nullable();
            $table->string('vendor_RCID')->after('last_name')->comment('Ritzycare Short ID')->nullable();
            $table->string('contact_number')->after('password')->nullable();
            $table->double('vendor_margin')->after('contact_number')->default(0)->nullable();
            $table->integer('vendor_payout')->after('vendor_margin')->comment('description in app config file')->default(0)->nullable();
            $table->integer('status')->after('vendor_payout')->comment('0 - Inactive, 1 - Active')->default(1)->nullable();
            $table->integer('modified_by')->after('status')->default(0)->nullable();
            $table->integer('app_type')->after('modified_by')->comment('0 - Both, 1 - Men, 2 - Women')->default(0)->nullable();
            $table->integer('user_type')->after('app_type')->comment('0 - Admin, 1 - Vendors')->default(0)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('admins', function (Blueprint $table) {
            $table->dropColumn('last_name');
            $table->dropColumn('vendor_RCID');
            $table->dropColumn('contact_number');
            $table->dropColumn('vendor_margin');
            $table->dropColumn('vendor_payout');
            $table->dropColumn('status');
            $table->dropColumn('modified_by');
            $table->dropColumn('app_type');
            $table->dropColumn('user_type');
        });
    }
}
