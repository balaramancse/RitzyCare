<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemPromotionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_promotions', function (Blueprint $table) {
            $table->id(); 
            $table->integer('item_id')->nullable();  
            $table->integer('promotion_id')->comment('1 - Flash, 2 - Weekly, 3 - Monthly, 4 - Exclusive, 5 - Members, 6 - Best Sellers')->nullable();
            $table->index('promotion_id');
            $table->string('promotion_ref')->nullable();
            $table->dateTime('start_date')->nullable();
            $table->dateTime('end_date')->nullable();
            $table->integer('is_expired')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->index('is_expired');
            $table->integer('status')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->index('status');
            $table->integer('modified_by')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));             
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_promotions');
    }
}
