<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVendorPayoutsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vendor_payouts', function (Blueprint $table) {
            $table->id();
            $table->integer('vendor_id')->comment('fkey of admin')->nullable();
            $table->string('paycycle_start')->nullable();
            $table->string('paycycle_end')->nullable();
            $table->double('total_sales')->default(0)->comment('This pay cycle')->nullable();
            $table->double('total_paid')->default(0)->nullable();
            $table->double('total_payable')->default(0)->nullable();
            $table->double('total_outstanding')->default(0)->nullable();
            $table->double('prev_outstanding')->default(0)->nullable();
            $table->integer('is_active')->default(1)->comment('1 - Active, 0 - In Active')->nullable();
            $table->integer('status')->default(1)->comment('1 - Pending, 0 - Completed')->nullable();
            $table->integer('paid_by')->default(0)->nullable();
            $table->string('paid_date')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vendor_payouts');
    }
}
