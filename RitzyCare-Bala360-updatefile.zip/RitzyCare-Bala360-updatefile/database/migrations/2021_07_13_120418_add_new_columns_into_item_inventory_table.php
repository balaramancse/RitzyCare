<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddNewColumnsIntoItemInventoryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('item_inventories', function (Blueprint $table) {
            $table->integer('discount')->after('base_price')->default(0)->comment('% Value')->nullable();
            $table->integer('member_discount')->after('selling_price')->default(0)->comment('% Value')->nullable();
            $table->double('member_selling_price')->after('member_discount')->default(0)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('item_inventories', function (Blueprint $table) {
            $table->dropColumn('discount');      
            $table->dropColumn('member_discount');
            $table->dropColumn('member_selling_price');         
        });
    }
}
