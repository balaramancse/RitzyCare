<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVideoReviewsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('video_reviews', function (Blueprint $table) {
            $table->id();
            $table->string('video_name')->nullable();
            $table->longText('video_url')->nullable();
            $table->integer('is_highlight')->default(0)->comment('0 - No, 1 - Yes')->nullable();
            $table->integer('status')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->integer('modified_by')->default(0);
            $table->integer('app_type')->comment('0 - Both, 1 - Men, 2 - Women')->default(0);
            $table->index('app_type');
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')); 
            $table->softDeletes(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('video_reviews');
    }
}
