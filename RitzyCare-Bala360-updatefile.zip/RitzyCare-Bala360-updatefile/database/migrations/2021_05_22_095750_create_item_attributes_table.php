<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemAttributesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_attributes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('item_id')->constrained();   
            $table->string('item_rcin')->nullable();
            $table->index('item_rcin');
            $table->string('variant_rcin')->nullable();
            $table->index('variant_rcin');        
            $table->text('variant_name')->nullable();            
            $table->integer('variant_type')->comment('0 - Parent, 1 - Child')->default(0)->nullable();
            $table->index('variant_type');
            $table->integer('attribute_type')->comment('0 - Text, 1 - Color, 2 - Image')->default(0)->nullable();
            $table->index('attribute_type');
            $table->text('attribute_value')->nullable(); 
            $table->integer('status')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->index('status');
            $table->integer('modified_by')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')); 
            $table->softDeletes();           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_attributes');
    }
}
