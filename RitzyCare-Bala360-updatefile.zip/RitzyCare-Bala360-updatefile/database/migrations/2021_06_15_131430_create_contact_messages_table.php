<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateContactMessagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contact_messages', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->string('email')->nullable();
            $table->string('dial_code')->default('974')->nullable();
            $table->string('phone')->nullable();
            $table->text('message')->nullable();
            $table->integer('type')->default(1)->comment('1 - Contact, 2 - Business')->nullable();
            $table->integer('status')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->ipAddress('record_ip')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contact_messages');
    }
}
