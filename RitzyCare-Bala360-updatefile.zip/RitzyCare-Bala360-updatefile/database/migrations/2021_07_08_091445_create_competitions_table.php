<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCompetitionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::enableForeignKeyConstraints();
        Schema::create('competitions', function (Blueprint $table) {
            $table->id();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('email')->nullable();
            $table->string('dial_code')->default('974')->nullable();
            $table->string('phone_number')->nullable();
            $table->foreignId('nationality_id'); 
            $table->longText('social_account')->nullable();  
            $table->string('height')->nullable();
            $table->string('weight')->nullable();
            $table->string('file_name')->nullable();
            $table->integer('is_agree')->comment('0 - No, 1 - Yes')->default(0);
            $table->index('is_agree');
            $table->integer('is_permission')->comment('0 - No, 1 - Yes')->default(0);
            $table->index('is_permission');
            $table->ipAddress('record_ip')->nullable();
            $table->integer('status')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->integer('modified_by')->default(0);
            $table->integer('app_type')->comment('0 - Both, 1 - Men, 2 - Women')->default(0);
            $table->index('app_type');
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')); 
            $table->softDeletes(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('competitions');
    }
}
