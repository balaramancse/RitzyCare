<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePromoAdsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('promo_ads', function (Blueprint $table) {
            $table->id();
            $table->string('ad_title')->nullable();
            $table->string('ad_image')->nullable();
            $table->integer('redirect_type')->default(0)->comment('0 - Internal, 1 - External')->nullable();
            $table->text('redirect_url')->nullable();
            $table->dateTime('start_date')->nullable();
            $table->dateTime('end_date')->nullable();
            $table->string('slug')->nullable();
            $table->integer('status')->comment('0 - Inactive, 1 - Active')->default(1);
            $table->integer('page_display')->comment('0 - home, 1 - List')->default(1);            
            $table->integer('modified_by')->default(0);
            $table->integer('app_type')->comment('0 - Both, 1 - Men, 2 - Women')->default(0);
            $table->index('app_type');
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('promo_ads');
    }
}
