<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->string('payment_id')->nullable();            
            $table->string('correlation_id')->comment('Third party pay ref')->nullable();
            $table->string('transaction_ref')->comment('Bank Transaction ID')->nullable(); 
            $table->text('acknowledgement')->nullable();  
            $table->integer('payment_type')->default(0)->comment('0 - Sale, 1 - Authorize')->nullable();
            $table->integer('payment_mode')->comment('1 - Credit Card, 2 - Debit Card, 3 - Paypal, 4 - COD, 5 - Ritzypay')->nullable();
            $table->integer('payment_status')->default(0)->comment('0 - Pending, 1 - Success, 2 - Failed')->nullable();
            $table->integer('user_id')->nullable();
            $table->double('sub_total')->nullable();
            $table->double('delivery_amount')->nullable();
            $table->double('total_amount')->nullable();
            $table->integer('is_coupon_used')->comment('0 - No, 1 - Yes')->default(0)->nullable();
            $table->string('coupon_code')->nullable();
            $table->integer('is_points_used')->comment('0 - No, 1 - Yes')->default(0)->nullable();
            $table->integer('reward_points')->nullable();
            $table->double('points_amount')->nullable();
            $table->double('transaction_amount')->nullable();
            $table->double('usd_amount')->nullable();
            $table->string('ship_first_name')->nullable();
            $table->string('ship_last_name')->nullable();  
            $table->string('ship_phone_number')->nullable();
            $table->string('ship_email')->nullable();            
            $table->longText('ship_address')->nullable();
            $table->string('ship_building_no')->nullable();
            $table->string('ship_street_no')->nullable();
            $table->string('ship_zone_no')->nullable();            
            $table->integer('is_billing')->comment('0 - No, 1 - Yes')->default(0)->nullable();
            $table->string('bill_first_name')->nullable();
            $table->string('bill_last_name')->nullable();  
            $table->string('bill_phone_number')->nullable();
            $table->string('bill_email')->nullable();            
            $table->longText('bill_address')->nullable();
            $table->string('bill_building_no')->nullable();
            $table->string('bill_street_no')->nullable();
            $table->string('bill_zone_no')->nullable();
            $table->integer('is_delivery')->comment('0 - No, 1 - Yes')->default(1)->nullable(); 
            $table->ipAddress('transaction_ip')->nullable();
            $table->longText('transaction_log')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
