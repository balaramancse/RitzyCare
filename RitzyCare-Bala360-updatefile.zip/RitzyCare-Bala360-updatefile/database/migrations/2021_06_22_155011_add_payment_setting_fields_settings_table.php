<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddPaymentSettingFieldsSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('settings', function (Blueprint $table) {
            $table->double('express_delivery_hrs')->after('meta_description')->nullable();
            $table->double('standard_delivery_hrs')->after('express_delivery_hrs')->nullable();
            $table->double('schedule_delivery_hrs')->after('standard_delivery_hrs')->nullable();   
            $table->double('express_delivery')->comment('Amount')->after('standard_delivery_hrs')->default(0)->nullable();     
            $table->double('standard_delivery')->comment('Amount')->after('express_delivery')->default(0)->nullable();
            $table->double('scheduled_delivery')->comment('Amount')->after('standard_delivery')->default(0)->nullable();
            $table->string('currency_code')->after('scheduled_delivery')->nullable();
            $table->string('country_code')->after('scheduled_delivery')->nullable();
            $table->text('paypal_account')->after('country_code')->nullable();
            $table->text('paypal_api')->after('paypal_account')->nullable();
            $table->string('paypal_signature')->after('paypal_api')->nullable();
            $table->text('migs_merchant_id')->after('paypal_signature')->nullable();
            $table->string('migs_access_code')->after('migs_merchant_id')->nullable();
            $table->text('migs_secret_key')->after('migs_access_code')->nullable();
            $table->text('naps_merchant_id')->after('migs_secret_key')->nullable();
            $table->string('naps_bank_id')->after('naps_merchant_id')->nullable();
            $table->text('naps_secret_key')->after('naps_bank_id')->nullable();
            $table->integer('payment_mode')->comment('0 - Sandbox, 1 - Live')->default(0)->after('naps_secret_key')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('settings', function (Blueprint $table) {
            $table->dropColumn('express_delivery_hrs');
            $table->dropColumn('standard_delivery_hrs');
            $table->dropColumn('schedule_delivery_hrs');
            $table->dropColumn('express_delivery');
            $table->dropColumn('standard_delivery');
            $table->dropColumn('scheduled_delivery');
            $table->dropColumn('currency_code');
            $table->dropColumn('country_code');
            $table->dropColumn('paypal_account');
            $table->dropColumn('paypal_api');
            $table->dropColumn('paypal_signature');
            $table->dropColumn('migs_merchant_id');
            $table->dropColumn('migs_access_code');
            $table->dropColumn('migs_secret_key');
            $table->dropColumn('naps_merchant_id');
            $table->dropColumn('naps_bank_id');
            $table->dropColumn('naps_secret_key');
            $table->dropColumn('payment_mode');
        });
    }
}
