<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserSubscriptionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_subscriptions', function (Blueprint $table) {
            $table->id();
            $table->string('subscription_id')->nullable();
            $table->string('subs_pay_ref')->nullable();
            $table->integer('plan_id')->nullable();
            $table->integer('user_id')->nullable();
            $table->text('plan_name')->nullable();
            $table->double('plan_amount')->nullable();
            $table->integer('plan_validity')->nullable();
            $table->longText('plan_benefits')->nullable();
            $table->dateTime('start_date')->nullable();
            $table->dateTime('end_date')->nullable();
            $table->integer('plan_status')->comment('0 - Expired, 1 - Active')->default(0);
            $table->integer('approve_status')->comment('0 - Pending, 1 - Approved')->default(1);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')); 
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_subscriptions');
    }
}
