<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrderBillingInfosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('order_billing_infos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained();  
            $table->index('order_id'); 
            $table->integer('shipping_ref_id')->nullable();          
            $table->string('master_order_id')->nullable();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();  
            $table->string('phone_number')->nullable();
            $table->string('email')->nullable();            
            $table->longText('address')->nullable();
            $table->string('building_no')->nullable();
            $table->string('street_no')->nullable();
            $table->string('zone_no')->nullable();           
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));             
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('order_billing_infos');
    }
}
