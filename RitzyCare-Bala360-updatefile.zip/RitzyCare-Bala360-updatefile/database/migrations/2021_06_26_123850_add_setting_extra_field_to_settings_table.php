<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddSettingExtraFieldToSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('settings', function (Blueprint $table) {
            $table->string('logo')->after('schedule_delivery_hrs')->nullable();
            $table->string('favicon')->after('logo')->nullable();
            $table->string('logo_ar')->after('favicon')->nullable();
            $table->string('favicon_ar')->after('logo_ar')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('settings', function (Blueprint $table) {
            $table->dropColumn('logo');
            $table->dropColumn('favicon');
            $table->dropColumn('logo_ar');
            $table->dropColumn('favicon_ar');
        });
    }
}
