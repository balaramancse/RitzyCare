<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldsToUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->integer('dial_code')->after('email')->nullable();
            $table->integer('phone_number')->after('dial_code')->nullable();
            $table->longText('verification_token')->after('password')->nullable();
            $table->dateTime('token_expiry')->after('verification_token')->nullable();
            $table->integer('token_status')->after('token_expiry')->comment('0 - Pending, 1 - Verified')->default(0)->nullable();
            $table->integer('is_active')->after('token_status')->comment('0 - In Active, 1 - Active')->default(0)->nullable();
            $table->dateTime('last_login')->after('is_active')->nullable();
            $table->ipAddress('last_login_ip')->after('last_login')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('dial_code');
            $table->dropColumn('phone_number');
            $table->dropColumn('verification_token');
            $table->dropColumn('token_expiry');
            $table->dropColumn('token_status');
            $table->dropColumn('is_active');
            $table->dropColumn('last_login');
            $table->dropColumn('last_login_ip');            
        });
    }
}
