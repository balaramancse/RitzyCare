<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemPromotionHistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_promotion_histories', function (Blueprint $table) {
            $table->id();
            $table->integer('item_id')->nullable(); 
            $table->index('item_id'); 
            $table->string('promotion_ref')->nullable();
            $table->integer('promotion_id')->default(0)->nullable();
            $table->index('promotion_id'); 
            $table->dateTime('start_date')->nullable();
            $table->dateTime('end_date')->nullable();
            $table->string('action_type')->comment('Desc - rc config')->default(1)->nullable();
            $table->string('action_description')->nullable();
            $table->integer('modified_by')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_promotion_histories');
    }
}
