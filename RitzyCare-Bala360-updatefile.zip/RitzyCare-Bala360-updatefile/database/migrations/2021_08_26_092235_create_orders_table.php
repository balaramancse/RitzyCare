<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_id')->nullable();
            $table->string('payment_id')->nullable();
            $table->integer('user_id')->nullable();
            $table->string('tracking_code')->nullable();  
            $table->integer('order_status')->comment('Ref - Config')->default(0)->nullable();
            $table->integer('is_delivery')->comment('0 - No, 1 - Yes')->default(1)->nullable(); 
            $table->integer('delivery_method')->comment('1 - Express, 2 - Standard, 3 - Scheduled')->nullable();          
            $table->dateTime('delivery_date')->nullable();  
            $table->string('delivery_slot')->nullable();           
            $table->string('delivery_verification_code')->nullable();
            $table->string('is_delivery_verified')->comment('0 - No, 1 - Yes')->default(0)->nullable();
            $table->dateTime('delivered_date')->nullable();            
            $table->integer('driver_id')->nullable();
            $table->dateTime('driver_assigned_date')->nullable();
            $table->integer('drivery_rating')->nullable();            
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
